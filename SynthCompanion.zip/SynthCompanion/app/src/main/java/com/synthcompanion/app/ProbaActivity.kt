package com.synthcompanion.app

import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import java.util.Locale
import kotlin.math.abs

/**
 * Probabilités et radar : ce que les données confirment vraiment (la taille des mouvements),
 * la chance de toucher chaque niveau, la taille de lot, et les niveaux cassés en attente de retour
 * sur toutes les unités de temps.
 */
class ProbaActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private var radarBox: LinearLayout? = null
    private var polBox: LinearLayout? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun f0(v: Double) = String.format(Locale.FRANCE, "%,.0f", v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { setBackgroundColor(color(R.color.bg)); addView(content) }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(14), b.top + dp(8), b.right + dp(14), b.bottom + dp(12))
            insets
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun text(t: String, size: Float = 13f, col: Int = R.color.text, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color(col))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.15f)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(color(R.color.surface))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        }
    }

    private fun btn(t: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = t
            textSize = 12f
            setOnClickListener { onClick() }
        }

    private fun render() {
        content.removeAllViews()
        content.addView(text("🎲 Probabilités et radar", 22f, bold = true))
        val candles = ArrayList(MarketHub.candles)
        val gran = MarketHub.granularity
        if (candles.size < 80) {
            content.addView(text("Pas encore assez de bougies chargées. Reviens dans un instant.", 13f, R.color.muted))
            return
        }
        val price = candles.last().close
        val measured = Prob.realizedVol(candles, gran)
        val sig = if (measured.isNaN() || measured <= 0) 0.5 else measured
        content.addView(text(
            "${MarketHub.shortName()} · ${MarketHub.timeframeLabel()} · prix ${MarketHub.format(price)}\n" +
                "Sur 90 jours de données, une seule chose revient vraiment : la taille des mouvements (volatilité fixe). " +
                "Le sens, lui, se comporte comme pile ou face. Ces chiffres valent donc autant pour la hausse que pour la baisse.",
            12.5f, R.color.muted,
        ).apply { setPadding(0, dp(4), 0, 0) })

        // Fourchettes
        val c1 = card()
        c1.addView(text("Fourchettes probables", 15f, R.color.accent, true))
        c1.addView(text("Volatilité mesurée : ${String.format(Locale.FRANCE, "%.1f", sig * 100)} % par an (annoncée : 50 %)", 12.5f, R.color.muted))
        val sb = StringBuilder()
        for ((sec, lbl) in listOf(900.0 to "15 min", 3600.0 to "1 h", 14400.0 to "4 h", 86400.0 to "24 h")) {
            sb.append("$lbl : ±${f0(Prob.points(price, sig, sec))} pts\n")
            sb.append("   2 chances sur 3 : ${f0(Prob.low(price, sig, sec))} – ${f0(Prob.high(price, sig, sec))}\n")
            sb.append("   95 % : ${f0(Prob.low(price, sig, sec, 1.96))} – ${f0(Prob.high(price, sig, sec, 1.96))}\n")
        }
        c1.addView(text(sb.toString().trimEnd(), 13f))
        content.addView(c1)

        // Niveaux
        val c2 = card()
        c2.addView(text("Chance que le prix TOUCHE chaque niveau", 15f, R.color.accent, true))
        val a = Analysis(candles)
        val t = a.lastClosed
        val levels = ArrayList<Pair<String, Double>>()
        val ov = a.structure.overlayAt(t, price)
        for (z in ov.zones) levels.add((if (z.mid > price) "Résistance ${z.touches}×" else "Support ${z.touches}×") to z.mid)
        for (l in ov.lines) levels.add((if (l.isSupport) "Oblique S" else "Oblique R") to l.valueAt(t))
        val full = try { Polarity.scanFull(a, from = maxOf(61, t - 200), to = t) } catch (e: Exception) { null }
        for (b in full?.pending ?: emptyList()) levels.add("Niveau cassé ${if (b.up) "↑" else "↓"}" to b.mid)
        for (al in AlertStore.activeFor(MarketHub.symbol)) levels.add("Alerte 🔔" to al.price)
        for (tr in Journal.all().filter { it.isOpen && it.symbol == MarketHub.symbol }) {
            levels.add("Stop de ta position" to tr.stop)
            tr.target?.let { levels.add("Objectif de ta position" to it) }
        }
        val shown = levels.filter { abs(it.second - price) > 0 }
            .sortedBy { abs(it.second - price) }.take(10).sortedByDescending { it.second }
        if (shown.isEmpty()) c2.addView(text("Aucun niveau proche pour l'instant.", 13f, R.color.muted))
        for ((name, p) in shown) {
            val diff = p - price
            c2.addView(text(
                "$name · ${MarketHub.format(p)} (${if (diff > 0) "+" else ""}${f0(diff)})\n" +
                    "   1 h ${Prob.pct(Prob.touch(price, p, sig, 3600.0))} · 4 h ${Prob.pct(Prob.touch(price, p, sig, 14400.0))} · " +
                    "24 h ${Prob.pct(Prob.touch(price, p, sig, 86400.0))}",
                13f, if (diff > 0) R.color.up else R.color.down,
            ).apply { setPadding(0, dp(4), 0, 0) })
        }
        content.addView(c2)

        // Taille de lot
        content.addView(lotCard(price, sig))

        // Positions
        val open = Journal.all().filter { it.isOpen && it.symbol == MarketHub.symbol }
        if (open.isNotEmpty()) {
            val c4 = card()
            c4.addView(text("Tes positions ouvertes", 15f, R.color.accent, true))
            for (tr in open) {
                val tg = tr.target
                val od = if (tg != null) Prob.odds(price, tr.stop, tg, sig) else null
                c4.addView(text(
                    "${if (tr.side == Side.BUY) "Achat" else "Vente"} à ${MarketHub.format(tr.entry)} · stop ${MarketHub.format(tr.stop)}" +
                        (tg?.let { " · objectif ${MarketHub.format(it)}" } ?: "") + "\n" +
                        (if (od != null) "   Depuis le prix actuel : objectif d'abord ${Prob.pct(od.pTarget)} · durée moyenne ${Prob.duration(od.seconds)}\n" else "") +
                        "   Stop touché dans l'heure : ${Prob.pct(Prob.touch(price, tr.stop, sig, 3600.0))}",
                    13f,
                ).apply { setPadding(0, dp(4), 0, 0) })
            }
            content.addView(c4)
        }

        // Inversion de polarité sur l'unité affichée
        val c5 = card()
        c5.addView(text("🔁 Cassures et retours (${MarketHub.timeframeLabel()})", 15f, R.color.accent, true))
        polBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        polBox?.addView(text("Calcul en cours…", 12.5f, R.color.muted))
        c5.addView(polBox)
        content.addView(c5)

        // Radar
        val c6 = card()
        c6.addView(text("📡 Radar : niveaux cassés en attente de retour", 15f, R.color.accent, true))
        radarBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        radarBox?.addView(text("Analyse de M1, M5, M15, M30, H1 et H4 à partir des données enregistrées…", 12.5f, R.color.muted))
        c6.addView(radarBox)
        c6.addView(btn("Actualiser") { render() })
        content.addView(c6)

        computePolarity(candles)
        computeRadar(MarketHub.symbol)
    }

    private fun lotCard(price: Double, sig: Double): View {
        val c = card()
        c.addView(text("💰 Taille de position", 15f, R.color.accent, true))
        fun number(v: Double, hint: String) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(String.format(Locale.US, "%.2f", v))
            this.hint = hint
            setTextColor(color(R.color.text))
        }
        val etCap = number(Journal.balance(), "Capital $")
        val etPct = number(Journal.riskPercent, "Risque %")
        val etStop = number(Prob.points(price, sig, 3600.0), "Stop (points)")
        val out = text("", 13f)
        fun refresh() {
            val cap = etCap.text.toString().replace(',', '.').toDoubleOrNull() ?: return
            val pctV = etPct.text.toString().replace(',', '.').toDoubleOrNull() ?: return
            val stopPts = etStop.text.toString().replace(',', '.').toDoubleOrNull() ?: return
            if (stopPts <= 0) return
            val risk = cap * pctV / 100
            val lot = Contracts.lotFor(risk, price, price - stopPts)
            val minLot = Contracts.minLot(MarketHub.symbol)
            out.text = "Perte si le stop est touché : ${String.format(Locale.US, "%.2f", risk)} $\n" +
                "Lot conseillé : ${String.format(Locale.US, "%.3f", lot)}" +
                (minLot?.let { " (minimum indicatif ${String.format(Locale.US, "%.3f", it)})" } ?: "") + "\n" +
                "Ce stop a ${Prob.pct(Prob.touch(price, price - stopPts, sig, 3600.0))} de chances d'être touché par le simple bruit dans l'heure " +
                "(${Prob.pct(Prob.touch(price, price - stopPts, sig, 900.0))} en 15 min)."
        }
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) = refresh()
        }
        for ((label, et) in listOf("Capital ($)" to etCap, "Risque par trade (%)" to etPct, "Distance du stop (points) — proposé : 1σ sur 1 h" to etStop)) {
            c.addView(text(label, 12f, R.color.muted).apply { setPadding(0, dp(6), 0, 0) })
            et.addTextChangedListener(watcher)
            c.addView(et)
        }
        c.addView(out)
        refresh()
        return c
    }

    private fun computePolarity(candles: List<Candle>) {
        CandleDb.async({
            val a = Analysis(candles)
            Polarity.scanFull(a, from = 61, to = a.lastClosed)
        }) { full ->
            val box = polBox ?: return@async
            if (isFinishing) return@async
            box.removeAllViews()
            if (full == null || full.breaks < 5) {
                box.addView(text("Pas assez de cassures sur les bougies chargées.", 12.5f, R.color.muted))
                return@async
            }
            val resolved = full.retests.filter { it.outcome != 0 }
            val held = resolved.count { it.outcome > 0 }
            val quick = full.retests.count { it.retestIndex - it.breakIndex <= 5 }
            box.addView(text(
                "${full.breaks} cassures sur ${candles.size} bougies. ${Prob.pct(full.retests.size.toDouble() / full.breaks)} reviennent tester le niveau " +
                    "dans les 60 bougies (${Prob.pct(if (full.retests.isEmpty()) 0.0 else quick.toDouble() / full.retests.size)} en 5 bougies ou moins).\n" +
                    "Au retour, le niveau a tenu $held fois et cédé ${resolved.size - held} fois " +
                    "(${Prob.pct(if (resolved.isEmpty()) 0.0 else held.toDouble() / resolved.size)} ; hasard ≈ 50 %).\n" +
                    "Le retour est presque sûr ; son issue ne l'est pas.",
                13f,
            ))
        }
    }

    private fun computeRadar(symbol: String) {
        val tfs = listOf(60, 300, 900, 1800, 3600, 14400)
        CandleDb.async({
            val m1 = CandleDb.loadRecent(symbol, 130_000)
            if (m1.size < 500) null
            else tfs.mapNotNull { g ->
                val c = AiEngine.aggregate(m1, g).takeLast(1500)
                if (c.size < 120) return@mapNotNull null
                val a = Analysis(c)
                val t = c.size - 1
                val full = Polarity.scanFull(a, from = maxOf(61, t - 200), to = t)
                val atr = a.structure.atrAt(t)
                Triple(g, c.last().close to atr, full.pending.map { it to (t - it.breakIndex) })
            }
        }) { rows ->
            val box = radarBox ?: return@async
            if (isFinishing) return@async
            box.removeAllViews()
            if (rows == null) {
                box.addView(text("Pas assez de bougies M1 enregistrées pour cet indice. Suis-le dans « Données stockées ».", 12.5f, R.color.muted))
                return@async
            }
            var any = false
            for ((g, priceAtr, pend) in rows) {
                for ((b, age) in pend) {
                    any = true
                    val (p, atr) = priceAtr
                    val dist = if (atr > 0) (p - b.mid) / atr * (if (b.up) 1 else -1) else 0.0
                    box.addView(text(
                        "${Timeframes.label(g)} · ${if (b.up) "↑ cassé vers le haut" else "↓ cassé vers le bas"} · ${MarketHub.format(b.mid)}\n" +
                            "   il y a $age bougie${if (age > 1) "s" else ""} · à ${String.format(Locale.FRANCE, "%.1f", dist)} ATR du prix",
                        13f, if (b.up) R.color.up else R.color.down,
                    ).apply { setPadding(0, dp(4), 0, 0) })
                }
            }
            if (!any) box.addView(text("Aucun niveau cassé en attente, sur aucune unité de temps.", 13f, R.color.muted))
            box.addView(text("Un niveau reste « en attente » 60 bougies après sa cassure.", 11.5f, R.color.muted).apply { setPadding(0, dp(6), 0, 0) })
        }
    }
}
