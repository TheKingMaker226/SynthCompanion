package com.synthcompanion.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    const val SERVICE_ID = 1
    private const val CLOSE_ID = 2

    /** v2 : canal sans pastille sur l'icône (le réglage d'un canal ne peut plus changer après sa création). */
    private const val CH_SERVICE = "service_v2"
    private const val CH_PAPER = "paper_trades"
    private const val CH_PRICE = "price_alerts"
    private const val CH_CLOSE = "candle_close"
    private const val CH_SIGNAL = "signals"
    private const val CH_ALARM = "alarm"
    private const val ALARM_ID = 4
    private const val SIGNAL_ID = 3

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.deleteNotificationChannel("service")
        nm.createNotificationChannels(
            listOf(
                NotificationChannel(CH_SERVICE, "Suivi en direct", NotificationManager.IMPORTANCE_LOW)
                    .apply { setShowBadge(false) },
                NotificationChannel(CH_PAPER, "Positions fictives", NotificationManager.IMPORTANCE_DEFAULT),
                NotificationChannel(CH_PRICE, "Alertes de prix", NotificationManager.IMPORTANCE_HIGH)
                    .apply { enableVibration(true) },
                NotificationChannel(CH_CLOSE, "Clôture de bougie", NotificationManager.IMPORTANCE_HIGH)
                    .apply { enableVibration(true) },
                NotificationChannel(CH_ALARM, "Alarmes (sonnerie)", NotificationManager.IMPORTANCE_HIGH)
                    .apply {
                        setSound(null, null) // le son est joué par AlarmPlayer, sur le flux alarme
                        enableVibration(false)
                    },
                NotificationChannel(CH_SIGNAL, "Signaux d'entrée", NotificationManager.IMPORTANCE_HIGH)
                    .apply {
                        enableVibration(true)
                        vibrationPattern = longArrayOf(0, 300, 150, 300)
                    },
            )
        )
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun serviceNotification(ctx: Context, text: String): Notification {
        val stop = PendingIntent.getService(
            ctx, 1,
            Intent(ctx, MarketService::class.java).setAction(MarketService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(ctx, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Synth Companion")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .addAction(0, "Arrêter", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    fun priceAlert(ctx: Context, alert: PriceAlert, price: Double, name: String, level: String, priceText: String) {
        val arrow = if (alert.direction == Direction.ABOVE) "▲" else "▼"
        val n = NotificationCompat.Builder(ctx, CH_PRICE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("$arrow $name a atteint $level")
            .setContentText("Prix actuel : $priceText")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        notify(ctx, 100 + (alert.id % 100_000).toInt(), n)
    }

    fun candleClosing(ctx: Context, name: String, timeframe: String, secondsLeft: Int) {
        val n = NotificationCompat.Builder(ctx, CH_CLOSE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Bougie $timeframe : clôture dans $secondsLeft s")
            .setContentText(name)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setTimeoutAfter(20_000)
            .setContentIntent(openApp(ctx))
            .build()
        notify(ctx, CLOSE_ID, n)
    }

    fun signal(
        ctx: Context, sig: Signal, name: String, timeframe: String,
        entry: String, stop: String, target: String, history: String,
    ) {
        val icon = if (sig.side == Side.BUY) "🟢" else "🔴"
        val title = "$icon Signal ${Report.sideLabel(sig.side)} · $name $timeframe"
        val text = "Entrée $entry · Stop $stop · Objectif $target"
        val n = NotificationCompat.Builder(ctx, CH_SIGNAL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$text\n${sig.strategy.label}\n$history"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        notify(ctx, SIGNAL_ID, n)
    }

    /** Notification d'alarme : écran plein au-dessus du verrouillage + bouton Arrêter. */
    fun alarm(ctx: Context, title: String, text: String) {
        val screen = PendingIntent.getActivity(
            ctx, 5,
            Intent(ctx, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            ctx, 6,
            Intent(ctx, MarketService::class.java).setAction(MarketService.ACTION_STOP_ALARM),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CH_ALARM)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("⏰ $title")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(screen, true)
            .setContentIntent(screen)
            .addAction(0, "ARRÊTER L'ALARME", stop)
            .build()
        notify(ctx, ALARM_ID, n)
    }

    fun cancelAlarm(ctx: Context) {
        NotificationManagerCompat.from(ctx).cancel(ALARM_ID)
    }

    @SuppressLint("MissingPermission")
    fun aiSignal(ctx: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_SIGNAL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text.substringBefore('\n'))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        notify(ctx, 7, n)
    }

    /** Position fictive clôturée par son stop ou son objectif. */
    fun paperClosed(ctx: Context, t: PaperTrade, fmt: (Double) -> String) {
        val icon = if (t.r >= 0) "✅" else "❌"
        val sens = if (t.side == Side.BUY) "Achat" else "Vente"
        val title = "$icon Position fictive clôturée : ${String.format(java.util.Locale.US, "%+.2f R", t.r)}"
        val text = "$sens ${t.symbol} · ${t.reason} à ${fmt(t.exit ?: 0.0)} · " +
            String.format(java.util.Locale.US, "%+.2f $", t.pnl)
        val n = NotificationCompat.Builder(ctx, CH_PAPER)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        notify(ctx, 50_000 + (t.id % 10_000).toInt(), n)
    }

    /** Retire toutes les notifications de l'appli (la notification permanente du service reste). */
    fun cancelAll(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        for (sb in nm.activeNotifications) {
            if (sb.id == SERVICE_ID) continue
            if (sb.id == ALARM_ID && AlarmPlayer.isRinging) continue
            nm.cancel(sb.tag, sb.id)
        }
    }

    private fun notify(ctx: Context, id: Int, n: Notification) {
        // Historique dans l'appli (sauf compte à rebours de clôture, trop fréquent)
        if (id != CLOSE_ID && id != SERVICE_ID) {
            val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
                ?: n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            NotificationLog.add(title, text)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }
}
