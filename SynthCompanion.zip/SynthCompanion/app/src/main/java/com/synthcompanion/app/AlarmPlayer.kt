package com.synthcompanion.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Sonnerie façon réveil : son d'alarme du téléphone en boucle (flux « alarme », donc audible même en
 * mode silencieux ou vibreur), vibration répétée, et écran d'alarme. S'arrête seule après 90 s.
 */
object AlarmPlayer {

    private const val AUTO_STOP_MS = 90_000L

    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var appCtx: Context? = null

    var isRinging = false
        private set
    var title = ""
        private set
    var text = ""
        private set

    private val autoStop = Runnable { appCtx?.let { stop(it) } }

    fun start(ctx: Context, title: String, text: String) {
        val app = ctx.applicationContext
        appCtx = app
        this.title = title
        this.text = text
        stopSound()

        val uri = RingtoneManager.getActualDefaultRingtoneUri(app, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        if (uri != null) {
            try {
                player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    setDataSource(app, uri)
                    isLooping = true
                    setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
                    prepare()
                    start()
                }
            } catch (_: Exception) {
                player?.release()
                player = null
            }
        }

        vibrator = if (Build.VERSION.SDK_INT >= 31) {
            app.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            app.getSystemService(Vibrator::class.java)
        }
        try {
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        } catch (_: Exception) {
        }

        isRinging = true
        Notifier.alarm(app, title, text)
        main.removeCallbacks(autoStop)
        main.postDelayed(autoStop, AUTO_STOP_MS)
    }

    fun stop(ctx: Context) {
        stopSound()
        isRinging = false
        main.removeCallbacks(autoStop)
        Notifier.cancelAlarm(ctx.applicationContext)
    }

    private fun stopSound() {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        player?.release()
        player = null
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
    }
}
