package com.synthcompanion.app

import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Probabilités : sur 90 jours de données, la seule chose qui revient vraiment est la TAILLE des
 * mouvements. Le V50 se comporte comme un mouvement aléatoire à volatilité fixe (≈ 50 % par an) :
 * on peut chiffrer la fourchette probable et la chance d'atteindre un niveau, mais pas le sens.
 */
object Prob {
    const val YEAR = 365.0 * 24 * 3600

    /** Dernière volatilité mesurée par un graphique (utilisée par le ticket d'ordre). */
    @Volatile
    var lastSigma: Double = 0.5

    /** Dernière tendance affichée par un graphique (+1, −1, 0) et son unité de temps. */
    @Volatile
    var lastTrend: Int = 0

    @Volatile
    var lastTrendTf: String = ""

    /** Volatilité annualisée mesurée sur les dernières bougies (rendements logarithmiques). */
    fun realizedVol(c: List<Candle>, granularity: Int, maxBars: Int = 3000): Double {
        if (c.size < 31 || granularity <= 0) return Double.NaN
        val from = max(1, c.size - maxBars)
        var s2 = 0.0
        var n = 0
        for (i in from until c.size) {
            if (c[i].epoch - c[i - 1].epoch > granularity * 3 / 2) continue // trou dans les données
            if (c[i].close <= 0 || c[i - 1].close <= 0) continue
            val r = ln(c[i].close / c[i - 1].close)
            s2 += r * r
            n++
        }
        if (n < 30) return Double.NaN
        return sqrt(s2 / n * YEAR / granularity)
    }

    /** Écart type (fraction du prix) sur [seconds]. */
    fun sigmaT(sigma: Double, seconds: Double): Double = sigma * sqrt(max(0.0, seconds) / YEAR)

    /** Écart de ±k écarts types en points de prix. */
    fun points(price: Double, sigma: Double, seconds: Double, k: Double = 1.0): Double =
        price * (exp(k * sigmaT(sigma, seconds)) - 1)

    fun low(price: Double, sigma: Double, seconds: Double, k: Double = 1.0) = price * exp(-k * sigmaT(sigma, seconds))
    fun high(price: Double, sigma: Double, seconds: Double, k: Double = 1.0) = price * exp(k * sigmaT(sigma, seconds))

    /** Probabilité que le prix touche [level] au moins une fois dans [seconds]. */
    fun touch(price: Double, level: Double, sigma: Double, seconds: Double): Double {
        val s = sigmaT(sigma, seconds)
        if (s <= 0 || price <= 0 || level <= 0) return 0.0
        val d = abs(ln(level / price))
        return min(1.0, 2 * (1 - normCdf(d / s)))
    }

    /** Probabilité d'être au-dessus de [level] au bout de [seconds]. */
    fun above(price: Double, level: Double, sigma: Double, seconds: Double): Double {
        val s = sigmaT(sigma, seconds)
        if (s <= 0) return if (price > level) 1.0 else 0.0
        return 1 - normCdf(ln(level / price) / s)
    }

    data class Odds(val pTarget: Double, val seconds: Double)

    /** Position : chance de toucher l'objectif avant le stop, et durée moyenne avant l'un des deux. */
    fun odds(entry: Double, stop: Double, target: Double, sigma: Double): Odds? {
        if (entry <= 0 || stop <= 0 || target <= 0 || sigma <= 0) return null
        val a = abs(ln(stop / entry))
        val b = abs(ln(target / entry))
        if (a <= 0 || b <= 0) return null
        return Odds(a / (a + b), a * b / (sigma * sigma) * YEAR)
    }

    fun duration(sec: Double): String = when {
        !sec.isFinite() -> "—"
        sec < 90 -> "${sec.toInt()} s"
        sec < 5400 -> "${(sec / 60).toInt()} min"
        sec < 172_800 -> String.format(Locale.FRANCE, "%.1f h", sec / 3600)
        else -> String.format(Locale.FRANCE, "%.1f j", sec / 86_400)
    }

    fun pct(p: Double): String = String.format(Locale.FRANCE, "%.0f %%", p * 100)

    /** Fonction de répartition de la loi normale. */
    fun normCdf(z: Double): Double {
        val t = 1 / (1 + 0.2316419 * abs(z))
        val d = 0.3989423 * exp(-z * z / 2)
        val p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))))
        return if (z > 0) 1 - p else p
    }

    /** Volatilité jour par jour (annualisée) : [moyenne, min, max, écart-type observé, écart-type attendu par hasard]. */
    fun dailyVols(c: List<Candle>, granularity: Int): DoubleArray? {
        if (granularity > 3600) return null
        val days = LinkedHashMap<Long, DoubleArray>() // [somme des carrés, n]
        for (i in 1 until c.size) {
            if (c[i].epoch - c[i - 1].epoch > granularity * 3 / 2) continue
            val r = ln(c[i].close / c[i - 1].close)
            val acc = days.getOrPut(c[i].epoch / 86_400) { DoubleArray(2) }
            acc[0] += r * r
            acc[1] += 1.0
        }
        val per = 86_400.0 / granularity
        val vols = days.values.filter { it[1] > per * 0.8 }.map { sqrt(it[0] / it[1] * YEAR / granularity) }
        if (vols.size < 3) return null
        val m = vols.average()
        val sd = sqrt(vols.sumOf { (it - m) * (it - m) } / (vols.size - 1))
        return doubleArrayOf(m, vols.min(), vols.max(), sd, m / sqrt(2 * per), vols.size.toDouble())
    }
}
