package com.synthcompanion.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/** Rapport d'analyse en texte simple, affichable et partageable. */
object Report {

    private fun pct(v: Double) = String.format(Locale.US, "%+.2f %%", v)
    private fun num(v: Double, d: Int = 2) = String.format(Locale.US, "%.${d}f", v)
    private fun r(v: Double) = String.format(Locale.US, "%+.2f R", v)

    fun sideLabel(side: Side) = if (side == Side.BUY) "ACHAT" else "VENTE"

    private fun trendLabel(t: Int) = when (t) {
        1 -> "haussière"
        -1 -> "baissière"
        else -> "sans direction"
    }

    /**
     * @param mtf analyses des autres unités de temps (libellé → analyse), dans l'ordre M1 → D1.
     *            Peut contenir l'unité de temps affichée.
     */
    fun build(
        a: Analysis,
        symbolName: String,
        timeframe: String,
        granularity: Int,
        selected: Strategy,
        slAtr: Double,
        tpAtr: Double,
        mtf: List<Pair<String, Analysis>>,
        fmt: (Double) -> String,
    ): String {
        val c = a.candles
        val n = c.size
        val i = a.lastClosed
        val st = a.structure
        val dateFmt = SimpleDateFormat(if (granularity >= 86_400) "dd/MM/yyyy" else "dd/MM HH:mm", Locale.FRANCE)
        val sb = StringBuilder()
        val last = c.last().close

        sb.appendLine("RAPPORT · $symbolName · $timeframe")
        sb.appendLine(
            "${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())} · $n bougies " +
                "(du ${dateFmt.format(Date(c.first().epoch * 1000))} au ${dateFmt.format(Date(c.last().epoch * 1000))})"
        )
        sb.appendLine()

        // ---------- Vue multi-unités ----------
        val views = mtf.ifEmpty { listOf(timeframe to a) }
        if (views.size > 1) {
            sb.appendLine("VUE MULTI-UNITÉS DE TEMPS")
            var up = 0
            var down = 0
            for ((label, x) in views) {
                val t = x.lastClosed
                if (t < 60) {
                    sb.appendLine("• $label : pas assez de données")
                    continue
                }
                val tr = x.trendAt(t)
                if (tr > 0) up++ else if (tr < 0) down++
                val rsi = x.rsi.getOrNull(t) ?: Double.NaN
                val parts = mutableListOf(trendLabel(tr))
                if (!rsi.isNaN()) parts.add("RSI ${num(rsi, 0)}")
                x.structure.chartPatternsAt(t).firstOrNull()?.let {
                    parts.add(it.name + if (it.confirmed) " (confirmée)" else " (en formation)")
                }
                x.structure.candlePatternAt(t)?.let { parts.add("bougie : ${it.name}") }
                sb.appendLine("• $label : ${parts.joinToString(" · ")}")
            }
            val total = views.size
            sb.appendLine("Alignement : $up/$total haussières, $down/$total baissières, ${total - up - down}/$total sans direction.")
            sb.appendLine()
        }

        // ---------- Détail de l'unité affichée ----------
        sb.appendLine("DÉTAIL $timeframe")
        val first = c.first().open
        sb.appendLine("• Prix : ${fmt(last)} · variation sur la période ${pct((last - first) / first * 100)}")
        val e20 = a.ema20.getOrNull(i) ?: Double.NaN
        val e50 = a.ema50.getOrNull(i) ?: Double.NaN
        val atr = st.atrAt(i)
        val rsi = a.rsi.getOrNull(i) ?: Double.NaN
        if (!e20.isNaN() && !e50.isNaN()) {
            sb.appendLine("• Tendance ${trendLabel(a.trendAt(i))} : EMA20 ${fmt(e20)} · EMA50 ${fmt(e50)} · prix ${if (last >= e50) "au-dessus" else "en dessous"} de l'EMA 50")
        }
        if (!rsi.isNaN()) {
            val zone = when {
                rsi >= 70 -> "surachat"
                rsi <= 30 -> "survente"
                rsi >= 50 -> "neutre, plutôt acheteur"
                else -> "neutre, plutôt vendeur"
            }
            sb.appendLine("• RSI14 : ${num(rsi, 1)} ($zone)")
        }
        if (atr > 0) sb.appendLine("• Volatilité ATR14 : ${fmt(atr)} (${num(atr / last * 100, 3)} % du prix par bougie)")

        val zones = st.zonesAt(i)
        fun zoneText(z: Zone) = "${fmt(z.low)} – ${fmt(z.high)} (${z.touches} touche${if (z.touches > 1) "s" else ""})"
        val sups = zones.filter { it.high < last }.sortedByDescending { it.high }.take(3)
        val ress = zones.filter { it.low > last }.sortedBy { it.low }.take(3)
        sb.appendLine("• Supports : " + if (sups.isEmpty()) "aucun" else sups.joinToString(" · ") { zoneText(it) })
        sb.appendLine("• Résistances : " + if (ress.isEmpty()) "aucune" else ress.joinToString(" · ") { zoneText(it) })

        val lines = st.trendLinesAt(i).sortedByDescending { it.score }
        if (lines.isEmpty()) {
            sb.appendLine("• Lignes de tendance : aucune ligne solide")
        } else {
            for (l in lines) {
                val kind = if (l.isSupport) "Ligne de support" else "Ligne de résistance"
                val dir = if (l.slope > 0) "montante" else if (l.slope < 0) "descendante" else "plate"
                sb.appendLine("• $kind $dir : ${l.touches} touches, passe à ${fmt(l.valueAt(i))} maintenant")
            }
        }

        val fib = st.fibAt(i)
        if (fib != null) {
            val leg = if (fib.isUpLeg) "hausse" else "baisse"
            sb.appendLine("• Fibonacci sur la dernière jambe de $leg (${fmt(fib.fromPrice)} → ${fmt(fib.toPrice)}) :")
            sb.appendLine("  " + fib.levels.joinToString(" · ") { "${it.label} ${fmt(it.price)}" })
            val retr = fib.levels.filter { it.ratio <= 1.0 }.sortedBy { it.price }
            val below = retr.lastOrNull { it.price <= last }
            val above = retr.firstOrNull { it.price > last }
            if (below != null && above != null) sb.appendLine("  Le prix est entre ${below.label} et ${above.label}.")
        }

        val patterns = st.chartPatternsAt(i)
        if (patterns.isEmpty()) {
            sb.appendLine("• Figures chartistes : aucune")
        } else {
            for (p in patterns) {
                val bias = when (p.bias) {
                    Side.BUY -> "haussière"
                    Side.SELL -> "baissière"
                    null -> "neutre"
                }
                val extra = buildString {
                    if (p.neckline != null) append(" · ligne de cou ${fmt(p.neckline)}")
                    if (p.target != null) append(" · objectif théorique ${fmt(p.target)}")
                }
                sb.appendLine("• ${p.name} ($bias, ${if (p.confirmed) "confirmée" else "en formation"})$extra")
            }
        }

        val cps = st.candlePatterns(i - 4, i)
        sb.appendLine(
            "• Bougies récentes : " + if (cps.isEmpty()) "rien de notable"
            else cps.joinToString(" · ") { "${it.name} (il y a ${i - it.index} bougie${if (i - it.index > 1) "s" else ""})" }
        )
        sb.appendLine()

        // ---------- Propositions ----------
        sb.appendLine("PROPOSITIONS D'ENTRÉE PAR UNITÉ DE TEMPS")
        sb.appendLine("(plans conditionnels : entrer seulement si le prix atteint la zone ET qu'une bougie de retournement s'y forme)")
        for ((label, x) in views) {
            if (x.lastClosed < 60) continue
            sb.appendLine("▸ $label : " + proposal(x, slAtr, tpAtr, fmt))
        }
        sb.appendLine()

        // ---------- Signal de la stratégie choisie ----------
        sb.appendLine("SIGNAL · ${selected.label} ($timeframe)")
        val sig = a.lastSignal(selected, slAtr, tpAtr)
        if (sig == null) {
            sb.appendLine("• Aucun signal sur la période analysée.")
        } else {
            val t = a.resolve(sig)
            val state = when (t?.outcome) {
                null -> "EN COURS"
                Outcome.TARGET -> "objectif atteint (${r(t.r)})"
                Outcome.STOP -> "stop touché (${r(t.r)})"
                Outcome.TIMEOUT -> "clôturé après ${Analysis.MAX_HOLD} bougies (${r(t.r)})"
            }
            sb.appendLine("• ${sideLabel(sig.side)} il y a ${i - sig.index} bougie(s), le ${dateFmt.format(Date(sig.epoch * 1000))}")
            if (sig.note.isNotEmpty()) sb.appendLine("• Motif : ${sig.note}")
            sb.appendLine("• Entrée ${fmt(sig.entry)} · Stop ${fmt(sig.stop)} · Objectif ${fmt(sig.target)} · statut : $state")
        }
        sb.appendLine()

        // ---------- Tests ----------
        val results = Strategy.values().map { a.backtest(it, slAtr, tpAtr) }
        sb.appendLine("TEST SUR L'HISTORIQUE $timeframe (spread et commissions non inclus)")
        for (res in results) {
            val mark = if (res.strategy == selected) "▶ " else "• "
            if (res.count == 0) {
                sb.appendLine("$mark${res.strategy.label} : aucun trade terminé")
                continue
            }
            val pf = if (res.profitFactor.isInfinite()) "∞" else num(res.profitFactor)
            sb.appendLine(
                "$mark${res.strategy.label} : ${res.count} trades · ${num(res.winRate, 1)} % gagnants · " +
                    "total ${r(res.totalR)} · moyenne ${r(res.avgR)} · PF $pf · pire baisse −${num(res.maxDrawdownR, 1)} R"
            )
        }
        val breakEven = slAtr / (slAtr + tpAtr) * 100
        sb.appendLine("Équilibre à ${num(breakEven, 1)} % de trades gagnants avec ce ratio stop/objectif.")
        val best = results.filter { it.count >= 20 }.maxByOrNull { it.totalR }
        if (best != null && best.totalR > 0) {
            sb.appendLine("Meilleur résultat sur cet échantillon : ${best.strategy.label} (${r(best.totalR)} sur ${best.count} trades).")
        } else {
            sb.appendLine("Aucune stratégie n'est positive sur au moins 20 trades avec ces réglages.")
        }
        sb.appendLine()

        sb.appendLine("À RETENIR")
        sb.appendLine(
            "Supports, lignes de tendance, Fibonacci et figures décrivent où le prix a réagi dans le passé. " +
                "Sur les indices synthétiques, générés par un algorithme aléatoire, ils n'annoncent pas l'avenir : " +
                "ils servent à placer des entrées, des stops et des objectifs cohérents. Un bon résultat sur un " +
                "historique court peut être dû au hasard. Ce rapport n'est pas un conseil financier."
        )
        return sb.toString()
    }

    /** Plan d'entrée pour une unité de temps, à partir de la tendance et des niveaux les plus proches. */
    fun proposal(x: Analysis, slAtr: Double, tpAtr: Double, fmt: (Double) -> String): String {
        val t = x.lastClosed
        val st = x.structure
        val atr = st.atrAt(t)
        if (atr <= 0) return "pas assez de données"
        val price = x.candles.last().close
        val trend = x.trendAt(t)
        val sb = StringBuilder()

        x.signalAt(t, Strategy.PRICE_ACTION, slAtr, tpAtr)?.let { s ->
            sb.append("SIGNAL ACTIF ${sideLabel(s.side)} (${s.note}) : entrée ${fmt(s.entry)}, stop ${fmt(s.stop)}, objectif ${fmt(s.target)}. ")
        }

        val sup = st.supportBelow(t, price)
        val res = st.resistanceAbove(t, price)
        val lines = st.trendLinesAt(t)
        val supLine = lines.filter { it.isSupport && it.valueAt(t) < price }.maxByOrNull { it.valueAt(t) }
        val resLine = lines.filter { !it.isSupport && it.valueAt(t) > price }.minByOrNull { it.valueAt(t) }
        val fib = st.fibAt(t)

        fun rr(entry: Double, stop: Double, target: Double) = abs(target - entry) / max(abs(entry - stop), 1e-12)

        when (trend) {
            1 -> {
                // Niveau d'achat : le plus proche entre la zone de support et la ligne de support
                val zoneLevel = sup?.high
                val lineLevel = supLine?.valueAt(t)
                val entry = listOfNotNull(zoneLevel, lineLevel).maxOrNull()
                if (entry == null) {
                    sb.append("Tendance haussière mais aucun support proche : attendre un repli qui forme un creux.")
                } else {
                    val source = if (entry == zoneLevel) "support ${sup!!.touches} touches" else "ligne de tendance ${supLine!!.touches} touches"
                    val stop = (if (entry == zoneLevel) sup!!.low else entry) - 0.5 * atr
                    val target = res?.low ?: fib?.levels?.firstOrNull { it.ratio == 1.272 && it.price > entry }?.price
                        ?: (entry + (entry - stop) * (tpAtr / slAtr))
                    val ratio = rr(entry, stop, target)
                    sb.append("Biais ACHETEUR. Achat sur repli vers ${fmt(entry)} ($source), stop ${fmt(stop)}, objectif ${fmt(target)}")
                    sb.append(if (res != null) " (résistance)" else "")
                    sb.append(", R:R 1:${num(ratio, 1)}.")
                    if (price - entry <= 0.5 * atr) sb.append(" Le prix est déjà sur la zone : surveiller une bougie haussière.")
                    if (ratio < 1.5 && res != null) sb.append(" R:R faible : mieux vaut attendre une clôture au-dessus de ${fmt(res.high)}.")
                }
            }
            -1 -> {
                val zoneLevel = res?.low
                val lineLevel = resLine?.valueAt(t)
                val entry = listOfNotNull(zoneLevel, lineLevel).minOrNull()
                if (entry == null) {
                    sb.append("Tendance baissière mais aucune résistance proche : attendre un rebond qui forme un sommet.")
                } else {
                    val source = if (entry == zoneLevel) "résistance ${res!!.touches} touches" else "ligne de tendance ${resLine!!.touches} touches"
                    val stop = (if (entry == zoneLevel) res!!.high else entry) + 0.5 * atr
                    val target = sup?.high ?: fib?.levels?.firstOrNull { it.ratio == 1.272 && it.price < entry }?.price
                        ?: (entry - (stop - entry) * (tpAtr / slAtr))
                    val ratio = rr(entry, stop, target)
                    sb.append("Biais VENDEUR. Vente sur rebond vers ${fmt(entry)} ($source), stop ${fmt(stop)}, objectif ${fmt(target)}")
                    sb.append(if (sup != null) " (support)" else "")
                    sb.append(", R:R 1:${num(ratio, 1)}.")
                    if (entry - price <= 0.5 * atr) sb.append(" Le prix est déjà sur la zone : surveiller une bougie baissière.")
                    if (ratio < 1.5 && sup != null) sb.append(" R:R faible : mieux vaut attendre une clôture sous ${fmt(sup.low)}.")
                }
            }
            else -> {
                sb.append("Pas de tendance claire : ")
                val parts = ArrayList<String>()
                if (res != null) parts.add("achat seulement sur clôture au-dessus de ${fmt(res.high)}")
                if (sup != null) parts.add("vente seulement sur clôture sous ${fmt(sup.low)}")
                sb.append(if (parts.isEmpty()) "attendre." else parts.joinToString(", ") + ".")
            }
        }
        return sb.toString()
    }
}
