package com.synthcompanion.app

import android.content.Context
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Enregistrement continu des ticks reçus en direct, un fichier CSV par indice :
 * epoch,date_utc,prix
 */
object Recorder {

    private const val PREFS = "recorder"
    private var writer: BufferedWriter? = null
    private var currentSymbol: String? = null
    private var lastEpoch = -1L
    private var pendingLines = 0

    private val utc = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

    fun formatUtc(epoch: Long): String = utc.format(Date(epoch * 1000))

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", false)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", on).apply()
        if (!on) close()
    }

    fun dir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "enregistrements").apply { mkdirs() }

    fun fileFor(ctx: Context, symbol: String) = File(dir(ctx), "ticks_$symbol.csv")

    fun files(ctx: Context): List<File> = dir(ctx).listFiles { f -> f.name.endsWith(".csv") }?.sortedBy { it.name } ?: emptyList()

    /** Appelé à chaque tick du flux en direct. */
    fun record(ctx: Context, symbol: String, epoch: Long, price: String) {
        if (!isEnabled(ctx)) return
        try {
            if (symbol != currentSymbol || writer == null) {
                close()
                val f = fileFor(ctx, symbol)
                val isNew = !f.exists() || f.length() == 0L
                writer = BufferedWriter(FileWriter(f, true))
                if (isNew) writer!!.write("epoch,date_utc,prix\n")
                currentSymbol = symbol
                lastEpoch = -1L
            }
            if (epoch <= lastEpoch) return
            lastEpoch = epoch
            writer!!.write("$epoch,${formatUtc(epoch)},$price\n")
            if (++pendingLines >= 30) {
                writer!!.flush()
                pendingLines = 0
            }
        } catch (_: Exception) {
            close()
        }
    }

    fun flush() {
        try {
            writer?.flush()
        } catch (_: Exception) {
        }
        pendingLines = 0
    }

    fun close() {
        try {
            writer?.flush()
            writer?.close()
        } catch (_: Exception) {
        }
        writer = null
        currentSymbol = null
        pendingLines = 0
    }

    /** Nombre de lignes de données (sans l'en-tête). */
    fun countLines(f: File): Long = try {
        f.bufferedReader().useLines { seq -> seq.count().toLong() - 1 }.coerceAtLeast(0)
    } catch (_: Exception) {
        0
    }

    fun clear(ctx: Context) {
        close()
        files(ctx).forEach { it.delete() }
    }
}
