package com.synthcompanion.app

import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Labo statistique : vérifie sur l'historique réel si les « règles du trading » (tendance, retour à la
 * moyenne, supports/résistances, figures de bougies, stratégies) fonctionnent mieux que le hasard.
 *
 * Principe : chaque mesure est comparée à ce qu'on obtiendrait sur une série sans mémoire. Un écart
 * significatif répété sur plusieurs périodes et unités de temps serait un indice de structure réelle.
 */
object Lab {

    private fun f(v: Double, d: Int = 2) = String.format(Locale.US, "%.${d}f", v)
    private fun pc(v: Double) = String.format(Locale.US, "%.1f %%", v * 100)

    private class Tally {
        var tests = 0
        var significant = 0
        fun add(z: Double): String {
            tests++
            val a = abs(z)
            return when {
                a >= 3.0 -> { significant++; "ÉCART FORT (z = ${f(z)})" }
                a >= 1.96 -> { significant++; "écart significatif (z = ${f(z)}), à confirmer" }
                else -> "compatible avec le hasard (z = ${f(z)})"
            }
        }
    }

    fun run(
        candles: List<Candle>,
        symbolName: String,
        timeframe: String,
        simulations: Int = 40,
        progress: (String) -> Unit = {},
    ): String {
        val sb = StringBuilder()
        val tally = Tally()
        val n = candles.size
        sb.appendLine("LABO STATISTIQUE · $symbolName · $timeframe")
        sb.appendLine("$n bougies réelles analysées.")
        sb.appendLine("Question : ces prix suivent-ils des règles du trading, ou se comportent-ils comme du hasard ?")
        sb.appendLine("Lecture : « z » mesure l'écart au hasard. Au-delà de 1,96 (ou sous −1,96), l'écart a moins de 5 % de chances d'être dû à la chance.")
        sb.appendLine()

        // 0. Taille des mouvements (la seule récurrence confirmée sur 90 jours)
        val gran = if (n > 2) (1 until minOf(n, 50)).map { (candles[it].epoch - candles[it - 1].epoch).toInt() }.sorted()[minOf(n, 50) / 2 - 1].coerceAtLeast(1) else 60
        val sigma = Prob.realizedVol(candles, gran, n)
        sb.appendLine("0. TAILLE DES MOUVEMENTS (volatilité)")
        if (!sigma.isNaN()) sb.appendLine("• Volatilité mesurée : ${f(sigma * 100, 1)} % par an (annoncée par Deriv : 50 % pour le V50).")
        val dv = Prob.dailyVols(candles, gran)
        if (dv != null) {
            sb.appendLine("• Jour par jour sur ${dv[5].toInt()} jours : de ${f(dv[1] * 100, 1)} % à ${f(dv[2] * 100, 1)} %, écart ${f(dv[3] * 100, 1)} point(s) ; le simple hasard de mesure en donne ${f(dv[4] * 100, 1)}.")
            sb.appendLine(if (dv[3] < dv[4] * 1.5) "→ Volatilité fixe : les journées « calmes » ou « nerveuses » ne sont que du bruit autour du même réglage. C'est la récurrence la plus solide."
            else "→ La volatilité varie plus que le hasard : à surveiller.")
        } else sb.appendLine("• Pas assez de jours complets pour mesurer la volatilité jour par jour (utilise l'historique enregistré).")
        sb.appendLine()

        val a = Analysis(candles)
        val closes = candles.map { it.close }
        val r = (1 until n).map { ln(closes[it] / closes[it - 1]) }

        // 1. Mémoire des mouvements
        progress("Test 1/6 : mémoire des mouvements…")
        sb.appendLine("1. MÉMOIRE DES MOUVEMENTS (autocorrélation)")
        sb.appendLine("Une bougie haussière est-elle plus souvent suivie d'une autre bougie haussière (tendance) ou d'une baissière (retour) ?")
        val band = 1.96 / sqrt(r.size.toDouble())
        for (k in 1..5) {
            val ac = acf(r, k)
            val z = ac * sqrt(r.size.toDouble())
            sb.appendLine("• Décalage $k bougie${if (k > 1) "s" else ""} : ${f(ac, 3)} (seuil ±${f(band, 3)}) → ${tally.add(z)}")
        }
        sb.appendLine()

        // 2. Ratio de variance
        progress("Test 2/6 : tendance ou retour à la moyenne…")
        sb.appendLine("2. TENDANCE OU RETOUR À LA MOYENNE (ratio de variance)")
        sb.appendLine("1,00 = marche au hasard · au-dessus = les mouvements se prolongent · en dessous = ils se corrigent.")
        for (q in listOf(2, 5, 10, 20)) {
            if (r.size < q * 10) continue
            val (vr, z) = varianceRatio(r, q)
            sb.appendLine("• Sur $q bougies : ${f(vr, 3)} → ${tally.add(z)}")
        }
        sb.appendLine()

        // 3. Supports / résistances
        progress("Test 3/6 : supports et résistances…")
        sb.appendLine("3. SUPPORTS ET RÉSISTANCES SONT-ILS RESPECTÉS ?")
        sb.appendLine("À chaque contact avec une zone (≥ 2 touches), on regarde si le prix rebondit d'1 ATR avant de la traverser d'1 ATR. Même mesure sur de faux niveaux placés au hasard.")
        val sr = srTest(a)
        if (sr.realN < 20) {
            sb.appendLine("• Pas assez de contacts (${sr.realN}) pour conclure.")
        } else {
            val zReal = binomZ(sr.realBounce, sr.realN)
            sb.appendLine("• Vrais niveaux : ${sr.realBounce}/${sr.realN} rebonds = ${pc(sr.realBounce.toDouble() / sr.realN)} → ${tally.add(zReal)}")
            if (sr.fakeN >= 20) {
                sb.appendLine("• Faux niveaux (témoin) : ${sr.fakeBounce}/${sr.fakeN} = ${pc(sr.fakeBounce.toDouble() / sr.fakeN)}")
                val zDiff = twoPropZ(sr.realBounce, sr.realN, sr.fakeBounce, sr.fakeN)
                sb.appendLine("• Vrais contre faux niveaux → ${tally.add(zDiff)}")
            }
        }
        sb.appendLine()

        // 4. Figures de bougies
        progress("Test 4/6 : figures de bougies…")
        sb.appendLine("4. LES FIGURES DE BOUGIES ANNONCENT-ELLES LA SUITE ?")
        sb.appendLine("Après chaque figure, le prix va-t-il d'1 ATR dans le sens annoncé avant d'aller d'1 ATR dans l'autre ? Hasard = 50 %.")
        val cps = candleTest(a)
        if (cps.isEmpty()) sb.appendLine("• Aucune figure exploitable.")
        for ((name, pair) in cps.entries.sortedByDescending { it.value.second }) {
            val (win, tot) = pair
            if (tot < 15) {
                sb.appendLine("• $name : seulement $tot cas, trop peu pour conclure")
                continue
            }
            sb.appendLine("• $name : $win/$tot = ${pc(win.toDouble() / tot)} → ${tally.add(binomZ(win, tot))}")
        }
        sb.appendLine()

        // 5 bis. Inversion de polarité
        progress("Test 5/6 : inversion de polarité…")
        sb.appendLine("5. INVERSION DE POLARITÉ (support cassé → résistance, résistance cassée → support)")
        sb.appendLine("Après la cassure d'une zone (≥ 2 touches), au premier retour du prix sur la zone : repart-il de 1 ATR dans le sens de la cassure avant de la retraverser de 1 ATR ? Même mesure sur de faux niveaux.")
        val flips = Polarity.scan(a).filter { it.outcome != 0 }
        val fakeFlips = Polarity.scan(a, shift = { z, atr -> Polarity.fakeShift(z, atr) }).filter { it.outcome != 0 }
        if (flips.size < 20) {
            sb.appendLine("• Pas assez de cassures suivies d'un retour (${flips.size}) pour conclure.")
        } else {
            val held = flips.count { it.outcome > 0 }
            sb.appendLine("• Vrais niveaux cassés : $held/${flips.size} ont tenu au retour = ${pc(held.toDouble() / flips.size)} → ${tally.add(binomZ(held, flips.size))}")
            val upF = flips.filter { it.up }
            val dnF = flips.filter { !it.up }
            if (upF.size >= 10) sb.appendLine("   dont résistances devenues supports : ${upF.count { it.outcome > 0 }}/${upF.size} = ${pc(upF.count { it.outcome > 0 }.toDouble() / upF.size)}")
            if (dnF.size >= 10) sb.appendLine("   dont supports devenus résistances : ${dnF.count { it.outcome > 0 }}/${dnF.size} = ${pc(dnF.count { it.outcome > 0 }.toDouble() / dnF.size)}")
            if (fakeFlips.size >= 20) {
                val fh = fakeFlips.count { it.outcome > 0 }
                sb.appendLine("• Faux niveaux (témoin) : $fh/${fakeFlips.size} = ${pc(fh.toDouble() / fakeFlips.size)}")
                sb.appendLine("• Vrais contre faux niveaux → ${tally.add(twoPropZ(held, flips.size, fh, fakeFlips.size))}")
            }
        }
        sb.appendLine()

        // 5. Stratégies contre séries mélangées
        sb.appendLine("6. LES STRATÉGIES BATTENT-ELLES LE HASARD ?")
        sb.appendLine("On rejoue chaque stratégie sur l'historique réel, puis sur $simulations copies du même historique dont les bougies sont mélangées dans le désordre (mêmes bougies, mais plus aucun ordre, donc plus aucune « règle »).")
        val rnd = Random(12345)
        val strategies = Strategy.values()
        val real = strategies.associateWith { a.backtest(it, 1.5, 3.0) }
        val sims = strategies.associateWith { ArrayList<Double>() }
        for (k in 0 until simulations) {
            progress("Test 6/6 : simulation ${k + 1}/$simulations…")
            val sa = Analysis(shuffled(candles, rnd))
            for (s in strategies) sims[s]!!.add(sa.backtest(s, 1.5, 3.0).totalR)
        }
        for (s in strategies) {
            val res = real[s]!!
            val list = sims[s]!!
            val better = list.count { it >= res.totalR }
            val p = (better + 1).toDouble() / (list.size + 1)
            val mean = list.average()
            val sd = sqrt(list.map { (it - mean) * (it - mean) }.average()).let { if (it == 0.0) 1e-9 else it }
            val z = (res.totalR - mean) / sd
            sb.appendLine(
                "• ${s.label} : réel ${f(res.totalR, 1)} R sur ${res.count} trades · hasard moyen ${f(mean, 1)} R · " +
                    "mieux que ${pc(1 - p)} des séries mélangées → ${tally.add(z)}"
            )
        }
        sb.appendLine()

        // 9. Calibration des probabilités
        progress("Vérification des probabilités…")
        sb.appendLine("9. LES PROBABILITÉS AFFICHÉES SONT-ELLES JUSTES ?")
        var worst = 0.0
        for ((bars, k) in listOf(12 to 1.0, 12 to 0.5, 48 to 1.0)) {
            val secs = bars * gran.toDouble()
            var hit = 0
            var cnt = 0
            var pred = 0.0
            var i = 0
            while (i + bars < n) {
                val p0 = candles[i].close
                val up = cnt % 2 == 0
                val lvl = p0 * exp((if (up) 1 else -1) * k * Prob.sigmaT(0.5, secs))
                pred += Prob.touch(p0, lvl, 0.5, secs)
                cnt++
                for (j in i + 1..i + bars) if (if (up) candles[j].high >= lvl else candles[j].low <= lvl) { hit++; break }
                i += max(1, bars / 3)
            }
            if (cnt == 0) continue
            val pr = pred / cnt
            val ob = hit.toDouble() / cnt
            worst = max(worst, abs(ob - pr))
            sb.appendLine("• Toucher ±${f(k, 1)}σ en $bars bougies : prévu ${pc(pr)}, observé ${pc(ob)} ($cnt essais)")
        }
        sb.appendLine(if (worst < 0.03) "→ Oui (écart maximal ${f(worst * 100, 1)} point). On peut s'y fier pour la taille des mouvements : stops, objectifs, lots."
        else "→ Écart de ${f(worst * 100, 1)} points : à revérifier sur plus de données.")
        sb.appendLine()

        // Conclusion
        val expected = tally.tests * 0.05
        sb.appendLine("CONCLUSION")
        sb.appendLine("${tally.significant} écart(s) significatif(s) sur ${tally.tests} tests.")
        sb.appendLine("Même sur des données purement aléatoires, on s'attend à environ ${f(expected, 1)} faux positif(s) sur autant de tests (5 % chacun).")
        when {
            tally.significant <= max(1.0, expected * 2) -> sb.appendLine(
                "→ Sur cet échantillon, rien ne distingue ces prix du hasard. Les règles testées ne donnent pas d'avantage mesurable."
            )
            else -> sb.appendLine(
                "→ Il y a plus d'écarts que le hasard n'en produit d'habitude. Refais le test sur une autre unité de temps et plus tard " +
                    "(autre période) : une vraie règle doit réapparaître à chaque fois, dans le même sens. Un écart qui disparaît était du bruit."
            )
        }
        sb.appendLine("→ Le sens se comporte comme pile ou face ; la TAILLE des mouvements, elle, est prévisible (tests 0 et 9). " +
            "Écran « Probabilités et radar » pour s'en servir.")
        sb.appendLine()
        sb.appendLine(
            "Rappel : Deriv indique que ces prix sont produits par un processus aléatoire cryptographiquement sûr, " +
                "et que des figures peuvent s'y former naturellement. Ce labo sert à le vérifier toi-même."
        )
        return sb.toString()
    }

    // ---------- Statistiques ----------

    private fun acf(x: List<Double>, k: Int): Double {
        val m = x.average()
        var num = 0.0
        var den = 0.0
        for (i in x.indices) {
            val d = x[i] - m
            den += d * d
            if (i >= k) num += d * (x[i - k] - m)
        }
        return if (den == 0.0) 0.0 else num / den
    }

    /** Lo-MacKinlay, hypothèse homoscédastique. Renvoie (VR, z). */
    private fun varianceRatio(x: List<Double>, q: Int): Pair<Double, Double> {
        val n = x.size
        val m = x.average()
        val var1 = x.sumOf { (it - m) * (it - m) } / (n - 1)
        var sumq = 0.0
        var cnt = 0
        var window = 0.0
        for (i in x.indices) {
            window += x[i]
            if (i >= q) window -= x[i - q]
            if (i >= q - 1) {
                val d = window - q * m
                sumq += d * d
                cnt++
            }
        }
        val varq = sumq / cnt
        val vr = if (var1 == 0.0) 1.0 else varq / (q * var1)
        val se = sqrt(2.0 * (2 * q - 1) * (q - 1) / (3.0 * q * n))
        return vr to (vr - 1) / se
    }

    private fun binomZ(k: Int, n: Int): Double = if (n == 0) 0.0 else (k - 0.5 * n) / sqrt(0.25 * n)

    private fun twoPropZ(k1: Int, n1: Int, k2: Int, n2: Int): Double {
        val p = (k1 + k2).toDouble() / (n1 + n2)
        val se = sqrt(p * (1 - p) * (1.0 / n1 + 1.0 / n2))
        return if (se == 0.0) 0.0 else (k1.toDouble() / n1 - k2.toDouble() / n2) / se
    }

    /** +1 si le prix monte de x avant de baisser de x, −1 dans le cas inverse, 0 si indécis. */
    private fun firstPassage(c: List<Candle>, from: Int, ref: Double, x: Double, maxH: Int): Int {
        for (j in from + 1..minOf(c.size - 1, from + maxH)) {
            val up = c[j].high >= ref + x
            val down = c[j].low <= ref - x
            if (up && down) return 0
            if (up) return 1
            if (down) return -1
        }
        return 0
    }

    private class SrResult(val realBounce: Int, val realN: Int, val fakeBounce: Int, val fakeN: Int)

    private fun srTest(a: Analysis): SrResult {
        val c = a.candles
        val st = a.structure
        val rnd = Random(7)
        var rb = 0; var rn = 0; var fb = 0; var fn = 0
        for (t in 60 until c.size - 1) {
            val atr = st.atrAt(t)
            if (atr <= 0) continue
            val zones = st.zonesAt(t - 1).filter { it.touches >= 2 }
            for (z in zones) {
                val offset = (1.5 + rnd.nextDouble() * 1.5) * atr * (if (rnd.nextBoolean()) 1 else -1)
                for ((low, high, isReal) in listOf(Triple(z.low, z.high, true), Triple(z.low + offset, z.high + offset, false))) {
                    var outcome = 0
                    var event = false
                    if (c[t - 1].low > high && c[t].low <= high && c[t].close >= low) {
                        event = true
                        outcome = firstPassage(c, t, c[t].close, atr, 50) // rebond = hausse
                    } else if (c[t - 1].high < low && c[t].high >= low && c[t].close <= high) {
                        event = true
                        outcome = -firstPassage(c, t, c[t].close, atr, 50) // rebond = baisse
                    }
                    if (!event || outcome == 0) continue
                    if (isReal) { rn++; if (outcome == 1) rb++ } else { fn++; if (outcome == 1) fb++ }
                }
            }
        }
        return SrResult(rb, rn, fb, fn)
    }

    private fun candleTest(a: Analysis): Map<String, Pair<Int, Int>> {
        val c = a.candles
        val st = a.structure
        val out = HashMap<String, Pair<Int, Int>>()
        for (i in 20 until c.size - 1) {
            val cp = st.candlePatternAt(i) ?: continue
            val bias = cp.bias ?: continue
            val atr = st.atrAt(i)
            if (atr <= 0) continue
            val res = firstPassage(c, i, c[i].close, atr, 30)
            if (res == 0) continue
            val ok = (bias == Side.BUY && res == 1) || (bias == Side.SELL && res == -1)
            val prev = out[cp.name] ?: (0 to 0)
            out[cp.name] = (prev.first + if (ok) 1 else 0) to (prev.second + 1)
        }
        return out
    }

    /** Mêmes bougies (forme et taille), ordre mélangé : toute dépendance entre bougies disparaît. */
    fun shuffled(c: List<Candle>, rnd: Random): List<Candle> {
        data class Shape(val oc: Double, val oh: Double, val ol: Double)
        val shapes = c.map { Shape(ln(it.close / it.open), ln(it.high / it.open), ln(it.low / it.open)) }.toMutableList()
        java.util.Collections.shuffle(shapes, rnd)
        val out = ArrayList<Candle>(c.size)
        var p = c.first().open
        for ((i, s) in shapes.withIndex()) {
            val close = p * exp(s.oc)
            out.add(Candle(c[i].epoch, p, p * exp(s.oh), p * exp(s.ol), close))
            p = close
        }
        return out
    }
}
