package com.synthcompanion.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationLog.init(this)
        CandleDb.init(this)
        AiStore.init(this)
        Journal.init(this)
        MarketHub.init(this)
        Notifier.createChannels(this)
    }
}
