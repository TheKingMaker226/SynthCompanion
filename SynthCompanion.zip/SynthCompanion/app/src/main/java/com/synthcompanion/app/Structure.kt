package com.synthcompanion.app

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Sommet ou creux significatif. [confirmIndex] = bougie à laquelle il est devenu certain (pas de regard vers le futur). */
data class Pivot(val index: Int, val price: Double, val isHigh: Boolean, val confirmIndex: Int)

/** Zone de support / résistance issue du regroupement de plusieurs pivots. */
data class Zone(val low: Double, val high: Double, val touches: Int, val lastIndex: Int, val score: Double) {
    val mid: Double get() = (low + high) / 2
}

data class TrendLine(
    val i1: Int, val p1: Double, val i2: Int, val p2: Double,
    val isSupport: Boolean, val touches: Int, val score: Double,
) {
    val slope: Double get() = (p2 - p1) / (i2 - i1)
    fun valueAt(i: Int): Double = p1 + slope * (i - i1)
}

data class FibLevel(val label: String, val ratio: Double, val price: Double)

/** Retracements (0 à 100 %) et extensions (127,2 / 161,8 %) de la dernière jambe entre deux pivots. */
data class FibLevels(val fromIndex: Int, val fromPrice: Double, val toIndex: Int, val toPrice: Double, val levels: List<FibLevel>) {
    val isUpLeg: Boolean get() = toPrice > fromPrice
}

data class Seg(val i1: Int, val p1: Double, val i2: Int, val p2: Double)

data class ChartPattern(
    val name: String,
    val bias: Side?,
    val segments: List<Seg>,
    val neckline: Double?,
    val target: Double?,
    val confirmed: Boolean,
    val lastIndex: Int,
)

data class CandlePattern(val index: Int, val name: String, val code: String, val bias: Side?)

/** Tout ce que le graphique doit dessiner pour les outils d'analyse. */
data class ChartOverlay(
    val zones: List<Zone>,
    val lines: List<TrendLine>,
    val fib: FibLevels?,
    val patterns: List<ChartPattern>,
    val candlePatterns: List<CandlePattern>,
) {
    companion object {
        val EMPTY = ChartOverlay(emptyList(), emptyList(), null, emptyList(), emptyList())
    }
}

/**
 * Analyse de structure (price action). Les pivots viennent d'un ZigZag dont le seuil est un multiple
 * de l'ATR : il s'adapte donc à toutes les unités de temps et à tous les indices.
 * Chaque fonction « …At(t) » n'utilise que l'information connue à la clôture de la bougie t.
 */
class Structure(private val a: Analysis) {

    companion object {
        const val ZZ_K = 2.0
        const val LOOKBACK = 300
        const val MAX_PIVOTS = 12
    }

    private val c = a.candles
    val pivots: List<Pivot>
    /** Extrême en cours, pas encore confirmé. */
    val provisional: Pivot?

    init {
        val list = ArrayList<Pivot>()
        var prov: Pivot? = null
        val n = c.size
        val s = 15
        if (n > s + 2) {
            var dir = 0
            var hiIdx = s
            var loIdx = s
            var ext = s
            for (i in s + 1 until n) {
                val atr = a.atr[i]
                if (atr.isNaN() || atr <= 0) continue
                val th = ZZ_K * atr
                when (dir) {
                    0 -> {
                        if (c[i].high > c[hiIdx].high) hiIdx = i
                        if (c[i].low < c[loIdx].low) loIdx = i
                        if (c[hiIdx].high - c[loIdx].low >= th) {
                            if (hiIdx > loIdx) {
                                list.add(Pivot(loIdx, c[loIdx].low, false, i)); dir = 1; ext = hiIdx
                            } else {
                                list.add(Pivot(hiIdx, c[hiIdx].high, true, i)); dir = -1; ext = loIdx
                            }
                        }
                    }
                    1 -> {
                        if (c[i].high >= c[ext].high) {
                            ext = i
                        } else if (c[ext].high - c[i].low >= th) {
                            list.add(Pivot(ext, c[ext].high, true, i))
                            var lo = ext + 1
                            for (k in ext + 1..i) if (c[k].low < c[lo].low) lo = k
                            ext = lo; dir = -1
                        }
                    }
                    else -> {
                        if (c[i].low <= c[ext].low) {
                            ext = i
                        } else if (c[i].high - c[ext].low >= th) {
                            list.add(Pivot(ext, c[ext].low, false, i))
                            var hi = ext + 1
                            for (k in ext + 1..i) if (c[k].high > c[hi].high) hi = k
                            ext = hi; dir = 1
                        }
                    }
                }
            }
            prov = when (dir) {
                1 -> Pivot(ext, c[ext].high, true, n)
                -1 -> Pivot(ext, c[ext].low, false, n)
                else -> null
            }
        }
        pivots = list
        provisional = prov
    }

    fun atrAt(t: Int): Double {
        val v = a.atr.getOrNull(t) ?: Double.NaN
        if (!v.isNaN() && v > 0) return v
        // Pas encore d'ATR : amplitude moyenne des bougies disponibles
        val from = max(0, t - 13)
        if (t < 0 || t >= c.size) return 0.0
        var sum = 0.0
        for (i in from..t) sum += c[i].high - c[i].low
        return sum / (t - from + 1)
    }

    fun pivotsAt(t: Int): List<Pivot> = pivots.filter { it.confirmIndex <= t && it.index >= t - LOOKBACK }

    // ---------- Supports / résistances ----------

    fun zonesAt(t: Int): List<Zone> {
        val atr = atrAt(t)
        if (atr <= 0) return emptyList()
        val tol = 0.6 * atr
        val ps = pivotsAt(t).sortedBy { it.price }
        val clusters = ArrayList<MutableList<Pivot>>()
        for (p in ps) {
            val last = clusters.lastOrNull()
            if (last != null && abs(p.price - last.map { it.price }.average()) <= tol) last.add(p)
            else clusters.add(mutableListOf(p))
        }
        return clusters.map { cl ->
            val lastIdx = cl.maxOf { it.index }
            val recency = (1.0 - (t - lastIdx).toDouble() / LOOKBACK).coerceIn(0.0, 1.0)
            Zone(cl.minOf { it.price } - 0.15 * atr, cl.maxOf { it.price } + 0.15 * atr, cl.size, lastIdx, cl.size + recency)
        }
    }

    /** Zone la plus proche sous le prix (de préférence touchée au moins 2 fois). */
    fun supportBelow(t: Int, price: Double): Zone? {
        val below = zonesAt(t).filter { it.high < price }
        return (below.filter { it.touches >= 2 }.ifEmpty { below }).maxByOrNull { it.high }
    }

    fun resistanceAbove(t: Int, price: Double): Zone? {
        val above = zonesAt(t).filter { it.low > price }
        return (above.filter { it.touches >= 2 }.ifEmpty { above }).minByOrNull { it.low }
    }

    // ---------- Lignes de tendance ----------

    /** Les 2 lignes de support et les 2 lignes de résistance les plus fortes (touches + longueur), non cassées. */
    fun trendLinesAt(t: Int): List<TrendLine> {
        val atr = atrAt(t)
        if (atr <= 0 || t >= c.size) return emptyList()
        val tol = 0.5 * atr
        val ps = pivotsAt(t)
        val out = ArrayList<TrendLine>()
        for (isHigh in listOf(false, true)) {
            val sub = ps.filter { it.isHigh == isHigh }.takeLast(MAX_PIVOTS)
            val cands = ArrayList<TrendLine>()
            for (x in sub.indices) for (y in x + 1 until sub.size) {
                val p1 = sub[x]
                val p2 = sub[y]
                if (p2.index - p1.index < 5) continue
                val line = TrendLine(p1.index, p1.price, p2.index, p2.price, !isHigh, 0, 0.0)
                // Ligne utile seulement si elle reste proche du prix et n'est pas verticale
                if (abs(line.slope) > 0.5 * atr) continue
                if (abs(line.valueAt(t) - c[t].close) > 6 * atr) continue
                var broken = false
                for (k in p1.index..t) {
                    val v = line.valueAt(k)
                    val cl = c[k].close
                    if ((!isHigh && cl < v - tol) || (isHigh && cl > v + tol)) {
                        broken = true
                        break
                    }
                }
                if (broken) continue
                val touches = sub.count { it.index >= p1.index && abs(it.price - line.valueAt(it.index)) <= tol }
                val length = (t - p1.index).toDouble() / LOOKBACK
                cands.add(line.copy(touches = touches, score = touches * 2.0 + length))
            }
            val chosen = ArrayList<TrendLine>()
            for (l in cands.sortedByDescending { it.score }) {
                if (chosen.none { abs(it.valueAt(t) - l.valueAt(t)) < atr }) chosen.add(l)
                if (chosen.size == 2) break
            }
            out.addAll(chosen)
        }
        return out
    }

    // ---------- Fibonacci ----------

    /** Jambe en cours : du dernier pivot confirmé jusqu'à l'extrême atteint depuis (connu à t). */
    fun fibAt(t: Int): FibLevels? {
        val ps = pivotsAt(t)
        if (ps.isEmpty() || t >= c.size) return null
        val p1 = ps.last()
        var e = -1
        for (k in p1.index + 1..t) {
            if (e < 0 || (p1.isHigh && c[k].low < c[e].low) || (!p1.isHigh && c[k].high > c[e].high)) e = k
        }
        if (e < 0) return null
        val p2 = Pivot(e, if (p1.isHigh) c[e].low else c[e].high, !p1.isHigh, t)
        val range = p2.price - p1.price
        if (range == 0.0) return null
        val levels = ArrayList<FibLevel>()
        for (r in listOf(0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0)) {
            levels.add(FibLevel(String.format(java.util.Locale.US, "%.1f %%", r * 100), r, p2.price - r * range))
        }
        for (r in listOf(1.272, 1.618)) {
            levels.add(FibLevel(String.format(java.util.Locale.US, "ext %.1f %%", r * 100), r, p1.price + r * range))
        }
        return FibLevels(p1.index, p1.price, p2.index, p2.price, levels)
    }

    // ---------- Figures chartistes ----------

    fun chartPatternsAt(t: Int): List<ChartPattern> {
        val atr = atrAt(t)
        if (atr <= 0) return emptyList()
        val ps = pivotsAt(t)
        val out = ArrayList<ChartPattern>()
        fun closedBeyond(from: Int, level: Double, below: Boolean): Boolean {
            for (k in from + 1..t) if (if (below) c[k].close < level else c[k].close > level) return true
            return false
        }
        for (end in listOf(ps.size - 1, ps.size - 2)) {
            if (end < 2) continue
            val x = ps[end - 2]
            val m = ps[end - 1]
            val y = ps[end]
            if (t - y.index > 150) continue
            if (x.isHigh && y.isHigh && abs(x.price - y.price) <= 0.8 * atr && min(x.price, y.price) - m.price >= 2 * atr) {
                val neck = m.price
                val h = (x.price + y.price) / 2 - neck
                out.add(ChartPattern("Double sommet", Side.SELL,
                    listOf(Seg(x.index, x.price, m.index, m.price), Seg(m.index, m.price, y.index, y.price)),
                    neck, neck - h, closedBeyond(y.index, neck, true), y.index))
            }
            if (!x.isHigh && !y.isHigh && abs(x.price - y.price) <= 0.8 * atr && m.price - max(x.price, y.price) >= 2 * atr) {
                val neck = m.price
                val h = neck - (x.price + y.price) / 2
                out.add(ChartPattern("Double creux", Side.BUY,
                    listOf(Seg(x.index, x.price, m.index, m.price), Seg(m.index, m.price, y.index, y.price)),
                    neck, neck + h, closedBeyond(y.index, neck, false), y.index))
            }
            if (end >= 4) {
                val p0 = ps[end - 4]; val p1 = ps[end - 3]; val p2 = ps[end - 2]; val p3 = ps[end - 1]; val p4 = ps[end]
                val neck = TrendLine(p1.index, p1.price, p3.index, p3.price, true, 2, 0.0)
                val segs = listOf(
                    Seg(p0.index, p0.price, p1.index, p1.price), Seg(p1.index, p1.price, p2.index, p2.price),
                    Seg(p2.index, p2.price, p3.index, p3.price), Seg(p3.index, p3.price, p4.index, p4.price),
                )
                if (p0.isHigh && p2.isHigh && p4.isHigh &&
                    p2.price > p0.price + 0.5 * atr && p2.price > p4.price + 0.5 * atr && abs(p0.price - p4.price) <= atr
                ) {
                    val neckNow = neck.valueAt(t)
                    var conf = false
                    for (k in p4.index + 1..t) if (c[k].close < neck.valueAt(k)) { conf = true; break }
                    out.add(ChartPattern("Épaule-tête-épaule", Side.SELL, segs, neckNow,
                        neckNow - (p2.price - neck.valueAt(p2.index)), conf, p4.index))
                }
                if (!p0.isHigh && !p2.isHigh && !p4.isHigh &&
                    p2.price < p0.price - 0.5 * atr && p2.price < p4.price - 0.5 * atr && abs(p0.price - p4.price) <= atr
                ) {
                    val neckNow = neck.valueAt(t)
                    var conf = false
                    for (k in p4.index + 1..t) if (c[k].close > neck.valueAt(k)) { conf = true; break }
                    out.add(ChartPattern("Épaule-tête-épaule inversée", Side.BUY, segs, neckNow,
                        neckNow + (neck.valueAt(p2.index) - p2.price), conf, p4.index))
                }
            }
        }

        // Triangles, biseaux et canaux : deux derniers sommets et deux derniers creux
        val highs = ps.filter { it.isHigh }.takeLast(2)
        val lows = ps.filter { !it.isHigh }.takeLast(2)
        if (highs.size == 2 && lows.size == 2 && t - max(highs[1].index, lows[1].index) <= 100) {
            val dh = highs[1].price - highs[0].price
            val dl = lows[1].price - lows[0].price
            val flat = 0.5 * atr
            val hi = TrendLine(highs[0].index, highs[0].price, highs[1].index, highs[1].price, false, 2, 0.0)
            val lo = TrendLine(lows[0].index, lows[0].price, lows[1].index, lows[1].price, true, 2, 0.0)
            val segs = listOf(
                Seg(hi.i1, hi.p1, t, hi.valueAt(t)),
                Seg(lo.i1, lo.p1, t, lo.valueAt(t)),
            )
            val last = max(highs[1].index, lows[1].index)
            val width = hi.valueAt(t) - lo.valueAt(t)
            val pattern: Pair<String, Side?>? = when {
                width <= 0 -> null
                abs(dh) <= flat && dl > flat -> "Triangle ascendant" to Side.BUY
                abs(dl) <= flat && dh < -flat -> "Triangle descendant" to Side.SELL
                dh < -flat && dl > flat -> "Triangle symétrique" to null
                dh > flat && dl > flat && lo.slope > hi.slope * 1.3 -> "Biseau ascendant" to Side.SELL
                dh < -flat && dl < -flat && hi.slope < lo.slope * 1.3 -> "Biseau descendant" to Side.BUY
                dh > flat && dl > flat -> "Canal haussier" to Side.BUY
                dh < -flat && dl < -flat -> "Canal baissier" to Side.SELL
                else -> null
            }
            if (pattern != null) {
                val broke = c[t].close > hi.valueAt(t) + 0.2 * atr || c[t].close < lo.valueAt(t) - 0.2 * atr
                out.add(ChartPattern(pattern.first, pattern.second, segs, null, null, broke, last))
            }
        }
        return out.sortedByDescending { it.lastIndex }.take(3)
    }

    // ---------- Figures de bougies ----------

    fun candlePatternAt(i: Int): CandlePattern? {
        if (i < 3 || i >= c.size) return null
        val atr = atrAt(i)
        if (atr <= 0) return null
        val k = c[i]
        val p = c[i - 1]
        val pp = c[i - 2]
        fun bull(x: Candle) = x.close > x.open
        fun bear(x: Candle) = x.close < x.open
        fun b(x: Candle) = abs(x.close - x.open)
        val body = b(k)
        val range = k.high - k.low
        if (range <= 0) return null
        val upper = k.high - max(k.open, k.close)
        val lower = min(k.open, k.close) - k.low

        if (bear(pp) && b(pp) >= 0.6 * atr && b(p) <= 0.3 * atr && bull(k) && k.close > (pp.open + pp.close) / 2)
            return CandlePattern(i, "Étoile du matin", "★", Side.BUY)
        if (bull(pp) && b(pp) >= 0.6 * atr && b(p) <= 0.3 * atr && bear(k) && k.close < (pp.open + pp.close) / 2)
            return CandlePattern(i, "Étoile du soir", "★", Side.SELL)
        if (bull(pp) && bull(p) && bull(k) && b(pp) >= 0.5 * atr && b(p) >= 0.5 * atr && body >= 0.5 * atr &&
            p.close > pp.close && k.close > p.close
        ) return CandlePattern(i, "Trois soldats blancs", "3", Side.BUY)
        if (bear(pp) && bear(p) && bear(k) && b(pp) >= 0.5 * atr && b(p) >= 0.5 * atr && body >= 0.5 * atr &&
            p.close < pp.close && k.close < p.close
        ) return CandlePattern(i, "Trois corbeaux noirs", "3", Side.SELL)
        if (bear(p) && bull(k) && k.close >= p.open && k.open <= p.close && body > b(p) && body >= 0.3 * atr)
            return CandlePattern(i, "Englobante haussière", "E", Side.BUY)
        if (bull(p) && bear(k) && k.close <= p.open && k.open >= p.close && body > b(p) && body >= 0.3 * atr)
            return CandlePattern(i, "Englobante baissière", "E", Side.SELL)
        if (range >= 0.5 * atr) {
            if (lower >= 2 * body && lower >= 0.6 * range && upper <= 0.25 * range)
                return CandlePattern(i, "Pin bar haussière (marteau)", "P", Side.BUY)
            if (upper >= 2 * body && upper >= 0.6 * range && lower <= 0.25 * range)
                return CandlePattern(i, "Pin bar baissière (étoile filante)", "P", Side.SELL)
        }
        if (body <= 0.1 * range && range >= 0.3 * atr) return CandlePattern(i, "Doji (indécision)", "D", null)
        if (k.high < p.high && k.low > p.low) return CandlePattern(i, "Inside bar (compression)", "IB", null)
        return null
    }

    fun candlePatterns(from: Int, to: Int): List<CandlePattern> =
        (max(3, from)..min(to, c.size - 1)).mapNotNull { candlePatternAt(it) }

    /** Ce que le graphique affiche : 3 supports sous le prix, 3 résistances au-dessus, etc. */
    fun overlayAt(t: Int, price: Double): ChartOverlay {
        if (t < 20) return ChartOverlay.EMPTY
        val zones = zonesAt(t)
        fun pick(list: List<Zone>) = (list.filter { it.touches >= 2 }.ifEmpty { list }).sortedByDescending { it.score }.take(3)
        val shown = pick(zones.filter { it.mid < price }) + pick(zones.filter { it.mid >= price })
        return ChartOverlay(
            zones = shown,
            lines = trendLinesAt(t),
            fib = fibAt(t),
            patterns = chartPatternsAt(t),
            candlePatterns = candlePatterns(t - LOOKBACK, t),
        )
    }
}
