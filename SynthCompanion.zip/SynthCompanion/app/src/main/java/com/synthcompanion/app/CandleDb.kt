package com.synthcompanion.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/**
 * Base de données sur le téléphone : toutes les bougies M1 des indices suivis.
 * Les autres unités de temps (M5, M15, H1…) sont reconstruites à partir des M1.
 * Toutes les écritures se font sur un fil séparé.
 */
object CandleDb {

    private const val NAME = "bougies.db"
    private lateinit var helper: Helper
    private lateinit var appCtx: Context
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private class Helper(ctx: Context) : SQLiteOpenHelper(ctx, NAME, null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE m1 (symbol TEXT NOT NULL, epoch INTEGER NOT NULL, o REAL NOT NULL, h REAL NOT NULL, " +
                    "l REAL NOT NULL, c REAL NOT NULL, PRIMARY KEY(symbol, epoch)) WITHOUT ROWID"
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    }

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        helper = Helper(appCtx)
    }

    data class Stats(val symbol: String, val count: Long, val first: Long?, val last: Long?)

    /** Exécute [work] sur le fil de la base, puis [done] sur le fil principal. */
    fun <T> async(work: () -> T, done: (T?) -> Unit) {
        executor.execute {
            val r: T? = try { work() } catch (e: Exception) { null }
            main.post { done(r) }
        }
    }

    fun upsert(symbol: String, candles: List<Candle>) {
        if (candles.isEmpty()) return
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val st = db.compileStatement("INSERT OR REPLACE INTO m1 (symbol, epoch, o, h, l, c) VALUES (?, ?, ?, ?, ?, ?)")
            for (k in candles) {
                st.clearBindings()
                st.bindString(1, symbol)
                st.bindLong(2, k.epoch)
                st.bindDouble(3, k.open)
                st.bindDouble(4, k.high)
                st.bindDouble(5, k.low)
                st.bindDouble(6, k.close)
                st.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun lastEpoch(symbol: String): Long? =
        helper.readableDatabase.rawQuery("SELECT MAX(epoch) FROM m1 WHERE symbol = ?", arrayOf(symbol)).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }

    fun stats(symbol: String): Stats =
        helper.readableDatabase.rawQuery("SELECT COUNT(*), MIN(epoch), MAX(epoch) FROM m1 WHERE symbol = ?", arrayOf(symbol)).use { c ->
            c.moveToFirst()
            Stats(symbol, c.getLong(0), if (c.isNull(1)) null else c.getLong(1), if (c.isNull(2)) null else c.getLong(2))
        }

    /** Les [limit] bougies M1 les plus récentes, de la plus ancienne à la plus récente. */
    fun loadRecent(symbol: String, limit: Int): List<Candle> {
        val out = ArrayList<Candle>()
        helper.readableDatabase.rawQuery(
            "SELECT epoch, o, h, l, c FROM (SELECT epoch, o, h, l, c FROM m1 WHERE symbol = ? ORDER BY epoch DESC LIMIT ?) ORDER BY epoch ASC",
            arrayOf(symbol, limit.toString()),
        ).use { c ->
            while (c.moveToNext()) out.add(Candle(c.getLong(0), c.getDouble(1), c.getDouble(2), c.getDouble(3), c.getDouble(4)))
        }
        return out
    }

    fun deleteSymbol(symbol: String) {
        helper.writableDatabase.delete("m1", "symbol = ?", arrayOf(symbol))
    }

    fun sizeBytes(): Long = appCtx.getDatabasePath(NAME).length()
}
