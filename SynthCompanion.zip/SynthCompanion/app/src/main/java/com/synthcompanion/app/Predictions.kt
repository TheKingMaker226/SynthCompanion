package com.synthcompanion.app

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Suivi des prédictions : on fige à un instant ce que prévoient les outils (et ton propre avis),
 * puis on vérifie plus tard si le prix a d'abord monté ou baissé de 1 ATR dans les 50 bougies.
 */
object Predictions {
    const val HORIZON = 50
    const val SHAPE = 30
    const val K = 25

    data class Snap(
        val id: Long,
        val symbol: String,
        val granularity: Int,
        /** Ouverture de la dernière bougie clôturée au moment de la capture. */
        val epoch: Long,
        val price: Double,
        val atr: Double,
        val mode: String,
        /** Avis : +1 hausse, −1 baisse, 0 aucun. */
        val user: Int,
        val trend: Int,
        val rsi: Int,
        val similar: Int,
        val simUp: Int,
        val simDown: Int,
        val note: String,
        /** Résultat : +1 (+1 ATR d'abord), −1 (−1 ATR d'abord), 0 indécis, null en attente. */
        val result: Int? = null,
        val bars: Int? = null,
    )

    val PREDICTORS = listOf("user" to "Ton avis", "similar" to "Formes similaires", "trend" to "Tendance EMA", "rsi" to "RSI extrême")

    fun call(s: Snap, key: String): Int = when (key) {
        "user" -> s.user
        "similar" -> s.similar
        "trend" -> s.trend
        else -> s.rsi
    }

    private lateinit var dir: File
    private val list = ArrayList<Snap>()

    fun init(ctx: Context) {
        dir = File(ctx.filesDir, "snaps").apply { mkdirs() }
        list.clear()
        try {
            val f = File(dir, "snaps.json")
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) fromJson(arr.getJSONObject(i))?.let { list.add(it) }
            }
        } catch (_: Exception) {
        }
    }

    fun all(): List<Snap> = synchronized(list) { list.sortedByDescending { it.id } }

    fun imageFile(s: Snap): File = File(dir, "${s.id}.jpg")

    fun add(s: Snap, image: Bitmap?) {
        synchronized(list) { list.add(s) }
        if (image != null) {
            try {
                imageFile(s).outputStream().use { image.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            } catch (_: Exception) {
            }
        }
        save()
    }

    fun delete(id: Long) {
        synchronized(list) { list.removeAll { it.id == id } }
        File(dir, "$id.jpg").delete()
        save()
    }

    private fun save() {
        val arr = JSONArray()
        synchronized(list) { for (s in list) arr.put(toJson(s)) }
        try {
            File(dir, "snaps.json").writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    private fun toJson(s: Snap) = JSONObject().apply {
        put("id", s.id); put("symbol", s.symbol); put("gran", s.granularity); put("epoch", s.epoch)
        put("price", s.price); put("atr", s.atr); put("mode", s.mode); put("user", s.user); put("trend", s.trend)
        put("rsi", s.rsi); put("similar", s.similar); put("simUp", s.simUp); put("simDown", s.simDown); put("note", s.note)
        if (s.result != null) put("result", s.result)
        if (s.bars != null) put("bars", s.bars)
    }

    private fun fromJson(o: JSONObject): Snap? = try {
        Snap(
            o.getLong("id"), o.getString("symbol"), o.getInt("gran"), o.getLong("epoch"), o.getDouble("price"),
            o.getDouble("atr"), o.optString("mode", "direct"), o.optInt("user"), o.optInt("trend"), o.optInt("rsi"),
            o.optInt("similar"), o.optInt("simUp"), o.optInt("simDown"), o.optString("note"),
            if (o.has("result")) o.getInt("result") else null,
            if (o.has("bars")) o.getInt("bars") else null,
        )
    } catch (_: Exception) {
        null
    }

    // ---------- Prédicteurs ----------

    /** Formes similaires : les K situations passées dont les 30 dernières clôtures ressemblent le plus à la bougie t. */
    fun similar(c: List<Candle>, atr: DoubleArray, t: Int): Pair<Int, Int>? {
        fun vec(i: Int): DoubleArray? {
            val a = atr.getOrNull(i) ?: return null
            if (a.isNaN() || a <= 0 || i < SHAPE) return null
            val ref = c[i].close
            return DoubleArray(SHAPE) { k -> (c[i - SHAPE + 1 + k].close - ref) / a }
        }
        val q = vec(t) ?: return null
        val best = ArrayList<Pair<Int, Double>>()
        for (i in SHAPE + 14 until t - HORIZON) {
            val v = vec(i) ?: continue
            var d = 0.0
            for (k in 0 until SHAPE) { val e = q[k] - v[k]; d += e * e }
            if (best.size < K) { best.add(i to d); best.sortBy { it.second } }
            else if (d < best[K - 1].second) { best[K - 1] = i to d; best.sortBy { it.second } }
        }
        if (best.size < 10) return null
        var up = 0
        var dn = 0
        for ((i, _) in best) {
            when (firstPassage(c, i, c[i].close, atr[i], HORIZON)) {
                1 -> up++
                -1 -> dn++
            }
        }
        return up to dn
    }

    fun firstPassage(c: List<Candle>, from: Int, ref: Double, x: Double, maxH: Int): Int {
        for (j in from + 1..min(c.size - 1, from + maxH)) {
            val u = c[j].high >= ref + x
            val d = c[j].low <= ref - x
            if (u && d) return 0
            if (u) return 1
            if (d) return -1
        }
        return 0
    }

    /** Construit une capture sur la dernière bougie clôturée de [c]. */
    fun build(symbol: String, granularity: Int, c: List<Candle>, mode: String, user: Int, note: String): Snap? {
        if (c.size < 320) return null
        val a = Analysis(c)
        val i = if (mode == "replay") c.size - 1 else c.size - 2
        val atr = a.atr[i]
        if (atr.isNaN() || atr <= 0) return null
        val trend = a.trendAt(i)
        val r = a.rsi[i]
        val rsiCall = when {
            r.isNaN() -> 0
            r > 70 -> -1
            r < 30 -> 1
            else -> 0
        }
        val sim = similar(c, a.atr, i)
        val simCall = if (sim == null || sim.first == sim.second) 0 else if (sim.first > sim.second) 1 else -1
        return Snap(
            System.currentTimeMillis(), symbol, granularity, c[i].epoch, c[i].close, atr, mode, user, trend, rsiCall,
            simCall, sim?.first ?: 0, sim?.second ?: 0, note,
        )
    }

    /** Vérifie la capture avec les bougies [c] (même indice, même unité). Null si la suite n'est pas encore connue. */
    fun evaluate(s: Snap, c: List<Candle>): Snap? {
        val i0 = c.indexOfFirst { it.epoch == s.epoch }
        if (i0 < 0) return null
        val left = c.size - 1 - i0
        val dir = firstPassage(c, i0, s.price, s.atr, HORIZON)
        if (dir == 0 && left < HORIZON + 1) return null
        var bars = 0
        for (j in i0 + 1..min(c.size - 1, i0 + HORIZON)) {
            bars = j - i0
            if (c[j].high >= s.price + s.atr || c[j].low <= s.price - s.atr) break
        }
        return s.copy(result = dir, bars = bars)
    }

    /** Vérifie toutes les captures en attente (sur le fil de la base de données). */
    fun evaluatePending(live: List<Candle>, liveSymbol: String, liveGran: Int, done: (Int) -> Unit) {
        val todo = all().filter { it.result == null }
        if (todo.isEmpty()) {
            done(0)
            return
        }
        CandleDb.async({
            var n = 0
            for (s in todo) {
                var c: List<Candle> = if (s.symbol == liveSymbol && s.granularity == liveGran) live else emptyList()
                if (c.none { it.epoch == s.epoch }) {
                    val need = ((System.currentTimeMillis() / 1000 - s.epoch) / 60).toInt() + 400
                    val m1 = CandleDb.loadRecent(s.symbol, max(500, min(need, 200_000)))
                    c = AiEngine.aggregate(m1, s.granularity)
                }
                val r = evaluate(s, c) ?: continue
                synchronized(list) {
                    val k = list.indexOfFirst { it.id == s.id }
                    if (k >= 0) list[k] = r
                }
                n++
            }
            if (n > 0) save()
            n
        }) { n -> done(n ?: 0) }
    }

    data class Score(val name: String, val ok: Int, val n: Int) {
        val rate: Double get() = if (n == 0) Double.NaN else ok.toDouble() / n
    }

    fun scores(snaps: List<Snap>): List<Score> = PREDICTORS.map { (key, name) ->
        var ok = 0
        var n = 0
        for (s in snaps) {
            val r = s.result ?: continue
            val cl = call(s, key)
            if (cl == 0 || r == 0) continue
            n++
            if (cl == r) ok++
        }
        Score(name, ok, n)
    }
}
