package com.synthcompanion.app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.util.WeakHashMap

/**
 * Plein écran pour le graphique : masque tout ce qui n'est pas le graphique (et les barres système),
 * puis restaure exactement l'affichage précédent.
 */
object ChartFullscreen {

    private val hidden = WeakHashMap<View, List<Pair<View, Int>>>()

    fun isOn(chart: View): Boolean = hidden.containsKey(chart)

    /** [keep] : vues à laisser visibles (ex. boutons du replay). */
    fun set(activity: Activity, chart: ChartView, on: Boolean, keep: Collection<View> = emptyList()) {
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        if (on) {
            if (hidden.containsKey(chart)) return
            val list = ArrayList<Pair<View, Int>>()
            var child: View = chart
            var parent = chart.parent
            while (parent is ViewGroup) {
                for (i in 0 until parent.childCount) {
                    val v = parent.getChildAt(i)
                    if (v !== child && keep.none { it === v }) {
                        list.add(v to v.visibility)
                        v.visibility = View.GONE
                    }
                }
                if (parent.id == android.R.id.content) break
                child = parent
                parent = parent.parent
            }
            hidden[chart] = list
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            hidden.remove(chart)?.forEach { (v, vis) -> v.visibility = vis }
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
        chart.isFullscreen = on
    }
}
