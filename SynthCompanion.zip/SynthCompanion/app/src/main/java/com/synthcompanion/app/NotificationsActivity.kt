package com.synthcompanion.app

import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Centre de notifications : historique de toutes les alertes envoyées par l'appli.
 * L'ouvrir retire les notifications du téléphone, ce qui efface le chiffre sur l'icône.
 */
class NotificationsActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private val fmt = SimpleDateFormat("EEE dd/MM HH:mm:ss", Locale.FRANCE)
    private val refresh: () -> Unit = { runOnUiThread { render() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@NotificationsActivity).apply {
                text = "Notifications"
                textSize = 22f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(color(R.color.text))
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(MaterialButton(this@NotificationsActivity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Tout effacer"
                setOnClickListener {
                    MaterialAlertDialogBuilder(this@NotificationsActivity)
                        .setTitle("Effacer tout l'historique ?")
                        .setPositiveButton("Effacer") { _, _ ->
                            NotificationLog.clear()
                            Notifier.cancelAll(this@NotificationsActivity)
                        }
                        .setNegativeButton("Annuler", null)
                        .show()
                }
            })
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(R.color.bg))
            addView(header)
            addView(TextView(this@NotificationsActivity).apply {
                text = "Touche une notification pour la supprimer."
                textSize = 12f
                setTextColor(color(R.color.muted))
                setPadding(0, dp(2), 0, dp(8))
            })
            addView(ScrollView(this@NotificationsActivity).apply { addView(list) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(14), b.top + dp(8), b.right + dp(14), b.bottom + dp(8))
            insets
        }
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        NotificationLog.addListener(refresh)
        // Vu = lu : retire les notifications du téléphone et la pastille de l'icône
        Notifier.cancelAll(this)
        NotificationLog.markAllRead()
        render()
    }

    override fun onStop() {
        NotificationLog.removeListener(refresh)
        super.onStop()
    }

    private fun render() {
        list.removeAllViews()
        val entries = NotificationLog.all()
        if (entries.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Aucune notification."
                setTextColor(color(R.color.muted))
                setPadding(0, dp(24), 0, 0)
                gravity = Gravity.CENTER
            })
            return
        }
        for (e in entries) {
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(color(R.color.surface))
                setPadding(dp(12), dp(8), dp(12), dp(8))
                addView(TextView(this@NotificationsActivity).apply {
                    text = fmt.format(Date(e.epoch * 1000))
                    textSize = 11f
                    setTextColor(color(R.color.muted))
                })
                addView(TextView(this@NotificationsActivity).apply {
                    text = e.title
                    textSize = 14f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(color(R.color.text))
                })
                if (e.text.isNotBlank()) addView(TextView(this@NotificationsActivity).apply {
                    text = e.text
                    textSize = 12.5f
                    setTextColor(color(R.color.text))
                })
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(6)
                }
                setOnClickListener {
                    MaterialAlertDialogBuilder(this@NotificationsActivity)
                        .setTitle("Supprimer cette notification ?")
                        .setMessage(e.title)
                        .setPositiveButton("Supprimer") { _, _ -> NotificationLog.delete(e.id) }
                        .setNegativeButton("Annuler", null)
                        .show()
                }
            })
        }
    }
}
