package com.synthcompanion.app

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Écran IA : entraîner sur l'historique stocké, voir le verdict hors échantillon, puis la lecture
 * de la situation actuelle. Les signaux en direct ne sont possibles qu'avec un modèle validé.
 */
class AiActivity : AppCompatActivity() {

    companion object {
        /** Dernier entraînement (gardé en mémoire tant que l'appli tourne, pour les motifs similaires). */
        private var lastResult: AiEngine.TrainResult? = null
        private var lastKey: String? = null
        /** Au-delà, on garde les bougies les plus récentes (temps de calcul raisonnable sur téléphone). */
        private const val MAX_CANDLES = 80_000
    }

    private val tfs = listOf("M1" to 60, "M5" to 300, "M15" to 900, "H1" to 3600)
    private lateinit var spSymbol: Spinner
    private lateinit var spTf: Spinner
    private lateinit var tvData: TextView
    private lateinit var results: LinearLayout
    private lateinit var now: LinearLayout
    private lateinit var btnTrain: MaterialButton
    private lateinit var swLive: MaterialSwitch
    private var symbols: List<String> = emptyList()
    private var training = false
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun f(v: Double, d: Int = 2) = String.format(Locale.US, "%.${d}f", v)

    private fun symbol() = symbols.getOrNull(spSymbol.selectedItemPosition) ?: MarketHub.symbol
    private fun gran() = tfs.getOrNull(spTf.selectedItemPosition)?.second ?: 60
    private fun key() = "${symbol()}|${gran()}"

    private fun text(t: CharSequence, size: Float = 13f, col: Int = R.color.text, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color(col))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.2f)
    }

    private fun card(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(color(R.color.surface))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        views.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(text("🤖 IA locale", 22f, bold = true))
        content.addView(text(
            "L'IA apprend sur les bougies stockées sur ton téléphone, puis elle est jugée sur la période la plus récente, " +
                "qu'elle n'a jamais vue. Question posée : « le prix va-t-il monter de 1 ATR avant de baisser de 1 ATR ? ». " +
                "Au hasard, c'est 50 %. Si elle fait nettement mieux sur des données inconnues, c'est qu'il existe un motif récurrent.",
            12.5f, R.color.muted,
        ).apply { setPadding(0, dp(4), 0, dp(8)) })

        symbols = MarketHub.trackedSymbols.sorted()
        spSymbol = Spinner(this).apply {
            adapter = ArrayAdapter(this@AiActivity, android.R.layout.simple_spinner_dropdown_item, symbols.map { MarketHub.symbolInfo(it)?.name ?: it })
            setSelection(symbols.indexOf(MarketHub.symbol).coerceAtLeast(0))
        }
        spTf = Spinner(this).apply {
            adapter = ArrayAdapter(this@AiActivity, android.R.layout.simple_spinner_dropdown_item, tfs.map { it.first })
            setSelection(tfs.indexOfFirst { it.second == MarketHub.granularity }.coerceAtLeast(0))
        }
        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = refreshAll()
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(spSymbol, LinearLayout.LayoutParams(0, dp(48), 2f))
            addView(spTf, LinearLayout.LayoutParams(0, dp(48), 1f))
        })
        tvData = text("", 12.5f, R.color.muted)
        content.addView(tvData)
        btnTrain = MaterialButton(this).apply {
            text = "Entraîner l'IA sur l'historique"
            setOnClickListener { train() }
        }
        content.addView(btnTrain)

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        now = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        content.addView(now)

        swLive = MaterialSwitch(this).apply {
            text = "Signaux IA en direct (seulement si le modèle de l'indice et de l'unité affichés est validé)"
            isChecked = AiStore.liveSignals
            setOnCheckedChangeListener { _, on -> AiStore.liveSignals = on }
            setPadding(0, dp(12), 0, 0)
        }
        content.addView(swLive)
        content.addView(text(
            "Les signaux IA arrivent à la clôture des bougies de l'indice et de l'unité de temps affichés sur l'écran principal. " +
                "Ils utilisent le modèle « situation ». Réentraîne régulièrement (par exemple chaque semaine) pour vérifier que le motif tient dans le temps.",
            11.5f, R.color.muted,
        ).apply { setPadding(0, dp(4), 0, 0) })

        val scroll = ScrollView(this).apply { setBackgroundColor(color(R.color.bg)); addView(content) }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(14), b.top + dp(8), b.right + dp(14), b.bottom + dp(12))
            insets
        }
        setContentView(scroll)
        spSymbol.onItemSelectedListener = listener
        spTf.onItemSelectedListener = listener
        refreshAll()
    }

    private fun refreshAll() {
        val sym = symbol()
        val g = gran()
        CandleDb.async({ CandleDb.stats(sym) }) { st ->
            if (st == null || st.count == 0L) {
                tvData.text = "Aucune bougie stockée pour cet indice. Elles s'enregistrent automatiquement : reviens dans quelques minutes (Menu → Données stockées pour suivre l'avancement)."
            } else {
                val days = ((st.last ?: 0) - (st.first ?: 0)) / 86_400.0
                val atTf = st.count * 60 / g
                tvData.text = "${st.count} bougies M1 stockées (${f(days, 1)} jours) → environ $atTf bougies en ${Timeframes.label(g)}." +
                    if (atTf < 1500) "\n⚠ Il faut au moins 1 500 bougies dans cette unité : récupère plus d'historique ou choisis une unité plus courte." else ""
            }
        }
        showSaved()
        showNow()
    }

    private fun showSaved() {
        results.removeAllViews()
        val r = if (lastKey == key()) lastResult else null
        if (r != null) {
            showResult(r)
            return
        }
        val saved = AiStore.get(symbol(), gran()) ?: run {
            results.addView(card(text("Pas encore de modèle pour cet indice et cette unité de temps.", 13f, R.color.muted)))
            return
        }
        results.addView(card(
            text("Dernier entraînement : ${dateFmt.format(Date(saved.trainedAt))}", 13f, bold = true),
            text(
                "Situation : ${AiEngine.pct(saved.confidentAcc)} sur ${saved.confidentN} cas jamais vus (z = ${f(saved.z)}) → ${if (saved.validated) "✅ validé" else "✘ non validé"}\n" +
                    "Motifs similaires : ${AiEngine.pct(saved.knnAcc)} (z = ${f(saved.knnZ)}) → ${if (saved.knnValidated) "✅ validé" else "✘ non validé"}",
            ),
        ))
    }

    private fun showResult(r: AiEngine.TrainResult) {
        results.removeAllViews()
        fun evalText(e: AiEngine.Eval) =
            "Précision globale : ${AiEngine.pct(e.accuracy)} sur ${e.n} cas\n" +
                "Quand elle est confiante (≥ 55 %) : ${AiEngine.pct(e.confidentAcc)} sur ${e.confidentN} cas\n" +
                "Écart au hasard : z = ${f(e.z)} (validé à partir de ${f(AiEngine.Z_VALID, 1)} et ${AiEngine.MIN_CONFIDENT_TESTS} cas)\n" +
                "Résultat moyen d'un trade stop = objectif = 1 ATR : ${String.format(Locale.US, "%+.3f R", e.avgR)} (avant spread)"
        results.addView(card(
            text("Données", 14f, R.color.accent, true),
            text(
                "${r.candles} bougies · apprentissage sur ${r.trainN} cas, test sur ${r.testN} cas jamais vus " +
                    "(à partir du ${dateFmt.format(Date(r.testStartEpoch * 1000))}).\n" +
                    "Proportion réelle de hausses dans la période de test : ${AiEngine.pct(r.baseRateTest)}",
                12.5f,
            ),
        ))
        for (e in listOf(r.logistic, r.knn)) {
            results.addView(card(
                text("${if (e.validated) "✅" else "✘"}  ${e.name}", 14f, if (e.validated) R.color.up else R.color.text, true),
                text(evalText(e), 12.5f),
            ))
        }
        val top = r.logisticModel.topWeights(4).joinToString(" · ") { "${it.first} (${if (it.second > 0) "+" else "−"})" }
        results.addView(card(
            text("Ce que regarde le plus le modèle « situation »", 13f, bold = true),
            text("$top\n(+ = pousse vers la hausse, − = vers la baisse. Sans validation, ces poids ne veulent rien dire.)", 12f, R.color.muted),
        ))
        val verdict = if (r.anyValidated) {
            "✅ L'IA a trouvé un motif qui tient sur des données qu'elle n'avait jamais vues. " +
                "Ce n'est pas encore une preuve définitive : réentraîne dans une semaine sur les nouvelles données. Si le résultat se répète, le motif est solide. " +
                "Le spread de MT5 réduit le gain affiché."
        } else {
            "✘ Sur cet historique, aucun modèle ne fait mieux que le hasard sur les données jamais vues. " +
                "Autrement dit, l'IA n'a pas trouvé de motif récurrent exploitable. Les signaux IA restent désactivés pour ne pas te tromper. " +
                "Tu peux réessayer avec plus d'historique, une autre unité de temps ou un autre indice."
        }
        results.addView(card(text("Verdict", 15f, R.color.accent, true), text(verdict, 13.5f)))
    }

    private fun train() {
        if (training) return
        val sym = symbol()
        val g = gran()
        training = true
        btnTrain.isEnabled = false
        btnTrain.text = "Chargement des données…"
        Thread {
            val m1 = CandleDb.loadRecent(sym, MAX_CANDLES * (g / 60).coerceAtLeast(1))
            val candles = AiEngine.aggregate(m1, g).takeLast(MAX_CANDLES)
            val r = try {
                AiEngine.trainAndEvaluate(candles) { msg -> runOnUiThread { btnTrain.text = msg } }
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                training = false
                btnTrain.isEnabled = true
                btnTrain.text = "Entraîner l'IA sur l'historique"
                if (isFinishing) return@runOnUiThread
                if (r == null) {
                    toast(if (candles.size < 1500) "Pas assez de données : ${candles.size} bougies en ${Timeframes.label(g)} (minimum 1 500)" else "Entraînement impossible sur ces données")
                    return@runOnUiThread
                }
                lastResult = r
                lastKey = "$sym|$g"
                AiStore.save(sym, g, r)
                showResult(r)
                showNow()
            }
        }.start()
    }

    /** Lecture de la situation actuelle par les modèles disponibles. */
    private fun showNow() {
        now.removeAllViews()
        val sym = symbol()
        val g = gran()
        val saved = AiStore.get(sym, g) ?: return
        val r = if (lastKey == "$sym|$g") lastResult else null
        val live = sym == MarketHub.symbol && g == MarketHub.granularity && MarketHub.candles.size >= 120
        // Copie faite ici, sur le fil principal (la liste en direct change à chaque tick)
        val liveCopy: List<Candle>? = if (live) ArrayList(MarketHub.candles) else null
        val load: () -> List<Candle> = {
            liveCopy ?: AiEngine.aggregate(CandleDb.loadRecent(sym, 400 * (g / 60).coerceAtLeast(1)), g)
        }
        CandleDb.async({
            val candles = load()
            AiEngine.predict(candles, r?.logisticModel ?: saved.model, r?.knnModel) to candles.lastOrNull()
        }) { res ->
            val p = res?.first ?: return@async
            val decimals = (MarketHub.symbolInfo(sym)?.pip ?: 0.01).let { if (it > 0) Math.round(-Math.log10(it)).toInt().coerceIn(0, 6) else 2 }
            fun fp(v: Double) = String.format(Locale.US, "%.${decimals}f", v)
            val lines = StringBuilder()
            lines.append("Probabilité que le prix monte de 1 ATR (${fp(p.atr)}) avant de baisser de 1 ATR, dans les 30 prochaines bougies :\n")
            p.pLogistic?.let { lines.append("• Situation : ${AiEngine.pct(it)} ${if (saved.validated) "(modèle validé)" else "(modèle non validé)"}\n") }
            p.pKnn?.let { lines.append("• Motifs similaires : ${AiEngine.pct(it)} ${if (r?.knn?.validated == true) "(validé)" else "(non validé)"}\n") }
            if (p.pKnn == null) lines.append("• Motifs similaires : réentraîne pour les calculer\n")
            val prob = p.pLogistic ?: 0.5
            val decision = when {
                !saved.validated && r?.knn?.validated != true ->
                    "Pas de décision : aucun modèle validé. Une probabilité proche de 50 % ou non validée ne vaut pas mieux qu'une pièce de monnaie."
                saved.validated && prob >= AiEngine.CONFIDENT ->
                    "Lecture IA : ACHAT. Entrée ≈ ${fp(p.price)}, stop ${fp(p.price - p.atr)}, objectif ${fp(p.price + p.atr)} (1 ATR de chaque côté, la question sur laquelle elle a été validée)."
                saved.validated && prob <= 1 - AiEngine.CONFIDENT ->
                    "Lecture IA : VENTE. Entrée ≈ ${fp(p.price)}, stop ${fp(p.price + p.atr)}, objectif ${fp(p.price - p.atr)}."
                else -> "Pas de signal : la probabilité est entre 45 et 55 %, la situation actuelle n'est pas assez nette."
            }
            now.addView(card(
                text("Situation actuelle${if (live) " (en direct)" else " (dernières bougies stockées)"}", 14f, R.color.accent, true),
                text(lines.toString().trimEnd(), 12.5f),
                text(decision, 13.5f, bold = true).apply { setPadding(0, dp(6), 0, 0) },
            ))
        }
    }
}
