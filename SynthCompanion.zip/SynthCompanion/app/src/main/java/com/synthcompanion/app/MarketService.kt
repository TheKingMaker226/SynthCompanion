package com.synthcompanion.app

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Service de premier plan : garde la connexion ouverte, les alertes actives et la bulle affichée. */
class MarketService : Service(), MarketHub.Listener {

    companion object {
        const val ACTION_STOP = "com.synthcompanion.app.STOP"
        const val ACTION_OVERLAY_ON = "com.synthcompanion.app.OVERLAY_ON"
        const val ACTION_OVERLAY_OFF = "com.synthcompanion.app.OVERLAY_OFF"
        const val ACTION_STOP_ALARM = "com.synthcompanion.app.STOP_ALARM"

        fun start(ctx: Context, action: String? = null) {
            val i = Intent(ctx, MarketService::class.java)
            if (action != null) i.action = action
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, MarketService::class.java))
        }
    }

    private var overlay: OverlayController? = null
    private var lastNotifAt = 0L
    private var lastNotifText = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        goForeground("Connexion à Deriv…")
        MarketHub.addListener(this)
        MarketHub.start()
        if (MarketHub.overlayEnabled) showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Toujours rappeler startForeground : obligatoire après chaque startForegroundService().
        goForeground(notificationText())
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP_ALARM -> AlarmPlayer.stop(this)
            ACTION_OVERLAY_ON -> {
                MarketHub.overlayEnabled = true
                showOverlay()
            }
            ACTION_OVERLAY_OFF -> {
                MarketHub.overlayEnabled = false
                hideOverlay()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        MarketHub.removeListener(this)
        MarketHub.stop()
        AlarmPlayer.stop(this)
        hideOverlay()
        super.onDestroy()
    }

    private fun goForeground(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, Notifier.SERVICE_ID, Notifier.serviceNotification(this, text), type)
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            MarketHub.overlayEnabled = false
            return
        }
        if (overlay == null) {
            overlay = OverlayController(this) {
                MarketHub.overlayEnabled = false
                hideOverlay()
            }.also { it.show() }
        }
        overlay?.update()
    }

    private fun hideOverlay() {
        overlay?.remove()
        overlay = null
    }

    private fun notificationText(): String {
        val price = MarketHub.format(MarketHub.lastPrice)
        return "${MarketHub.shortName()} · ${MarketHub.timeframeLabel()} · $price\n${MarketHub.status}"
            .replace('\n', ' ')
    }

    private fun updateNotification(force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastNotifAt < 5_000) return
        val text = notificationText()
        if (text == lastNotifText) return
        lastNotifAt = now
        lastNotifText = text
        getSystemService(NotificationManager::class.java)
            .notify(Notifier.SERVICE_ID, Notifier.serviceNotification(this, text))
    }

    override fun onData() {
        overlay?.update()
    }

    override fun onTick() {
        overlay?.update()
        updateNotification(false)
    }

    override fun onStatus() {
        updateNotification(true)
    }
}
