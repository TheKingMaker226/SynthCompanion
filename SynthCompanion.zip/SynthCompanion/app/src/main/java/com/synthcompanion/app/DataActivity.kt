package com.synthcompanion.app

import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Données stockées sur le téléphone : indices suivis, couverture, export, historique plus ancien. */
class DataActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private lateinit var tvSync: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
    private var exportFile: File? = null

    private val createCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val f = exportFile ?: return@registerForActivityResult
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            toast("Fichier enregistré")
        } catch (e: Exception) {
            toast("Échec : ${e.message}")
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            tvSync.text = syncText()
            handler.postDelayed(this, 2000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvSync = TextView(this)
        val scroll = ScrollView(this).apply { setBackgroundColor(color(R.color.bg)); addView(content) }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(14), b.top + dp(8), b.right + dp(14), b.bottom + dp(12))
            insets
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    private fun syncText(): String =
        (if (MarketHub.syncing) "⟳ " else "✓ ") + MarketHub.syncInfo + " · base : " + sizeText(CandleDb.sizeBytes())

    private fun sizeText(b: Long) = if (b > 1_000_000) String.format(Locale.US, "%.1f Mo", b / 1e6) else "${b / 1000} Ko"

    private fun text(t: String, size: Float = 13f, col: Int = R.color.text, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color(col))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.15f)
    }

    private fun btn(t: String, outlined: Boolean = true, onClick: () -> Unit) =
        (if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle) else MaterialButton(this)).apply {
            text = t
            textSize = 12f
            setOnClickListener { onClick() }
        }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(6) })
        }
    }

    private fun render() {
        content.removeAllViews()
        content.addView(text("Données stockées", 22f, bold = true))
        content.addView(text(
            "Toutes les bougies M1 des indices suivis sont enregistrées automatiquement dans une base de données sur le téléphone, " +
                "tant que l'appli tourne (même en arrière-plan). Si le téléphone était éteint, les trous sont comblés à la reconnexion. " +
                "M5, M15, H1… sont reconstruites à partir des M1.",
            12.5f, R.color.muted,
        ).apply { setPadding(0, dp(4), 0, dp(6)) })
        tvSync.text = syncText()
        tvSync.textSize = 12.5f
        tvSync.setTextColor(color(R.color.accent))
        content.addView(tvSync)

        val tracked = MarketHub.trackedSymbols.sorted()
        CandleDb.async({ tracked.map { CandleDb.stats(it) } }) { stats ->
            if (isFinishing) return@async
            for (st in stats ?: emptyList()) content.addView(symbolCard(st))
            addFooter()
        }
    }

    private fun addFooter() {
        content.addView(text("Réglages", 15f, R.color.accent, true).apply { setPadding(0, dp(16), 0, dp(4)) })
        content.addView(row(
            btn("+ Suivre un indice", false) { addSymbol() },
            btn("Synchroniser maintenant") {
                MarketHub.syncNow()
                toast(if (MarketHub.connected) "Synchronisation lancée" else "Pas de connexion à Deriv")
            },
        ))
        content.addView(row(
            btn("Historique initial : ${MarketHub.backfillDays} jours") { chooseBackfill() },
        ))
        content.addView(text(
            "Repère de taille : environ 70 Ko par jour et par indice (1 440 bougies M1). 1 an ≈ 25 Mo.",
            11.5f, R.color.muted,
        ).apply { setPadding(0, dp(6), 0, 0) })
    }

    private fun symbolCard(st: CandleDb.Stats): View {
        val name = MarketHub.symbolInfo(st.symbol)?.name ?: st.symbol
        val days = if (st.first != null && st.last != null) (st.last - st.first) / 86_400.0 else 0.0
        val detail = if (st.count == 0L) "Aucune bougie pour l'instant (récupération en cours ou à venir)"
        else "${st.count} bougies M1 · ${String.format(Locale.US, "%.1f", days)} jours\n" +
            "du ${dateFmt.format(Date(st.first!! * 1000))} au ${dateFmt.format(Date(st.last!! * 1000))}"
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(R.color.surface))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(text(name, 15f, bold = true))
            addView(text(detail, 12.5f, R.color.muted))
            addView(row(
                btn("Exporter CSV") { exportSymbol(st.symbol) },
                btn("Plus d'historique") { fetchOlder(st) },
                btn("Ne plus suivre") { untrack(st.symbol) },
            ).apply { setPadding(0, dp(6), 0, 0) })
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
        }
    }

    private fun addSymbol() {
        val candidates = MarketHub.symbols.filter { it.code !in MarketHub.trackedSymbols }
        if (candidates.isEmpty()) {
            toast("Tous les indices sont déjà suivis")
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Suivre un indice")
            .setItems(candidates.map { it.name }.toTypedArray()) { _, which ->
                MarketHub.addTracked(candidates[which].code)
                MarketHub.syncNow()
                render()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun untrack(sym: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Ne plus suivre ${MarketHub.shortName(sym)} ?")
            .setMessage("L'enregistrement s'arrête. Veux-tu aussi effacer les bougies déjà stockées ?")
            .setPositiveButton("Arrêter et effacer") { _, _ ->
                MarketHub.removeTracked(sym)
                CandleDb.async({ CandleDb.deleteSymbol(sym) }) { render() }
            }
            .setNeutralButton("Arrêter, garder les données") { _, _ ->
                MarketHub.removeTracked(sym)
                render()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun chooseBackfill() {
        val choices = intArrayOf(7, 30, 90, 180, 365)
        MaterialAlertDialogBuilder(this)
            .setTitle("Historique récupéré pour un nouvel indice")
            .setItems(choices.map { "$it jours" }.toTypedArray()) { _, which ->
                MarketHub.backfillDays = choices[which]
                render()
            }
            .show()
    }

    /** Remonte plus loin dans le passé que la plus ancienne bougie stockée. */
    private fun fetchOlder(st: CandleDb.Stats) {
        val first = st.first
        if (first == null) {
            MarketHub.syncNow()
            return
        }
        val choices = intArrayOf(7, 30, 90, 180)
        MaterialAlertDialogBuilder(this)
            .setTitle("Récupérer plus d'historique")
            .setItems(choices.map { "$it jours de plus" }.toTypedArray()) { _, which ->
                val days = choices[which]
                val progress = MaterialAlertDialogBuilder(this)
                    .setTitle("Récupération")
                    .setMessage("Téléchargement…")
                    .setCancelable(false)
                    .show()
                MarketHub.fetchCandlesPaged(
                    st.symbol, 60, days * 1440 + 10, { n -> progress.setMessage("$n bougies récupérées…") },
                    stopAtEpoch = first - days * 86_400L, endEpoch = first - 1,
                ) { list ->
                    val older = list?.filter { it.epoch < first } ?: emptyList()
                    if (older.isEmpty()) {
                        progress.dismiss()
                        toast("Deriv n'a pas renvoyé d'historique plus ancien")
                        return@fetchCandlesPaged
                    }
                    CandleDb.async({ CandleDb.upsert(st.symbol, older) }) {
                        progress.dismiss()
                        toast("${older.size} bougies ajoutées")
                        render()
                    }
                }
            }
            .show()
    }

    private fun exportSymbol(sym: String) {
        val tfs = listOf("M1" to 60, "M5" to 300, "M15" to 900, "H1" to 3600, "H4" to 14400, "D1" to 86400)
        MaterialAlertDialogBuilder(this)
            .setTitle("Exporter ${MarketHub.shortName(sym)}")
            .setItems(tfs.map { "En ${it.first}" }.toTypedArray()) { _, which ->
                val (label, gran) = tfs[which]
                val decimals = (MarketHub.symbolInfo(sym)?.pip ?: 0.01).let { if (it > 0) Math.round(-Math.log10(it)).toInt().coerceIn(0, 6) else 2 }
                toast("Préparation du fichier…")
                CandleDb.async({
                    val m1 = CandleDb.loadRecent(sym, 2_000_000)
                    val list = AiEngine.aggregate(m1, gran)
                    val f = File(cacheDir, "${sym}_${label}_${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}.csv")
                    val fmt = "%.${decimals}f"
                    f.bufferedWriter().use { w ->
                        w.write("epoch,date_utc,open,high,low,close\n")
                        for (c in list) {
                            w.write("${c.epoch},${Recorder.formatUtc(c.epoch)},${String.format(Locale.US, fmt, c.open)},${String.format(Locale.US, fmt, c.high)},${String.format(Locale.US, fmt, c.low)},${String.format(Locale.US, fmt, c.close)}\n")
                        }
                    }
                    f to list.size
                }) { res ->
                    if (res == null || res.second == 0) {
                        toast("Aucune donnée à exporter")
                        return@async
                    }
                    exportFile = res.first
                    toast("${res.second} bougies prêtes")
                    createCsv.launch(res.first.name)
                }
            }
            .show()
    }
}
