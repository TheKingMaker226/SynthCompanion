package com.synthcompanion.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Alertes de prix, sauvegardées sur le téléphone. */
object AlertStore {
    private const val KEY = "alerts"
    private lateinit var prefs: SharedPreferences
    private val alerts = ArrayList<PriceAlert>()

    fun init(context: Context) {
        prefs = context.getSharedPreferences("alerts", Context.MODE_PRIVATE)
        alerts.clear()
        val raw = prefs.getString(KEY, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                alerts.add(
                    PriceAlert(
                        id = o.getLong("id"),
                        symbol = o.getString("symbol"),
                        price = o.getDouble("price"),
                        direction = Direction.valueOf(o.getString("direction")),
                        active = o.optBoolean("active", true),
                        alarm = o.optBoolean("alarm", false),
                    )
                )
            }
        } catch (_: Exception) {
            alerts.clear()
        }
    }

    fun all(): List<PriceAlert> = alerts.toList()

    fun activeFor(symbol: String): List<PriceAlert> = alerts.filter { it.active && it.symbol == symbol }

    /** Le sens est déduit du prix actuel : au-dessus → alerte à la hausse, en dessous → à la baisse. */
    fun add(symbol: String, price: Double, currentPrice: Double, alarm: Boolean = false): PriceAlert {
        val direction = if (currentPrice.isNaN() || price >= currentPrice) Direction.ABOVE else Direction.BELOW
        val alert = PriceAlert(System.currentTimeMillis(), symbol, price, direction, alarm = alarm)
        alerts.add(alert)
        save()
        return alert
    }

    fun markTriggered(id: Long) {
        val i = alerts.indexOfFirst { it.id == id }
        if (i >= 0) {
            alerts[i] = alerts[i].copy(active = false)
            save()
        }
    }

    fun remove(id: Long) {
        alerts.removeAll { it.id == id }
        save()
    }

    fun clear() {
        alerts.clear()
        save()
    }

    private fun save() {
        val arr = JSONArray()
        alerts.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("symbol", it.symbol)
                    .put("price", it.price)
                    .put("direction", it.direction.name)
                    .put("active", it.active)
                    .put("alarm", it.alarm)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
