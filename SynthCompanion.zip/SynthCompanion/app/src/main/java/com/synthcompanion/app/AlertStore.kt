package com.synthcompanion.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Alertes de prix, sauvegardées sur le téléphone. */
object AlertStore {
    private const val KEY = "alerts"
    private lateinit var prefs: SharedPreferences
    private val alerts = ArrayList<PriceAlert>()

    fun init(context: Context) {
        prefs = context.getSharedPreferences("alerts", Context.MODE_PRIVATE)
        alerts.clear()
        val raw = prefs.getString(KEY, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                alerts.add(
                    PriceAlert(
                        id = o.getLong("id"),
                        symbol = o.getString("symbol"),
                        price = o.getDouble("price"),
                        direction = Direction.valueOf(o.getString("direction")),
                        active = o.optBoolean("active", true),
                        alarm = o.optBoolean("alarm", false),
                        react = o.optJSONObject("react")?.let { r ->
                            ReactCfg(
                                minutes = r.optInt("minutes", 15),
                                granularity = r.optInt("gran", 60),
                                reversal = r.optBoolean("reversal", true),
                                big = r.optBoolean("big", true),
                                bigAtr = r.optDouble("bigAtr", 1.5),
                                maxBeyond = r.optDouble("maxBeyond", 0.0),
                            )
                        },
                        phase = o.optString("phase", ""),
                        hitAt = o.optLong("hitAt", 0),
                        watchUntil = o.optLong("watchUntil", 0),
                        lastEval = o.optLong("lastEval", 0),
                        maxSeen = o.optDouble("maxSeen", 0.0),
                        result = o.optString("result", ""),
                    )
                )
            }
        } catch (_: Exception) {
            alerts.clear()
        }
    }

    fun all(): List<PriceAlert> = alerts.toList()

    fun activeFor(symbol: String): List<PriceAlert> = alerts.filter { it.active && it.symbol == symbol }

    /** Le sens est déduit du prix actuel : au-dessus → alerte à la hausse, en dessous → à la baisse. */
    fun add(symbol: String, price: Double, currentPrice: Double, alarm: Boolean = false, react: ReactCfg? = null): PriceAlert {
        val direction = if (currentPrice.isNaN() || price >= currentPrice) Direction.ABOVE else Direction.BELOW
        val alert = PriceAlert(System.currentTimeMillis(), symbol, price, direction, alarm = alarm, react = react)
        alerts.add(alert)
        save()
        return alert
    }

    fun markTriggered(id: Long) {
        val i = alerts.indexOfFirst { it.id == id }
        if (i >= 0) {
            alerts[i] = alerts[i].copy(active = false)
            save()
        }
    }

    /** Alertes dont la réaction est en cours de surveillance. */
    fun watching(): List<PriceAlert> = alerts.filter { it.phase == "watch" }

    fun update(a: PriceAlert) {
        val i = alerts.indexOfFirst { it.id == a.id }
        if (i >= 0) {
            alerts[i] = a
            save()
        }
    }

    fun remove(id: Long) {
        alerts.removeAll { it.id == id }
        save()
    }

    fun clear() {
        alerts.clear()
        save()
    }

    private fun save() {
        val arr = JSONArray()
        alerts.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("symbol", it.symbol)
                    .put("price", it.price)
                    .put("direction", it.direction.name)
                    .put("active", it.active)
                    .put("alarm", it.alarm)
                    .put("phase", it.phase)
                    .put("hitAt", it.hitAt)
                    .put("watchUntil", it.watchUntil)
                    .put("lastEval", it.lastEval)
                    .put("maxSeen", it.maxSeen)
                    .put("result", it.result)
                    .put("react", it.react?.let { r ->
                        JSONObject().put("minutes", r.minutes).put("gran", r.granularity).put("reversal", r.reversal)
                            .put("big", r.big).put("bigAtr", r.bigAtr).put("maxBeyond", r.maxBeyond)
                    })
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
