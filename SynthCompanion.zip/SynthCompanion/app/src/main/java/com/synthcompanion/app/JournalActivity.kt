package com.synthcompanion.app

import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Journal de trading : capital fictif, positions, historique, statistiques et conseils. */
class JournalActivity : AppCompatActivity(), MarketHub.Listener {

    companion object {
        /** Ouvre directement la vue « Mes positions » (ouvertes en direct + historique). */
        const val EXTRA_POSITIONS = "positions"
    }

    private lateinit var content: LinearLayout
    private var filter: TradeMode? = null
    private var positionsMode = false
    /** Lignes des positions ouvertes, mises à jour à chaque tick. */
    private val liveRows = LinkedHashMap<Long, Pair<TextView, PaperTrade>>()
    private var shownOpenIds: List<Long> = emptyList()
    private val dateFmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)

    private val exportCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(Journal.toCsv { sym -> decimalsFor(sym) }.toByteArray()) }
            toast("Journal exporté")
        } catch (e: Exception) {
            toast("Échec : ${e.message}")
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun f(v: Double, d: Int = 2) = String.format(Locale.US, "%.${d}f", v)
    private fun rr(v: Double) = String.format(Locale.US, "%+.2f R", v)
    private fun money(v: Double) = String.format(Locale.US, "%+.2f $", v)

    private fun decimalsFor(sym: String): Int {
        val pip = MarketHub.symbolInfo(sym)?.pip ?: 0.01
        return if (pip > 0) Math.round(-Math.log10(pip)).toInt().coerceIn(0, 6) else 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(color(R.color.bg))
            addView(content)
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(14), b.top + dp(8), b.right + dp(14), b.bottom + dp(8))
            insets
        }
        setContentView(scroll)
        positionsMode = intent.getBooleanExtra(EXTRA_POSITIONS, false)
        if (positionsMode) filter = TradeMode.LIVE
    }

    override fun onResume() {
        super.onResume()
        MarketHub.addListener(this)
        render()
    }

    override fun onPause() {
        MarketHub.removeListener(this)
        super.onPause()
    }

    /** Chaque tick : gain/perte des positions ouvertes ; si une position s'est clôturée, tout est redessiné. */
    override fun onData() {
        val openIds = Journal.all().filter { it.isOpen && (filter == null || it.mode == filter) }.map { it.id }
        if (openIds != shownOpenIds) {
            render()
            return
        }
        for ((_, pair) in liveRows) {
            val (tv, t) = pair
            tv.text = openHeader(t)
            val p = MarketHub.lastPrice
            if (t.symbol == MarketHub.symbol && !p.isNaN() && t.mode == TradeMode.LIVE) {
                tv.setTextColor(color(if (t.rAt(p) >= 0) R.color.up else R.color.down))
            }
        }
        liveTotal?.text = totalOpenText()
    }

    private var liveTotal: TextView? = null

    private fun openHeader(t: PaperTrade): String {
        val sens = if (t.side == Side.BUY) "▲ Achat" else "▼ Vente"
        val lot = t.lot?.let { String.format(Locale.US, " %.3f lot", it) } ?: ""
        val now = if (t.symbol == MarketHub.symbol) MarketHub.lastPrice else Double.NaN
        return "$sens$lot ${t.symbol} ${t.timeframe} · " + if (now.isNaN() || t.mode != TradeMode.LIVE) "ouverte (prix indisponible)"
        else String.format(Locale.US, "%+.2f $ (%+.2f R) · prix %s", t.rAt(now) * t.riskAmount, t.rAt(now),
            String.format(Locale.US, "%.${decimalsFor(t.symbol)}f", now))
    }

    private fun totalOpenText(): String {
        val open = Journal.open(TradeMode.LIVE).filter { it.symbol == MarketHub.symbol }
        val p = MarketHub.lastPrice
        if (open.isEmpty() || p.isNaN()) return ""
        return String.format(Locale.US, "Gain/perte en cours : %+.2f $", open.sumOf { it.rAt(p) * it.riskAmount })
    }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(color(R.color.accent))
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun body(t: CharSequence, size: Float = 13f, col: Int = R.color.text) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color(col))
        setLineSpacing(0f, 1.15f)
    }

    private fun button(t: String, outlined: Boolean = true, onClick: () -> Unit) =
        (if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle) else MaterialButton(this)).apply {
            text = t
            textSize = 12f
            setOnClickListener { onClick() }
        }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(6)
            })
        }
    }

    private fun render() {
        content.removeAllViews()
        liveRows.clear()
        liveTotal = null
        shownOpenIds = Journal.all().filter { it.isOpen && (filter == null || it.mode == filter) }.map { it.id }
        if (positionsMode) {
            renderPositions()
            return
        }
        val all = Journal.all()
        val trades = all.filter { filter == null || it.mode == filter }
        val stats = JournalStats(trades, Journal.startBalance)

        // En-tête
        content.addView(body("Journal de trading", 22f).apply { setTypeface(typeface, Typeface.BOLD) })
        val bal = Journal.balance()
        val perf = (bal - Journal.startBalance) / Journal.startBalance * 100
        content.addView(body(
            "Capital fictif : ${f(bal)} $  (${String.format(Locale.US, "%+.1f", perf)} %)\n" +
                "Départ ${f(Journal.startBalance, 0)} $ · risque proposé ${f(Journal.riskPercent, 1)} % par trade" +
                cashSummary(),
            14f,
        ).apply { setPadding(0, dp(4), 0, 0) })

        // Filtre
        fun filterBtn(label: String, m: TradeMode?) = button((if (filter == m) "● " else "") + label, filter != m) {
            filter = m
            render()
        }
        content.addView(row(filterBtn("Tous", null), filterBtn("Direct", TradeMode.LIVE), filterBtn("Replay", TradeMode.REPLAY)).apply {
            setPadding(0, dp(8), 0, 0)
        })

        // Courbe
        content.addView(title("Courbe du capital"))
        content.addView(EquityView(this).apply { setValues(stats.equity, Journal.startBalance) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170)))

        // Chiffres clés
        content.addView(title("Chiffres clés"))
        if (stats.n == 0) {
            content.addView(body("Aucun trade clôturé${if (filter != null) " dans ce mode" else ""}.", 13f, R.color.muted))
        } else {
            val pf = if (stats.profitFactor.isInfinite()) "∞" else f(stats.profitFactor)
            content.addView(body(
                "Trades : ${stats.n} (${stats.wins} gagnants, ${stats.losses} perdants)\n" +
                    "Taux de réussite : ${f(stats.winRate, 1)} %\n" +
                    "Résultat : ${rr(stats.totalR)} · ${money(stats.totalPnl)}\n" +
                    "Moyenne par trade : ${rr(stats.avgR)}\n" +
                    "Gain moyen ${rr(stats.avgWinR)} · perte moyenne ${rr(stats.avgLossR)}\n" +
                    "Facteur de profit : $pf\n" +
                    "Pire baisse du capital : ${f(stats.maxDrawdown)} $\n" +
                    "Plus longue série de pertes : ${stats.maxLosingStreak}"
            ))
        }

        // Conseils
        content.addView(title("Ce que disent tes trades"))
        for (s in stats.insights()) content.addView(body("• $s").apply { setPadding(0, dp(3), 0, dp(3)) })

        // Répartitions
        if (stats.n > 0) {
            fun table(name: String, groups: List<JournalStats.Group>) {
                if (groups.isEmpty()) return
                content.addView(title(name))
                content.addView(body(groups.joinToString("\n") {
                    "${it.name} : ${it.n} trade${if (it.n > 1) "s" else ""} · ${f(it.winRate, 0)} % · moy. ${rr(it.avgR)} · total ${rr(it.totalR)}"
                }))
            }
            table("Par setup", stats.bySetup)
            table("Achats / ventes", stats.bySide)
            table("Par unité de temps", stats.byTimeframe)
            table("Par façon de sortir", stats.byReason)
            table("Par heure d'entrée", stats.byHour.sortedBy { it.name })
            if (filter == null) table("Direct / replay", stats.byMode)
        }

        // Positions ouvertes
        val open = trades.filter { it.isOpen }
        content.addView(title("Positions ouvertes (${open.size})"))
        if (open.isEmpty()) content.addView(body("Aucune.", 13f, R.color.muted))
        for (t in open) content.addView(tradeRow(t))

        // Historique
        val closed = trades.filter { !it.isOpen }.sortedByDescending { it.closeEpoch ?: 0 }
        content.addView(title("Historique (${closed.size})"))
        val movesAll = if (filter == TradeMode.REPLAY) emptyList() else Journal.cashMoves()
        if (closed.isEmpty() && movesAll.isEmpty()) content.addView(body("Aucun trade clôturé.", 13f, R.color.muted))
        val rows: List<Pair<Long, View>> = closed.take(200).map { (it.closeEpoch ?: 0L) to tradeRow(it) } + movesAll.map { it.epoch to moveRow(it) }
        for ((_, v) in rows.sortedByDescending { it.first }) content.addView(v)
        if (closed.size > 200) content.addView(body("… les ${closed.size - 200} plus anciens sont dans l'export CSV.", 12f, R.color.muted))

        // Actions
        content.addView(title("Réglages"))
        content.addView(row(
            button("Exporter CSV") { exportCsv.launch("journal_trading_${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}.csv") },
            button("Capital et risque") { editSettings() },
        ))
        content.addView(row(
            button("Effacer le replay") { confirmReset(TradeMode.REPLAY) },
            button("Tout réinitialiser") { confirmReset(null) },
        ))
    }

    /** Vue simple : capital, positions ouvertes en direct, historique complet. */
    private fun renderPositions() {
        content.addView(body("Mes positions", 22f).apply { setTypeface(typeface, Typeface.BOLD) })
        val bal = Journal.balance()
        content.addView(body("Capital fictif : ${f(bal)} $ · départ ${f(Journal.startBalance, 0)} $" + cashSummary(), 14f).apply { setPadding(0, dp(4), 0, 0) })
        liveTotal = body(totalOpenText(), 15f, R.color.accent).apply { setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(4), 0, 0) }
        content.addView(liveTotal)

        fun filterBtn(label: String, m: TradeMode?) = button((if (filter == m) "● " else "") + label, filter != m) {
            filter = m
            render()
        }
        content.addView(row(filterBtn("Direct", TradeMode.LIVE), filterBtn("Replay", TradeMode.REPLAY), filterBtn("Tous", null)).apply {
            setPadding(0, dp(8), 0, 0)
        })

        val trades = Journal.all().filter { filter == null || it.mode == filter }
        val open = trades.filter { it.isOpen }
        content.addView(title("En cours (${open.size})"))
        if (open.isEmpty()) content.addView(body("Aucune position ouverte. Utilise ACHAT ou VENTE sur l'écran principal.", 13f, R.color.muted))
        for (t in open) content.addView(tradeRow(t))

        val closed = trades.filter { !it.isOpen }.sortedByDescending { it.closeEpoch ?: 0 }
        val totalR = closed.sumOf { it.r }
        val totalPnl = closed.sumOf { it.pnl }
        content.addView(title("Historique (${closed.size}) · ${rr(totalR)} · ${money(totalPnl)}"))
        // Les dépôts / retraits sont intercalés à leur date (ils ne concernent que le direct)
        val moves = if (filter == TradeMode.REPLAY) emptyList() else Journal.cashMoves()
        val items: List<Pair<Long, View>> =
            closed.take(300).map { (it.closeEpoch ?: 0L) to tradeRow(it) } + moves.map { it.epoch to moveRow(it) }
        if (items.isEmpty()) content.addView(body("Aucune position clôturée.", 13f, R.color.muted))
        for ((_, v) in items.sortedByDescending { it.first }) content.addView(v)
        if (closed.size > 300) content.addView(body("… les plus anciennes sont dans l'export CSV (journal complet).", 12f, R.color.muted))

        content.addView(title("Aller plus loin"))
        content.addView(row(
            button("Statistiques et conseils", false) { positionsMode = false; filter = null; render() },
            button("Exporter CSV") { exportCsv.launch("journal_trading_${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}.csv") },
        ))
    }

    private fun cashSummary(): String {
        val dep = Journal.totalDeposits()
        val wd = Journal.totalWithdrawals()
        if (dep == 0.0 && wd == 0.0) return ""
        return "\nDépôts ${f(dep)} $ · retraits ${f(wd)} $ · résultat net des trades ${money(Journal.balance() - Journal.startBalance - dep + wd)}"
    }

    private fun moveRow(m: CashMove): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setBackgroundColor(color(R.color.surface))
        addView(body(
            (if (m.isDeposit) "💵 Dépôt " else "💵 Retrait ") + String.format(Locale.US, "%+.2f $", m.amount),
            13f, R.color.accent,
        ).apply { setTypeface(typeface, Typeface.BOLD) })
        addView(body("${dateFmt.format(Date(m.epoch * 1000))} · ${m.note} · capital après : ${f(m.balanceAfter)} $", 11.5f, R.color.muted))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(6)
        }
    }

    private fun tradeRow(t: PaperTrade): View {
        val d = decimalsFor(t.symbol)
        fun p(v: Double) = String.format(Locale.US, "%.${d}f", v)
        val sens = if (t.side == Side.BUY) "▲ Achat" else "▼ Vente"
        val header: String
        val col: Int
        if (t.isOpen) {
            header = openHeader(t)
            col = R.color.text
        } else {
            header = "$sens ${t.symbol} ${t.timeframe} · ${rr(t.r)} · ${money(t.pnl)}"
            col = if (t.r >= 0) R.color.up else R.color.down
        }
        val detail = "${t.mode.label} · ${dateFmt.format(Date(t.openEpoch * 1000))} · ${t.setup}" +
            (t.lot?.let { " · ${String.format(Locale.US, "%.3f", it)} lot" } ?: "") +
            " · risque ${String.format(Locale.US, "%.2f", t.riskAmount)} $\n" +
            "Entrée ${p(t.entry)} · Stop ${p(t.initialStop ?: t.stop)} · Objectif ${t.target?.let { p(it) } ?: "—"}" +
            (t.exit?.let { " · Sortie ${p(it)} (${t.reason})" } ?: "")
        val headerView = body(header, 13f, col).apply { setTypeface(typeface, Typeface.BOLD) }
        if (t.isOpen) liveRows[t.id] = headerView to t
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(color(R.color.surface))
            addView(headerView)
            addView(body(detail, 11.5f, R.color.muted))
            if (t.note.isNotBlank()) addView(body("« ${t.note} »", 11.5f, R.color.muted))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
            setOnClickListener { tradeActions(t) }
        }
    }

    private fun tradeActions(t: PaperTrade) {
        if (t.isOpen && t.mode == TradeMode.LIVE && t.symbol == MarketHub.symbol && !MarketHub.lastPrice.isNaN()) {
            TradeTicket.manage(this, t, MarketHub.lastPrice, MarketHub.serverNow(), decimalsFor(t.symbol)) { render() }
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Trade ${t.symbol}")
            .setItems(arrayOf("Modifier la note", "Supprimer ce trade")) { _, which ->
                when (which) {
                    0 -> {
                        val et = EditText(this).apply {
                            setText(t.note)
                            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        }
                        MaterialAlertDialogBuilder(this)
                            .setTitle("Note")
                            .setView(LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et) })
                            .setPositiveButton("Enregistrer") { _, _ -> Journal.update(t.copy(note = et.text.toString().trim())); render() }
                            .setNegativeButton("Annuler", null)
                            .show()
                    }
                    1 -> MaterialAlertDialogBuilder(this)
                        .setTitle("Supprimer ce trade ?")
                        .setPositiveButton("Supprimer") { _, _ -> Journal.delete(t.id); render() }
                        .setNegativeButton("Annuler", null)
                        .show()
                }
            }
            .show()
    }

    private fun editSettings() {
        fun et(v: Double, hint: String) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            this.hint = hint
            setText(f(v, 1))
        }
        val etBal = et(Journal.startBalance, "Capital de départ ($)")
        val etRisk = et(Journal.riskPercent, "Risque par trade (%)")
        MaterialAlertDialogBuilder(this)
            .setTitle("Capital et risque")
            .setView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(8), dp(20), 0)
                addView(body("Capital de départ ($)", 12f, R.color.muted)); addView(etBal)
                addView(body("Risque proposé par trade (%)", 12f, R.color.muted)); addView(etRisk)
            })
            .setPositiveButton("Enregistrer") { _, _ ->
                etBal.text.toString().replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 }?.let { Journal.startBalance = it }
                etRisk.text.toString().replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 && it <= 20 }?.let { Journal.riskPercent = it }
                render()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun confirmReset(mode: TradeMode?) {
        MaterialAlertDialogBuilder(this)
            .setTitle(if (mode == null) "Tout réinitialiser ?" else "Effacer les trades du replay ?")
            .setMessage(if (mode == null) "Tous les trades fictifs seront supprimés. Pense à exporter le CSV avant." else "Les trades faits en replay seront supprimés.")
            .setPositiveButton("Effacer") { _, _ -> Journal.reset(mode); render() }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
