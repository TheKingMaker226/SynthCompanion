package com.synthcompanion.app

/** Une bougie OHLC. [epoch] = heure d'ouverture (secondes, heure serveur Deriv). */
data class Candle(
    val epoch: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
)

data class SymbolInfo(val code: String, val name: String, val pip: Double) {
    /** Nom court pour la bulle et les notifications. */
    val shortName: String get() = name.removeSuffix(" Index")

    companion object {
        /** Liste de secours, remplacée par la liste officielle Deriv dès la connexion. */
        val DEFAULTS = listOf(
            SymbolInfo("1HZ10V", "Volatility 10 (1s) Index", 0.01),
            SymbolInfo("1HZ25V", "Volatility 25 (1s) Index", 0.01),
            SymbolInfo("1HZ50V", "Volatility 50 (1s) Index", 0.01),
            SymbolInfo("1HZ75V", "Volatility 75 (1s) Index", 0.01),
            SymbolInfo("1HZ100V", "Volatility 100 (1s) Index", 0.01),
            SymbolInfo("R_10", "Volatility 10 Index", 0.001),
            SymbolInfo("R_25", "Volatility 25 Index", 0.001),
            SymbolInfo("R_50", "Volatility 50 Index", 0.0001),
            SymbolInfo("R_75", "Volatility 75 Index", 0.0001),
            SymbolInfo("R_100", "Volatility 100 Index", 0.01),
        )
    }
}

enum class Direction { ABOVE, BELOW }

data class PriceAlert(
    val id: Long,
    val symbol: String,
    val price: Double,
    val direction: Direction,
    val active: Boolean = true,
    /** Sonner comme un réveil au lieu d'une simple notification. */
    val alarm: Boolean = false,
    /** Alerte en deux temps : surveillance de la réaction après le niveau (null = alerte simple). */
    val react: ReactCfg? = null,
    /** "" (attente du niveau), "watch" (surveillance en cours) ou "done". */
    val phase: String = "",
    val hitAt: Long = 0,
    val watchUntil: Long = 0,
    /** Ouverture de la dernière bougie déjà examinée. */
    val lastEval: Long = 0,
    /** Plus grand dépassement du niveau observé pendant la surveillance (points). */
    val maxSeen: Double = 0.0,
    val result: String = "",
)

/**
 * Réglages de la 2ᵉ alerte : pendant [minutes] après le niveau, sur les bougies [granularity],
 * prévenir si une bougie de retournement (P, E, ★, D) contraire à l'arrivée ou une grosse bougie
 * (corps ≥ [bigAtr] ATR) se forme, tant que le prix n'a pas dépassé le niveau de plus de [maxBeyond] points.
 */
data class ReactCfg(
    val minutes: Int = 15,
    val granularity: Int = 60,
    val reversal: Boolean = true,
    val big: Boolean = true,
    val bigAtr: Double = 1.5,
    val maxBeyond: Double = 0.0,
)

/** Unités de temps acceptées par l'API Deriv (en secondes). */
object Timeframes {
    val list: List<Pair<Int, String>> = listOf(
        60 to "M1", 120 to "M2", 180 to "M3", 300 to "M5", 600 to "M10",
        900 to "M15", 1800 to "M30", 3600 to "H1", 7200 to "H2",
        14400 to "H4", 28800 to "H8", 86400 to "D1",
    )

    fun label(granularity: Int): String =
        list.firstOrNull { it.first == granularity }?.second ?: "${granularity}s"
}

/** Outils de tracé que l'utilisateur peut afficher ou masquer. */
enum class Tool(val label: String, val defaultOn: Boolean) {
    EMA("Moyennes mobiles EMA 20 / 50", true),
    ZONES("Supports et résistances", true),
    TRENDLINES("Lignes de tendance", true),
    FIBONACCI("Retracements de Fibonacci", false),
    PATTERNS("Figures chartistes", true),
    CANDLES("Figures de bougies", true),
    SIGNALS("Signaux d'entrée et trade en cours", true),
    BROKEN("Niveaux cassés en attente de retour", true),
    TREND_BADGE("Badge de tendance", true),
    CONE("Cône de probabilités (±1σ, ±2σ)", true),
}
