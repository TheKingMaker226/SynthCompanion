package com.synthcompanion.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONObject
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Cœur de l'appli : connexion Deriv, bougies en direct, compte à rebours et déclenchement des alertes.
 * Tout l'état est lu et modifié sur le thread principal.
 */
object MarketHub {

    /**
     * Identifiant d'application Deriv. 1089 est l'identifiant de test public :
     * crée le tien gratuitement sur le site développeurs de Deriv et remplace-le ici.
     */
    const val APP_ID = "1089"

    /**
     * Adresses essayées à tour de rôle. La première est l'API publique actuelle de Deriv
     * (données de marché sans compte), la seconde l'ancienne API, gardée en secours.
     */
    private val WS_URLS = listOf(
        "wss://api.derivws.com/trading/v1/options/ws/public",
        "wss://ws.derivws.com/websockets/v3?app_id=$APP_ID",
    )
    private var urlIndex = 0
    private var openedThisAttempt = false

    /** Nombre de décimales renvoyé par Deriv pour chaque symbole (prioritaire sur le pip). */
    private val decimalsBySymbol = HashMap<String, Int>()

    private const val HISTORY_COUNT = 1000
    private const val MAX_CANDLES = 1500
    private const val STALE_MS = 20_000L
    private const val PING_MS = 30_000L

    private const val KEY_SYMBOL = "symbol"
    private const val KEY_GRAN = "granularity"
    private const val KEY_PRECLOSE = "preclose"
    private const val KEY_OVERLAY = "overlay"
    private const val KEY_STRATEGY = "strategy"
    private const val KEY_SL = "sl_atr"
    private const val KEY_TP = "tp_atr"
    private const val KEY_SIGNAL_ALERTS = "signal_alerts"

    interface Listener {
        fun onData() {}
        fun onTick() {}
        fun onStatus() {}
        fun onSymbols() {}
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<Listener>()
    private lateinit var appContext: Context
    private lateinit var prefs: SharedPreferences

    var symbols: List<SymbolInfo> = SymbolInfo.DEFAULTS
        private set
    var symbol: String = "1HZ50V"
        private set
    var granularity: Int = 60
        private set
    val candles = ArrayList<Candle>()
    var lastPrice: Double = Double.NaN
        private set
    var status: String = "Déconnecté"
        private set
    var connected = false
        private set

    var preCloseSeconds: Int
        get() = prefs.getInt(KEY_PRECLOSE, 10)
        set(value) = prefs.edit().putInt(KEY_PRECLOSE, value).apply()

    var overlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY, value).apply()

    var strategy: Strategy
        get() = prefs.getString(KEY_STRATEGY, null)
            ?.let { name -> Strategy.values().firstOrNull { it.name == name } } ?: Strategy.EMA_CROSS
        set(value) = prefs.edit().putString(KEY_STRATEGY, value.name).apply()

    /** Stop, en multiples d'ATR. */
    var slAtr: Double
        get() = prefs.getFloat(KEY_SL, 1.5f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_SL, value.toFloat()).apply()

    /** Objectif, en multiples d'ATR. */
    var tpAtr: Double
        get() = prefs.getFloat(KEY_TP, 3f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_TP, value.toFloat()).apply()

    var signalAlerts: Boolean
        get() = prefs.getBoolean(KEY_SIGNAL_ALERTS, true)
        set(value) = prefs.edit().putBoolean(KEY_SIGNAL_ALERTS, value).apply()

    private var lastSignalEpoch = -1L

    /** Les signaux d'entrée sonnent comme un réveil. */
    var signalAlarm: Boolean
        get() = prefs.getBoolean("signal_alarm", false)
        set(value) = prefs.edit().putBoolean("signal_alarm", value).apply()

    /** Dernier choix « sonnerie » dans la fenêtre de création d'alerte. */
    var lastAlarmChoice: Boolean
        get() = prefs.getBoolean("last_alarm_choice", false)
        set(value) = prefs.edit().putBoolean("last_alarm_choice", value).apply()

    fun toolEnabled(t: Tool): Boolean = prefs.getBoolean("tool_" + t.name, t.defaultOn)

    fun setTool(t: Tool, on: Boolean) = prefs.edit().putBoolean("tool_" + t.name, on).apply()

    /** Requêtes d'historique ponctuelles (rapport, labo, export), par req_id. Reçoivent la réponse brute. */
    private val pending = HashMap<Int, (JSONObject?) -> Unit>()

    /** Envoie une requête ticks_history sans abonnement. [cb] reçoit null en cas d'erreur ou après 30 s. */
    private fun requestHistory(sym: String, style: String, gran: Int, count: Int, end: String, cb: (JSONObject?) -> Unit) {
        if (!connected) {
            cb(null)
            return
        }
        val id = ++reqCounter
        pending[id] = cb
        val req = JSONObject()
            .put("ticks_history", sym)
            .put("style", style)
            .put("count", count)
            .put("end", end)
            .put("adjust_start_time", 1)
            .put("req_id", id)
        if (style == "candles") req.put("granularity", gran)
        send(req)
        main.postDelayed({ pending.remove(id)?.invoke(null) }, 30_000)
    }

    /** Récupère les [count] dernières bougies d'une unité de temps, sans abonnement. */
    fun fetchCandles(sym: String, gran: Int, count: Int, cb: (List<Candle>?) -> Unit) {
        requestHistory(sym, "candles", gran, count, "latest") { json -> cb(json?.let { parseCandles(it) }) }
    }

    /**
     * Remonte l'historique par paquets (5 000 max par requête) jusqu'à [total] bougies.
     * Renvoie ce qui a pu être récupéré (du plus ancien au plus récent), ou null si rien.
     */
    fun fetchCandlesPaged(
        sym: String, gran: Int, total: Int, onProgress: (Int) -> Unit,
        stopAtEpoch: Long? = null, endEpoch: Long? = null, cb: (List<Candle>?) -> Unit,
    ) {
        val acc = ArrayList<Candle>()
        var rounds = 0
        fun step(end: String) {
            rounds++
            requestHistory(sym, "candles", gran, minOf(5000, total - acc.size), end) { json ->
                val batch = json?.let { parseCandles(it) }
                if (batch == null) {
                    cb(acc.ifEmpty { null })
                    return@requestHistory
                }
                val older = batch.filter { acc.isEmpty() || it.epoch < acc.first().epoch }
                acc.addAll(0, older)
                onProgress(acc.size)
                val reached = stopAtEpoch != null && acc.isNotEmpty() && acc.first().epoch <= stopAtEpoch
                if (older.isEmpty() || acc.size >= total || reached || rounds >= 60) cb(acc)
                else step((acc.first().epoch - 1).toString())
            }
        }
        step(endEpoch?.toString() ?: "latest")
    }

    /** Même principe pour les ticks bruts : liste de (epoch, prix). */
    fun fetchTicksPaged(sym: String, total: Int, onProgress: (Int) -> Unit, cb: (List<Pair<Long, Double>>?) -> Unit) {
        val acc = ArrayList<Pair<Long, Double>>()
        var rounds = 0
        fun step(end: String) {
            rounds++
            requestHistory(sym, "ticks", 0, minOf(5000, total - acc.size), end) { json ->
                val hist = json?.optJSONObject("history")
                val prices = hist?.optJSONArray("prices")
                val times = hist?.optJSONArray("times")
                if (prices == null || times == null) {
                    cb(acc.ifEmpty { null })
                    return@requestHistory
                }
                val batch = ArrayList<Pair<Long, Double>>()
                for (i in 0 until minOf(prices.length(), times.length())) {
                    batch.add(times.getLong(i) to prices.getDouble(i))
                }
                val older = batch.filter { acc.isEmpty() || it.first < acc.first().first }
                acc.addAll(0, older)
                onProgress(acc.size)
                if (older.isEmpty() || acc.size >= total || rounds >= 40) cb(acc)
                else step((acc.first().first - 1).toString())
            }
        }
        step("latest")
    }

    private fun parseCandles(json: JSONObject): List<Candle>? {
        val arr = json.optJSONArray("candles") ?: return null
        val out = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            out.add(Candle(c.getLong("epoch"), c.getDouble("open"), c.getDouble("high"), c.getDouble("low"), c.getDouble("close")))
        }
        return out
    }

    private var client: DerivClient? = null
    private var generation = 0
    private var reqCounter = 0
    private var candlesReqId = -1
    private var subscriptionId: String? = null
    private var running = false
    private var retry = 0
    private var lastMessageAt = 0L
    private var serverOffsetMs = 0L
    private var hasOffset = false
    private var armedEpoch = -1L
    private var firedEpoch = -1L

    fun init(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext
        prefs = appContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        symbol = prefs.getString(KEY_SYMBOL, "1HZ50V") ?: "1HZ50V"
        granularity = prefs.getInt(KEY_GRAN, 60)
        AlertStore.init(appContext)
    }

    // ---------- Écouteurs ----------

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    private fun notifyData() = listeners.toList().forEach { it.onData() }
    private fun notifyTick() = listeners.toList().forEach { it.onTick() }
    private fun notifySymbols() = listeners.toList().forEach { it.onSymbols() }
    private fun setStatus(s: String) {
        status = s
        listeners.toList().forEach { it.onStatus() }
    }

    // ---------- Cycle de vie ----------

    fun start() {
        if (running) return
        running = true
        retry = 0
        connect()
        main.removeCallbacks(ticker)
        main.post(ticker)
    }

    private fun failPending() {
        val cbs = pending.values.toList()
        pending.clear()
        cbs.forEach { it(null) }
    }

    fun stop() {
        running = false
        failPending()
        Recorder.close()
        main.removeCallbacks(ticker)
        main.removeCallbacks(reconnectRunnable)
        main.removeCallbacks(pingRunnable)
        main.removeCallbacks(syncRunnable)
        syncing = false
        generation++
        client?.close()
        client = null
        connected = false
        setStatus("Arrêté")
    }

    fun setSymbol(code: String) {
        if (code == symbol) return
        symbol = code
        addTracked(code)
        prefs.edit().putString(KEY_SYMBOL, code).apply()
        subscribeCandles()
    }

    fun setGranularity(seconds: Int) {
        if (seconds == granularity) return
        granularity = seconds
        prefs.edit().putInt(KEY_GRAN, seconds).apply()
        subscribeCandles()
    }

    // ---------- Connexion ----------

    private val reconnectRunnable = Runnable { if (running) connect() }

    private val pingRunnable = object : Runnable {
        override fun run() {
            if (!connected) return
            send(JSONObject().put("ping", 1))
            main.postDelayed(this, PING_MS)
        }
    }

    private fun connect() {
        val gen = ++generation
        client?.close()
        connected = false
        setStatus("Connexion à Deriv…")
        lastMessageAt = SystemClock.elapsedRealtime()
        openedThisAttempt = false
        val c = DerivClient(WS_URLS[urlIndex], object : DerivClient.Listener {
            override fun onOpen() {
                main.post { if (gen == generation) handleOpen() }
            }

            override fun onMessage(text: String) {
                main.post { if (gen == generation) handleMessage(text) }
            }

            override fun onClosed(reason: String) {
                main.post { if (gen == generation) onConnectionLost(reason) }
            }
        })
        client = c
        c.connect()
    }

    private fun handleOpen() {
        connected = true
        openedThisAttempt = true
        retry = 0
        subscriptionId = null
        lastMessageAt = SystemClock.elapsedRealtime()
        setStatus("Connecté")
        send(JSONObject().put("active_symbols", "brief"))
        subscribeCandles()
        main.removeCallbacks(pingRunnable)
        main.postDelayed(pingRunnable, PING_MS)
        // Stockage automatique : complète la base dès la connexion, puis toutes les minutes
        main.removeCallbacks(syncRunnable)
        main.postDelayed(syncRunnable, 3_000)
    }

    private fun onConnectionLost(reason: String) {
        generation++ // ignore tout callback tardif de l'ancienne connexion
        failPending()
        client?.close()
        client = null
        connected = false
        main.removeCallbacks(pingRunnable)
        if (!running) return
        // Si la connexion n'a jamais abouti, on essaie l'autre adresse la prochaine fois.
        if (!openedThisAttempt) urlIndex = (urlIndex + 1) % WS_URLS.size
        val delay = if (!openedThisAttempt && retry < WS_URLS.size) 1 else min(30, 1 shl min(retry, 5))
        retry++
        setStatus("Connexion perdue ($reason) · nouvel essai dans $delay s")
        main.removeCallbacks(reconnectRunnable)
        main.postDelayed(reconnectRunnable, delay * 1000L)
    }

    private fun send(obj: JSONObject) {
        client?.send(obj)
    }

    private fun subscribeCandles() {
        subscriptionId?.let { send(JSONObject().put("forget", it)) }
        subscriptionId = null
        candles.clear()
        lastPrice = Double.NaN
        armedEpoch = -1L
        notifyData()
        if (!connected) return
        val id = ++reqCounter
        candlesReqId = id
        send(
            JSONObject()
                .put("ticks_history", symbol)
                .put("style", "candles")
                .put("granularity", granularity)
                .put("count", HISTORY_COUNT)
                .put("end", "latest")
                .put("adjust_start_time", 1)
                .put("subscribe", 1)
                .put("req_id", id)
        )
    }

    // ---------- Messages ----------

    private fun handleMessage(text: String) {
        lastMessageAt = SystemClock.elapsedRealtime()
        val json = try {
            JSONObject(text)
        } catch (_: Exception) {
            return
        }
        val type = json.optString("msg_type")
        val error = json.optJSONObject("error")
        val rid = json.optInt("req_id", -1)
        if (rid >= 0 && pending.containsKey(rid) && type != "ohlc") {
            val cb = pending.remove(rid)
            cb?.invoke(if (error != null) null else json)
            return
        }
        if (error != null) {
            if (type == "forget" || type == "ping" || type == "active_symbols") return
            setStatus("Erreur Deriv : " + error.optString("message", "inconnue"))
            return
        }
        when (type) {
            "candles" -> onCandles(json)
            "ohlc" -> onOhlc(json)
            "active_symbols" -> onActiveSymbols(json)
        }
    }

    /** La réponse correspond-elle à l'abonnement en cours ? (req_id, ou à défaut la requête renvoyée) */
    private fun isCurrentSubscription(json: JSONObject): Boolean {
        if (json.has("req_id")) return json.optInt("req_id", -1) == candlesReqId
        val echo = json.optJSONObject("echo_req") ?: return true
        val sym = echo.optString("ticks_history")
        if (sym.isNotEmpty() && sym != symbol) return false
        return echo.optInt("granularity", granularity) == granularity
    }

    private fun readDecimals(json: JSONObject) {
        if (!json.has("pip_size")) return
        val v = json.optDouble("pip_size", Double.NaN)
        if (v.isNaN()) return
        // pip_size = nombre de décimales (ex. 2) ; certaines réponses donnent la valeur du pip (ex. 0.01)
        val d = if (v >= 1.0 || v == 0.0) v.roundToInt() else (-log10(v)).roundToInt()
        decimalsBySymbol[symbol] = d.coerceIn(0, 6)
    }

    private fun onCandles(json: JSONObject) {
        if (!isCurrentSubscription(json)) return
        readDecimals(json)
        val list = parseCandles(json) ?: return
        candles.clear()
        candles.addAll(list)
        subscriptionId = json.optJSONObject("subscription")?.optString("id")
        lastPrice = candles.lastOrNull()?.close ?: Double.NaN
        setStatus("En direct · Deriv")
        notifyData()
    }

    private fun onOhlc(json: JSONObject) {
        val o = json.optJSONObject("ohlc") ?: return
        val sym = o.optString("symbol").ifEmpty { o.optString("underlying_symbol") }
        if (sym.isNotEmpty() && sym != symbol) return
        if (o.optInt("granularity", granularity) != granularity) return
        if (!isCurrentSubscription(json)) return

        val epoch = o.getLong("epoch")
        val openTime = if (o.has("open_time")) o.getLong("open_time") else epoch - Math.floorMod(epoch, granularity.toLong())
        updateServerOffset(epoch)

        val c = Candle(
            openTime,
            o.getDouble("open"),
            o.getDouble("high"),
            o.getDouble("low"),
            o.getDouble("close"),
        )
        val last = candles.lastOrNull()
        var candleClosed = false
        when {
            last == null -> candles.add(c)
            last.epoch == openTime -> candles[candles.size - 1] = c
            openTime > last.epoch -> {
                candles.add(c)
                if (candles.size > MAX_CANDLES) candles.subList(0, candles.size - MAX_CANDLES).clear()
                candleClosed = true
            }
            else -> return
        }
        lastPrice = c.close
        Recorder.record(appContext, symbol, epoch, format(c.close))
        for (t in Journal.onLivePrice(symbol, c.close, epoch)) Notifier.paperClosed(appContext, t) { format(it) }
        checkPriceAlerts(c.close)
        if (candleClosed) {
            checkSignal()
            checkAiSignal()
        }
        notifyData()
    }

    private fun onActiveSymbols(json: JSONObject) {
        val arr = json.optJSONArray("active_symbols") ?: return
        val list = ArrayList<SymbolInfo>()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            if (s.optString("market") != "synthetic_index") continue
            val code = s.optString("underlying_symbol").ifEmpty { s.optString("symbol") }
            if (code.isEmpty()) continue
            val name = s.optString("underlying_symbol_name").ifEmpty { s.optString("display_name", code) }
            // Nouvelle API : pip_size ; ancienne : pip. Les deux peuvent être une valeur (0.01) ou un nombre de décimales.
            val raw = if (s.has("pip_size")) s.optDouble("pip_size", 0.01) else s.optDouble("pip", 0.01)
            val pip = if (raw >= 1.0) Math.pow(10.0, -raw) else raw
            list.add(SymbolInfo(code, name, pip))
        }
        if (list.isEmpty()) return
        symbols = list.sortedBy { it.name }
        notifySymbols()
        notifyData()
    }

    /**
     * Décalage entre l'horloge du téléphone et celle du serveur. La latence réseau ne peut que
     * sous-estimer l'heure serveur, on garde donc le maximum observé, avec une lente dérive
     * pour suivre un éventuel changement d'heure du téléphone.
     */
    private fun updateServerOffset(tickEpoch: Long) {
        val sample = tickEpoch * 1000 - System.currentTimeMillis()
        serverOffsetMs = if (!hasOffset) sample else max(sample, serverOffsetMs - 5)
        hasOffset = true
    }

    // ---------- Alertes ----------

    private fun checkPriceAlerts(price: Double) {
        val hit = AlertStore.activeFor(symbol).filter {
            (it.direction == Direction.ABOVE && price >= it.price) ||
                (it.direction == Direction.BELOW && price <= it.price)
        }
        for (a in hit) {
            AlertStore.markTriggered(a.id)
            Notifier.priceAlert(appContext, a, price, shortName(a.symbol), format(a.price), format(price))
            if (a.alarm) {
                val arrow = if (a.direction == Direction.ABOVE) "▲" else "▼"
                AlarmPlayer.start(appContext, "$arrow ${shortName(a.symbol)} a atteint ${format(a.price)}", "Prix actuel : ${format(price)}")
            }
        }
    }

    /** Appelé à chaque clôture de bougie en direct : évalue la stratégie choisie sur la bougie qui vient de fermer. */
    // ---------- Stockage automatique des bougies M1 ----------

    /** Indices dont toutes les bougies M1 sont enregistrées sur le téléphone. */
    val trackedSymbols: Set<String>
        get() = prefs.getStringSet("tracked", null)?.toSet() ?: setOf("1HZ50V", symbol)

    fun addTracked(code: String) {
        prefs.edit().putStringSet("tracked", trackedSymbols + code).apply()
    }

    fun removeTracked(code: String) {
        prefs.edit().putStringSet("tracked", trackedSymbols - code).apply()
    }

    /** Profondeur d'historique récupérée la première fois (en jours). */
    var backfillDays: Int
        get() = prefs.getInt("backfill_days", 30)
        set(v) = prefs.edit().putInt("backfill_days", v).apply()

    var syncInfo: String = "Pas encore synchronisé"
        private set
    var syncing = false
        private set

    private val syncRunnable = object : Runnable {
        override fun run() {
            syncNow()
            main.postDelayed(this, 60_000)
        }
    }

    /** Synchronise tous les indices suivis l'un après l'autre (sans effet si déjà en cours). */
    fun syncNow() {
        if (!connected || syncing) return
        syncing = true
        val list = trackedSymbols.toList()
        fun next(k: Int) {
            if (k >= list.size || !connected) {
                syncing = false
                notifyStatusSilently()
                return
            }
            syncSymbol(list[k]) { next(k + 1) }
        }
        next(0)
    }

    private fun notifyStatusSilently() = listeners.toList().forEach { it.onStatus() }

    private fun syncSymbol(sym: String, done: () -> Unit) {
        CandleDb.async({ CandleDb.lastEpoch(sym) }) { last ->
            val now = serverNow()
            val since = last ?: (now - backfillDays * 86_400L)
            val needed = ((now - since) / 60).toInt() + 2
            if (needed <= 2) {
                done()
                return@async
            }
            if (last == null || needed > 100) syncInfo = "Récupération de l'historique de ${shortName(sym)}…"
            fetchCandlesPaged(sym, 60, minOf(needed, 300_000), { n ->
                if (needed > 100) syncInfo = "Historique ${shortName(sym)} : $n / $needed bougies…"
            }, stopAtEpoch = since) { list ->
                // On n'enregistre que les bougies terminées
                val closed = list?.filter { it.epoch + 60 <= now && (last == null || it.epoch > last) } ?: emptyList()
                if (closed.isEmpty()) {
                    done()
                    return@fetchCandlesPaged
                }
                CandleDb.async({ CandleDb.upsert(sym, closed) }) {
                    syncInfo = "À jour : ${java.text.SimpleDateFormat("HH:mm", java.util.Locale.FRANCE).format(java.util.Date())}"
                    done()
                }
            }
        }
    }

    /**
     * Signal IA à la clôture d'une bougie : seulement si un modèle VALIDÉ hors échantillon existe pour
     * cet indice et cette unité de temps, et si sa probabilité dépasse le seuil de confiance.
     */
    private fun checkAiSignal() {
        if (!AiStore.liveSignals || candles.size < 120) return
        val saved = AiStore.get(symbol, granularity) ?: return
        if (!saved.validated) return
        val p = AiEngine.predict(ArrayList(candles), saved.model, null) ?: return
        val prob = p.pLogistic ?: return
        if (prob < AiEngine.CONFIDENT && prob > 1 - AiEngine.CONFIDENT) return
        val epoch = candles[candles.size - 2].epoch
        if (epoch == AiStore.lastSignalEpoch) return
        AiStore.lastSignalEpoch = epoch
        val buy = prob >= 0.5
        val entry = p.price
        val stop = if (buy) entry - p.atr else entry + p.atr
        val target = if (buy) entry + p.atr else entry - p.atr
        Notifier.aiSignal(
            appContext,
            "🤖 IA : ${if (buy) "ACHAT" else "VENTE"} · ${shortName()} ${timeframeLabel()}",
            "Probabilité ${AiEngine.pct(if (buy) prob else 1 - prob)} · entrée ${format(entry)} · stop ${format(stop)} · objectif ${format(target)}\n" +
                "Modèle validé : ${AiEngine.pct(saved.confidentAcc)} de réussite sur ${saved.confidentN} cas jamais vus (z = ${String.format(java.util.Locale.US, "%.1f", saved.z)})",
        )
        if (signalAlarm) AlarmPlayer.start(appContext, "Signal IA ${if (buy) "ACHAT" else "VENTE"}", "${shortName()} · entrée ${format(entry)}")
    }

    private fun checkSignal() {
        if (!signalAlerts || candles.size < 60) return
        val a = Analysis(ArrayList(candles))
        val s = strategy
        val sig = a.signalAt(a.lastClosed, s, slAtr, tpAtr) ?: return
        if (sig.epoch == lastSignalEpoch) return
        lastSignalEpoch = sig.epoch
        val bt = a.backtest(s, slAtr, tpAtr)
        val history = if (bt.count > 0) {
            String.format(Locale.US, "Historique : %.0f %% gagnants sur %d trades, total %+.1f R", bt.winRate, bt.count, bt.totalR)
        } else "Pas encore d'historique pour cette stratégie"
        val note = if (sig.note.isNotEmpty()) sig.note + "\n" else ""
        Notifier.signal(appContext, sig, shortName(), timeframeLabel(), format(sig.entry), format(sig.stop), format(sig.target), note + history)
        if (signalAlarm) {
            AlarmPlayer.start(
                appContext,
                "Signal ${Report.sideLabel(sig.side)} · ${shortName()} ${timeframeLabel()}",
                "Entrée ${format(sig.entry)} · Stop ${format(sig.stop)} · Objectif ${format(sig.target)}" +
                    if (sig.note.isNotEmpty()) "\n${sig.note}" else "",
            )
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            onSecond()
            val now = System.currentTimeMillis() + serverOffsetMs
            main.postDelayed(this, 1000 - Math.floorMod(now, 1000L) + 20)
        }
    }

    private fun onSecond() {
        if (!running) return
        if (connected && SystemClock.elapsedRealtime() - lastMessageAt > STALE_MS) {
            onConnectionLost("aucune donnée reçue")
        }
        val last = candles.lastOrNull()
        val n = preCloseSeconds
        if (last != null && n > 0 && granularity > n) {
            val rem = remainingSeconds()
            if (rem > n) {
                armedEpoch = last.epoch
            } else if (rem >= 0 && armedEpoch == last.epoch && firedEpoch != last.epoch) {
                firedEpoch = last.epoch
                Notifier.candleClosing(appContext, shortName(symbol), timeframeLabel(), rem)
            }
        }
        notifyTick()
    }

    // ---------- Aides à l'affichage ----------

    /** Heure actuelle du serveur Deriv (secondes). */
    fun serverNow(): Long = (System.currentTimeMillis() + serverOffsetMs) / 1000

    /** ATR 14 de l'unité affichée (0 si pas encore calculable). */
    fun currentAtr(): Double {
        if (candles.size < 20) return 0.0
        val a = Indicators.atr(candles, 14)
        return a.lastOrNull { !it.isNaN() } ?: 0.0
    }

    /** Secondes avant la clôture de la bougie en cours, ou -1 si aucune donnée. */
    fun remainingSeconds(): Int {
        val last = candles.lastOrNull() ?: return -1
        val serverNowMs = System.currentTimeMillis() + serverOffsetMs
        val remMs = (last.epoch + granularity) * 1000 - serverNowMs
        return ceil(remMs / 1000.0).toInt().coerceIn(0, granularity)
    }

    fun formatRemaining(sec: Int): String {
        if (sec < 0) return "--:--"
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun symbolInfo(code: String = symbol): SymbolInfo? = symbols.firstOrNull { it.code == code }

    fun shortName(code: String = symbol): String = symbolInfo(code)?.shortName ?: code

    fun timeframeLabel(): String = Timeframes.label(granularity)

    fun decimals(): Int {
        decimalsBySymbol[symbol]?.let { return it }
        val pip = symbolInfo()?.pip ?: 0.01
        if (pip <= 0.0 || pip.isNaN()) return 2
        return (-log10(pip)).roundToInt().coerceIn(0, 6)
    }

    fun format(v: Double): String =
        if (v.isNaN()) "—" else String.format(Locale.US, "%.${decimals()}f", v)
}
