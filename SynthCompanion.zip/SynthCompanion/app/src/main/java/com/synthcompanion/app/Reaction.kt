package com.synthcompanion.app

import java.util.Locale
import kotlin.math.abs

/**
 * 2ᵉ alerte : après que le prix a atteint un niveau, repère une bougie de retournement (P, E, ★ dans le
 * sens contraire de l'arrivée, ou un doji) ou une grosse bougie (corps ≥ X ATR) qui vient de clôturer.
 */
object Reaction {
    data class Hit(val name: String, val reversal: Boolean)

    /** Dépassement du niveau dans le sens de l'arrivée (points ; positif = au-delà du niveau). */
    fun beyond(a: PriceAlert, high: Double, low: Double): Double =
        if (a.direction == Direction.ABOVE) high - a.price else a.price - low

    fun check(a: PriceAlert, c: List<Candle>, i: Int): Hit? {
        val r = a.react ?: return null
        if (i < 15 || i >= c.size) return null
        val st = Analysis(c).structure
        val atr = st.atrAt(i)
        if (atr <= 0) return null
        // la bougie doit avoir réellement « testé » le niveau (sa mèche est allée jusqu'à moins de 0,5 ATR)
        val tested = if (a.direction == Direction.ABOVE) c[i].high >= a.price - 0.5 * atr else c[i].low <= a.price + 0.5 * atr
        if (r.reversal && tested) {
            val p = st.candlePatternAt(i)
            // arrivée par le bas (alerte ▲) → on attend un retournement baissier, et l'inverse
            val want = if (a.direction == Direction.ABOVE) Side.SELL else Side.BUY
            // un doji ne compte que s'il marque l'extrême des 10 dernières bougies (indécision au sommet / au creux)
            val extreme = if (a.direction == Direction.ABOVE) (i - 10 until i).all { it < 0 || c[it].high <= c[i].high }
            else (i - 10 until i).all { it < 0 || c[it].low >= c[i].low }
            if (p != null && ((p.code == "D" && extreme) || (p.code in setOf("P", "E", "★") && p.bias == want))) return Hit(p.name, true)
        }
        if (r.big) {
            val body = c[i].close - c[i].open
            if (abs(body) >= r.bigAtr * atr) {
                val k = String.format(Locale.FRANCE, "%.1f", abs(body) / atr)
                return Hit("Grosse bougie ${if (body > 0) "haussière" else "baissière"} (corps $k ATR)", false)
            }
        }
        return null
    }
}
