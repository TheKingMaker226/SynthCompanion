package com.synthcompanion.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Historique des notifications envoyées par l'appli, consultable et effaçable dans l'appli. */
object NotificationLog {

    data class Entry(val id: Long, val epoch: Long, val title: String, val text: String)

    private const val MAX = 300
    private var file: File? = null
    private var prefs: SharedPreferences? = null
    private val entries = ArrayList<Entry>()
    private val listeners = LinkedHashSet<() -> Unit>()

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "notifications.json")
        prefs = ctx.getSharedPreferences("notif_log", Context.MODE_PRIVATE)
        entries.clear()
        try {
            val f = file
            if (f != null && f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    entries.add(Entry(o.getLong("id"), o.getLong("epoch"), o.optString("title"), o.optString("text")))
                }
            }
        } catch (_: Exception) {
            entries.clear()
        }
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    fun all(): List<Entry> = entries.sortedByDescending { it.epoch }

    /** Nombre de notifications arrivées depuis la dernière ouverture du centre. */
    fun unread(): Int {
        val seen = prefs?.getLong("seen", 0L) ?: 0L
        return entries.count { it.epoch > seen }
    }

    fun markAllRead() {
        prefs?.edit()?.putLong("seen", System.currentTimeMillis() / 1000)?.apply()
        notifyListeners()
    }

    fun add(title: String, text: String) {
        val now = System.currentTimeMillis()
        entries.add(Entry(now, now / 1000, title, text))
        while (entries.size > MAX) entries.removeAt(0)
        save()
        notifyListeners()
    }

    fun delete(id: Long) {
        entries.removeAll { it.id == id }
        save()
        notifyListeners()
    }

    fun clear() {
        entries.clear()
        save()
        notifyListeners()
    }

    private fun notifyListeners() = listeners.toList().forEach { it() }

    private fun save() {
        val f = file ?: return
        val arr = JSONArray()
        entries.forEach { arr.put(JSONObject().put("id", it.id).put("epoch", it.epoch).put("title", it.title).put("text", it.text)) }
        try {
            f.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }
}
