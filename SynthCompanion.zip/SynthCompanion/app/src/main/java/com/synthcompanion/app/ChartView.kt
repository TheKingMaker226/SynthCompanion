package com.synthcompanion.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Graphique en chandeliers avec EMA 20/50, RSI 14, ligne du dernier prix et niveaux d'alerte. */
class ChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    /** Appelé lors d'un appui long dans la zone de prix, avec le prix sous le doigt. */
    var onLongPressPrice: ((Double) -> Unit)? = null

    /** Bouton plein écran (en haut à droite du graphique). */
    var onFullscreenToggle: (() -> Unit)? = null
    var isFullscreen = false
        set(v) {
            field = v
            invalidate()
        }

    /** Échelle verticale automatique (suit les bougies) ou libre (déplacée / zoomée par l'utilisateur). */
    private var autoScale = true
    private var manLo = 0.0
    private var manHi = 1.0
    private val btnFull = RectF()
    private val btnAuto = RectF()

    private var candles: List<Candle> = emptyList()
    private var ema20 = DoubleArray(0)
    private var ema50 = DoubleArray(0)
    private var rsi = DoubleArray(0)
    private var alertLevels: List<Double> = emptyList()
    private var signals: List<Signal> = emptyList()
    private var activeSignal: Signal? = null
    private var overlay: ChartOverlay = ChartOverlay.EMPTY
    private var openTrades: List<PaperTrade> = emptyList()
    private var closedTrades: List<PaperTrade> = emptyList()

    /** Positions fictives à dessiner (ouvertes : niveaux ; clôturées : trait entrée → sortie). */
    fun setTrades(open: List<PaperTrade>, closed: List<PaperTrade>) {
        openTrades = open
        closedTrades = closed
        invalidate()
    }

    /** Indice de la bougie qui contient cet instant (dernière bougie ouverte avant ou à [epoch]). */
    private fun indexForEpoch(epoch: Long): Int {
        var lo = 0
        var hi = candles.size - 1
        if (hi < 0 || epoch < candles[0].epoch) return -1
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (candles[mid].epoch <= epoch) lo = mid else hi = mid - 1
        }
        return lo
    }
    private var tools: Set<Tool> = Tool.values().filter { it.defaultOn }.toSet()
    private var decimals = 2
    private var granularity = 60
    private var lastSize = 0

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var candleWidth = dp(8f)

    /** Largeur d'une bougie en pixels (zoom), conservée lors d'une rotation. */
    var zoom: Float
        get() = candleWidth
        set(value) {
            candleWidth = value.coerceIn(dp(2f), dp(40f))
            invalidate()
        }
    /** Nombre de bougies masquées à droite (0 = collé au direct). */
    private var offset = 0f
    private val axisW = dp(66f)
    private val timeH = dp(18f)

    // Dernière géométrie dessinée (pour convertir un appui en prix)
    private var drawnLo = 0.0
    private var drawnHi = 1.0
    private var drawnTop = 0f
    private var drawnBottom = 1f

    private val colBg = Color.parseColor("#0E1117")
    private val colGrid = Color.parseColor("#1F2630")
    private val colText = Color.parseColor("#8B949E")
    private val colUp = Color.parseColor("#26A69A")
    private val colDown = Color.parseColor("#EF5350")
    private val colEma20 = Color.parseColor("#F0B90B")
    private val colEma50 = Color.parseColor("#4DA3FF")
    private val colRsi = Color.parseColor("#B388FF")
    private val colAlert = Color.parseColor("#FF9800")

    private val gridPaint = Paint().apply { color = colGrid; strokeWidth = dp(1f) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colText; textSize = dp(10f) }
    private val legendPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(11f) }
    private val candlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = max(1f, dp(1f)) }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.4f)
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        pathEffect = DashPathEffect(floatArrayOf(dp(4f), dp(4f)), 0f)
    }
    private val labelBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val zonePaint = Paint().apply { style = Paint.Style.FILL }
    private val buttonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val buttonText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = dp(16f) }
    private val buttonSmall = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F0B90B"); textSize = dp(11f); isFakeBoldText = true }
    private val tradePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = dp(1.6f) }
    private val trendPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = dp(1.5f) }
    private val patternPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = dp(1.5f) }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(9f); isFakeBoldText = true }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(10.5f); isFakeBoldText = true }
    private val colZoneSup = Color.argb(40, 38, 166, 154)
    private val colZoneRes = Color.argb(40, 239, 83, 80)
    private val colFib = Color.parseColor("#9AA7FF")
    private val labelTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = dp(10f)
        isFakeBoldText = true
    }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colText
        textSize = dp(13f)
        textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val rect = RectF()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dayFmt = SimpleDateFormat("dd/MM", Locale.getDefault())

    /** [analysis] doit avoir été calculée sur la même liste que [list]. */
    fun setData(
        list: List<Candle>, decimals: Int, granularity: Int, alerts: List<Double>,
        analysis: Analysis, signals: List<Signal>, active: Signal?,
        overlay: ChartOverlay, tools: Set<Tool>,
    ) {
        if (list.size < lastSize || granularity != this.granularity) {
            offset = 0f
        } else if (offset > 0f && list.size > lastSize) {
            offset += (list.size - lastSize).toFloat() // garde la vue immobile quand on regarde l'historique
        }
        lastSize = list.size
        candles = list
        this.decimals = decimals
        this.granularity = granularity
        alertLevels = alerts
        ema20 = analysis.ema20
        ema50 = analysis.ema50
        rsi = analysis.rsi
        this.signals = signals
        activeSignal = active
        this.overlay = overlay
        this.tools = tools
        invalidate()
    }

    private fun fmt(v: Double) = String.format(Locale.US, "%.${decimals}f", v)

    private fun visibleCount(): Int = max(1, ((width - axisW) / candleWidth).toInt())

    private fun clampOffset() {
        val maxOff = max(0f, (candles.size - visibleCount()).toFloat())
        offset = offset.coerceIn(0f, maxOff)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(colBg)
        val w = width.toFloat()
        val h = height.toFloat()
        if (candles.isEmpty()) {
            canvas.drawText("Chargement des données…", w / 2, h / 2, emptyPaint)
            return
        }

        val right = w - axisW
        val gap = dp(10f)
        val priceTop = dp(22f)
        val rsiH = (h - timeH) * 0.24f
        val priceBottom = h - timeH - rsiH - gap
        val rsiTop = priceBottom + gap
        val rsiBottom = h - timeH

        clampOffset()
        val endIdx = candles.size - 1 - offset.toInt()
        val startIdx = max(0, endIdx - visibleCount() + 1)
        fun x(i: Int): Float = right - (endIdx - i + 0.5f) * candleWidth

        // Échelle de prix
        var lo = Double.MAX_VALUE
        var hi = -Double.MAX_VALUE
        for (i in startIdx..endIdx) {
            lo = min(lo, candles[i].low)
            hi = max(hi, candles[i].high)
        }
        val act = if (Tool.SIGNALS in tools) activeSignal else null
        // L'échelle suit uniquement les bougies : les niveaux hors écran sont signalés sur les bords
        val pad = if (hi > lo) (hi - lo) * 0.08 else max(abs(hi) * 0.001, 1e-6)
        hi += pad
        lo -= pad
        if (!autoScale && manHi > manLo) {
            lo = manLo
            hi = manHi
        }
        fun y(p: Double): Float = (priceTop + (hi - p) / (hi - lo) * (priceBottom - priceTop)).toFloat()
        drawnLo = lo; drawnHi = hi; drawnTop = priceTop; drawnBottom = priceBottom

        // Grille + axe des prix
        for (k in 0..4) {
            val p = lo + (hi - lo) * k / 4.0
            val yy = y(p)
            canvas.drawLine(0f, yy, right, yy, gridPaint)
            canvas.drawText(fmt(p), right + dp(4f), yy + dp(3.5f), textPaint)
        }

        canvas.save()
        canvas.clipRect(0f, priceTop, right, priceBottom)

        // Zones de support / résistance (derrière les bougies)
        if (Tool.ZONES in tools) {
            val lastClose = candles.last().close
            for (z in overlay.zones) {
                if (z.high < lo || z.low > hi) continue
                val isSupport = z.mid < lastClose
                zonePaint.color = if (isSupport) colZoneSup else colZoneRes
                val top = y(z.high)
                val bottom = max(y(z.low), top + dp(2f))
                canvas.drawRect(0f, top, right, bottom, zonePaint)
                smallPaint.color = if (isSupport) colUp else colDown
                canvas.drawText("${if (isSupport) "S" else "R"} ${z.touches}×", dp(4f), top - dp(2f), smallPaint)
            }
        }

        // Fibonacci
        val fib = overlay.fib
        if (Tool.FIBONACCI in tools && fib != null) {
            val x0 = if (fib.fromIndex >= startIdx) x(fib.fromIndex) else 0f
            dashPaint.color = colFib
            for (lv in fib.levels) {
                if (lv.price < lo || lv.price > hi) continue
                val yy = y(lv.price)
                path.reset(); path.moveTo(x0, yy); path.lineTo(right, yy)
                canvas.drawPath(path, dashPaint)
                smallPaint.color = colFib
                canvas.drawText(lv.label, x0 + dp(3f), yy - dp(2f), smallPaint)
            }
            if (fib.fromIndex >= startIdx && fib.toIndex <= endIdx) {
                linePaint.color = colFib
                canvas.drawLine(x(fib.fromIndex), y(fib.fromPrice), x(fib.toIndex), y(fib.toPrice), linePaint)
            }
        }

        // Bougies
        val bodyW = max(1f, candleWidth * 0.7f)
        for (i in startIdx..endIdx) {
            val c = candles[i]
            val cx = x(i)
            candlePaint.color = if (c.close >= c.open) colUp else colDown
            canvas.drawLine(cx, y(c.high), cx, y(c.low), candlePaint)
            val top = y(max(c.open, c.close))
            var bottom = y(min(c.open, c.close))
            if (bottom - top < 1f) bottom = top + 1f
            canvas.drawRect(cx - bodyW / 2, top, cx + bodyW / 2, bottom, candlePaint)
        }

        // EMA
        if (Tool.EMA in tools) {
            drawSeries(canvas, ema50, startIdx, endIdx, colEma50, { x(it) }, { y(it) })
            drawSeries(canvas, ema20, startIdx, endIdx, colEma20, { x(it) }, { y(it) })
        }

        // Lignes de tendance : de leur premier point jusqu'au bord droit
        if (Tool.TRENDLINES in tools) {
            for (l in overlay.lines) {
                val from = max(l.i1, startIdx)
                if (from > endIdx) continue
                trendPaint.color = if (l.isSupport) colUp else colDown
                trendPaint.strokeWidth = if (l.touches >= 3) dp(2f) else dp(1.2f)
                val xr = right
                val iRight = endIdx + (right - x(endIdx)) / candleWidth
                val yr = y(l.p1 + l.slope * (iRight - l.i1))
                canvas.drawLine(x(from), y(l.valueAt(from)), xr, yr, trendPaint)
                smallPaint.color = trendPaint.color
                canvas.drawText("${l.touches}×", xr - dp(18f), yr - dp(3f), smallPaint)
            }
        }

        // Figures chartistes
        if (Tool.PATTERNS in tools) {
            for (p in overlay.patterns) {
                val color = when (p.bias) {
                    Side.BUY -> colUp
                    Side.SELL -> colDown
                    null -> colText
                }
                patternPaint.color = color
                var labelX = -1f
                var labelY = 0f
                for (sg in p.segments) {
                    if (sg.i2 < startIdx || sg.i1 > endIdx) continue
                    canvas.drawLine(x(sg.i1), y(sg.p1), x(sg.i2), y(sg.p2), patternPaint)
                    labelX = x(sg.i2); labelY = y(sg.p2)
                }
                p.neckline?.let {
                    if (it in lo..hi) {
                        dashPaint.color = color
                        val yy = y(it)
                        path.reset(); path.moveTo(x(max(startIdx, p.segments.first().i1)), yy); path.lineTo(right, yy)
                        canvas.drawPath(path, dashPaint)
                    }
                }
                if (labelX >= 0) {
                    labelPaint.color = color
                    val text = p.name + if (p.confirmed) " ✓" else ""
                    canvas.drawText(text, min(labelX, right - labelPaint.measureText(text) - dp(2f)), labelY - dp(6f), labelPaint)
                }
            }
        }

        // Figures de bougies (seulement celles qui ont un sens haussier ou baissier)
        if (Tool.CANDLES in tools && candleWidth >= dp(4f)) {
            smallPaint.textAlign = Paint.Align.CENTER
            for (cp in overlay.candlePatterns) {
                if (cp.index !in startIdx..endIdx || cp.bias == null) continue
                val c = candles[cp.index]
                smallPaint.color = if (cp.bias == Side.BUY) colUp else colDown
                val yy = if (cp.bias == Side.BUY) y(c.low) + dp(22f) else y(c.high) - dp(16f)
                canvas.drawText(cp.code, x(cp.index), yy, smallPaint)
            }
            smallPaint.textAlign = Paint.Align.LEFT
        }

        // Flèches de signal
        val arrow = max(dp(5f), min(dp(9f), candleWidth * 0.6f))
        for (sig in if (Tool.SIGNALS in tools) signals else emptyList()) {
            if (sig.index !in startIdx..endIdx) continue
            val cx = x(sig.index)
            val c = candles[sig.index]
            path.reset()
            if (sig.side == Side.BUY) {
                val tip = y(c.low) + dp(4f)
                path.moveTo(cx, tip); path.lineTo(cx - arrow, tip + arrow * 1.3f); path.lineTo(cx + arrow, tip + arrow * 1.3f)
                markerPaint.color = colUp
            } else {
                val tip = y(c.high) - dp(4f)
                path.moveTo(cx, tip); path.lineTo(cx - arrow, tip - arrow * 1.3f); path.lineTo(cx + arrow, tip - arrow * 1.3f)
                markerPaint.color = colDown
            }
            path.close()
            canvas.drawPath(path, markerPaint)
        }

        // Trade en cours : entrée, stop, objectif
        if (act != null && act.index in startIdx..endIdx) {
            val x0 = x(act.index)
            for ((level, color) in listOf(act.entry to colText, act.stop to colDown, act.target to colUp)) {
                dashPaint.color = color
                val yy = y(level)
                path.reset(); path.moveTo(x0, yy); path.lineTo(right, yy)
                canvas.drawPath(path, dashPaint)
            }
            textPaint.color = colDown
            canvas.drawText("SL", x0 + dp(3f), y(act.stop) - dp(3f), textPaint)
            textPaint.color = colUp
            canvas.drawText("TP", x0 + dp(3f), y(act.target) - dp(3f), textPaint)
            textPaint.color = colText
        }

        // Positions fictives clôturées : trait de l'entrée à la sortie
        for (t in closedTrades) {
            val i1 = indexForEpoch(t.openEpoch)
            val i2 = indexForEpoch(t.closeEpoch ?: continue)
            if (i1 < 0 || i2 < 0 || i2 < startIdx || i1 > endIdx) continue
            val col = if (t.r >= 0) colUp else colDown
            tradePaint.color = col
            canvas.drawLine(x(i1), y(t.entry), x(i2), y(t.exit ?: t.entry), tradePaint)
            markerPaint.color = col
            canvas.drawCircle(x(i1), y(t.entry), dp(3.5f), markerPaint)
            canvas.drawCircle(x(i2), y(t.exit ?: t.entry), dp(3.5f), markerPaint)
        }

        // Positions fictives ouvertes : entrée, stop, objectif
        val lastPrice = candles.last().close
        for (t in openTrades) {
            val i1 = indexForEpoch(t.openEpoch).coerceAtLeast(startIdx)
            if (i1 > endIdx) continue
            val x0 = x(i1)
            val levels = listOfNotNull(Triple(t.entry, colText, "Entrée"), Triple(t.stop, colDown, "SL"), t.target?.let { Triple(it, colUp, "TP") })
            for ((lvl, col, label) in levels) {
                if (lvl < lo || lvl > hi) {
                    // Hors de l'écran : petit repère sur le bord haut ou bas
                    smallPaint.color = col
                    val above = lvl > hi
                    val yy = if (above) priceTop + dp(10f) else priceBottom - dp(4f)
                    canvas.drawText("${if (above) "↑" else "↓"} $label ${fmt(lvl)}", x0 + dp(3f), yy, smallPaint)
                    continue
                }
                tradePaint.color = col
                canvas.drawLine(x0, y(lvl), right, y(lvl), tradePaint)
                smallPaint.color = col
                canvas.drawText(label, x0 + dp(3f), y(lvl) - dp(3f), smallPaint)
            }
            val r = t.rAt(lastPrice)
            labelPaint.color = if (r >= 0) colUp else colDown
            val txt = (if (t.side == Side.BUY) "ACHAT " else "VENTE ") +
                String.format(Locale.US, "%+.2f $ (%+.2f R)", r * t.riskAmount, r)
            canvas.drawText(txt, x0 + dp(3f), y(t.entry) + dp(13f), labelPaint)
        }

        // Niveaux d'alerte
        dashPaint.color = colAlert
        for (lvl in alertLevels) {
            if (lvl < lo || lvl > hi) continue
            val yy = y(lvl)
            path.reset(); path.moveTo(0f, yy); path.lineTo(right, yy)
            canvas.drawPath(path, dashPaint)
        }
        canvas.restore()

        for (lvl in alertLevels) {
            if (lvl < lo || lvl > hi) continue
            drawAxisLabel(canvas, right, w, y(lvl), fmt(lvl), colAlert)
        }

        // Dernier prix
        val last = candles.last()
        val lastColor = if (last.close >= last.open) colUp else colDown
        val ly = y(last.close).coerceIn(priceTop, priceBottom)
        dashPaint.color = lastColor
        path.reset(); path.moveTo(0f, ly); path.lineTo(right, ly)
        canvas.drawPath(path, dashPaint)
        if (act != null && act.index in startIdx..endIdx) {
            drawAxisLabel(canvas, right, w, y(act.stop), fmt(act.stop), colDown)
            drawAxisLabel(canvas, right, w, y(act.target), fmt(act.target), colUp)
        }
        drawAxisLabel(canvas, right, w, ly, fmt(last.close), lastColor)

        // Boutons : plein écran et retour à l'échelle automatique
        val bs = dp(30f)
        btnFull.set(right - bs - dp(4f), priceTop + dp(2f), right - dp(4f), priceTop + dp(2f) + bs)
        buttonPaint.color = Color.argb(170, 22, 27, 34)
        canvas.drawRoundRect(btnFull, dp(6f), dp(6f), buttonPaint)
        buttonText.textAlign = Paint.Align.CENTER
        canvas.drawText(if (isFullscreen) "✕" else "⛶", btnFull.centerX(), btnFull.centerY() + dp(5f), buttonText)
        if (!autoScale) {
            btnAuto.set(btnFull.left - dp(56f), btnFull.top, btnFull.left - dp(6f), btnFull.bottom)
            canvas.drawRoundRect(btnAuto, dp(6f), dp(6f), buttonPaint)
            buttonSmall.textAlign = Paint.Align.CENTER
            canvas.drawText("AUTO", btnAuto.centerX(), btnAuto.centerY() + dp(4f), buttonSmall)
        } else {
            btnAuto.setEmpty()
        }

        // Légende
        var lx = dp(4f)
        val legendY = dp(14f)
        if (Tool.EMA in tools) {
            lx = drawLegend(canvas, lx, legendY, "EMA20 ", ema20.getOrNull(endIdx), colEma20)
            drawLegend(canvas, lx + dp(10f), legendY, "EMA50 ", ema50.getOrNull(endIdx), colEma50)
        }

        // RSI
        fun ry(v: Double): Float = (rsiTop + (100 - v) / 100 * (rsiBottom - rsiTop)).toFloat()
        canvas.drawLine(0f, rsiTop, right, rsiTop, gridPaint)
        canvas.drawLine(0f, rsiBottom, right, rsiBottom, gridPaint)
        dashPaint.color = colGrid
        for (lvl in doubleArrayOf(30.0, 70.0)) {
            val yy = ry(lvl)
            path.reset(); path.moveTo(0f, yy); path.lineTo(right, yy)
            canvas.drawPath(path, dashPaint)
            canvas.drawText(lvl.toInt().toString(), right + dp(4f), yy + dp(3.5f), textPaint)
        }
        canvas.save()
        canvas.clipRect(0f, rsiTop, right, rsiBottom)
        drawSeries(canvas, rsi, startIdx, endIdx, colRsi, { x(it) }, { ry(it) })
        canvas.restore()
        val rsiNow = rsi.getOrNull(endIdx)
        legendPaint.color = colRsi
        canvas.drawText(
            "RSI14 " + (if (rsiNow == null || rsiNow.isNaN()) "—" else String.format(Locale.US, "%.1f", rsiNow)),
            dp(4f), rsiTop + dp(13f), legendPaint,
        )

        // Heures
        val every = max(1, (dp(70f) / candleWidth).toInt())
        val f = if (granularity >= 86_400) dayFmt else timeFmt
        textPaint.textAlign = Paint.Align.CENTER
        for (i in startIdx..endIdx) {
            if (i % every != 0) continue
            val cx = x(i)
            if (cx < dp(16f) || cx > right - dp(16f)) continue
            canvas.drawText(f.format(Date(candles[i].epoch * 1000)), cx, h - dp(4f), textPaint)
        }
        textPaint.textAlign = Paint.Align.LEFT
    }

    private inline fun drawSeries(
        canvas: Canvas, arr: DoubleArray, from: Int, to: Int, color: Int,
        xOf: (Int) -> Float, yOf: (Double) -> Float,
    ) {
        path.reset()
        var started = false
        for (i in from..to) {
            val v = arr.getOrNull(i)
            if (v == null || v.isNaN()) {
                started = false
                continue
            }
            if (!started) {
                path.moveTo(xOf(i), yOf(v)); started = true
            } else {
                path.lineTo(xOf(i), yOf(v))
            }
        }
        linePaint.color = color
        canvas.drawPath(path, linePaint)
    }

    private fun drawAxisLabel(canvas: Canvas, left: Float, right: Float, yy: Float, text: String, color: Int) {
        labelBoxPaint.color = color
        rect.set(left, yy - dp(8f), right, yy + dp(8f))
        canvas.drawRoundRect(rect, dp(3f), dp(3f), labelBoxPaint)
        canvas.drawText(text, left + dp(4f), yy + dp(3.5f), labelTextPaint)
    }

    private fun drawLegend(canvas: Canvas, x: Float, y: Float, label: String, v: Double?, color: Int): Float {
        legendPaint.color = color
        val text = label + if (v == null || v.isNaN()) "—" else fmt(v)
        canvas.drawText(text, x, y, legendPaint)
        return x + legendPaint.measureText(text)
    }

    // ---------- Gestes ----------

    /** Passe en échelle libre en partant de ce qui est affiché. */
    private fun goManual() {
        if (!autoScale) return
        manLo = drawnLo
        manHi = drawnHi
        autoScale = false
    }

    private fun zoomVertical(factor: Double) {
        goManual()
        val mid = (manLo + manHi) / 2
        val half = ((manHi - manLo) / 2 * factor).coerceAtLeast(1e-9)
        manLo = mid - half
        manHi = mid + half
    }

    private var dragOnAxis = false
    private var accX = 0f
    private var accY = 0f

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean {
            dragOnAxis = e.x > width - axisW && e.y in drawnTop..drawnBottom
            accX = 0f
            accY = 0f
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            if (btnFull.contains(e.x, e.y)) {
                onFullscreenToggle?.invoke()
                return true
            }
            if (!btnAuto.isEmpty && btnAuto.contains(e.x, e.y)) {
                autoScale = true
                invalidate()
                return true
            }
            return false
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            parent?.requestDisallowInterceptTouchEvent(true)
            if (dragOnAxis) {
                // Glisser sur l'axe des prix : vers le bas = dézoomer, vers le haut = zoomer
                zoomVertical(Math.exp(-distanceY * 0.006))
                invalidate()
                return true
            }
            offset -= distanceX / candleWidth
            clampOffset()
            accX += abs(distanceX)
            accY += abs(distanceY)
            // Un geste nettement vertical libère l'échelle : le graphique suit alors le doigt dans tous les sens
            if (autoScale && accY > dp(24f) && accY > accX * 1.2f) goManual()
            if (!autoScale && drawnBottom > drawnTop) {
                val perPx = (manHi - manLo) / (drawnBottom - drawnTop)
                // Doigt vers le haut (distanceY > 0) : le graphique monte, on voit des prix plus bas
                manLo -= distanceY * perPx
                manHi -= distanceY * perPx
            }
            invalidate()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            // Retour au direct avec l'échelle automatique
            offset = 0f
            autoScale = true
            invalidate()
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (candles.isEmpty() || e.y < drawnTop || e.y > drawnBottom || e.x > width - axisW) return
            val ratio = (e.y - drawnTop) / (drawnBottom - drawnTop)
            val price = drawnHi - ratio * (drawnHi - drawnLo)
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onLongPressPrice?.invoke(price)
        }
    })

    private val scaler = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val fx = if (detector.previousSpanX > 10f) detector.currentSpanX / detector.previousSpanX else 1f
            val fy = if (detector.previousSpanY > 10f) detector.currentSpanY / detector.previousSpanY else 1f
            if (abs(ln(fy.toDouble())) > abs(ln(fx.toDouble())) * 1.3) {
                // Pincement vertical : zoom sur les prix
                zoomVertical(1.0 / fy)
            } else {
                candleWidth = (candleWidth * fx).coerceIn(dp(2f), dp(40f))
                clampOffset()
            }
            invalidate()
            return true
        }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaler.onTouchEvent(event)
        if (!scaler.isInProgress) gestures.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
