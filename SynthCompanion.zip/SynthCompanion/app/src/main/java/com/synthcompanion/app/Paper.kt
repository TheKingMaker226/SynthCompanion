package com.synthcompanion.app

import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

enum class TradeMode(val label: String) { LIVE("Direct"), REPLAY("Replay") }

/** Mouvement de capital fictif : dépôt (montant positif) ou retrait (montant négatif). */
data class CashMove(val id: Long, val epoch: Long, val amount: Double, val balanceAfter: Double, val note: String) {
    val isDeposit: Boolean get() = amount > 0
}

/**
 * Spécifications MT5 des indices synthétiques Deriv : 1 lot = 1 $ par unité de prix,
 * donc gain ou perte en $ = lots × écart de prix. Les lots minimums sont indicatifs
 * (ils peuvent changer) : la référence reste « Spécifications » dans MT5.
 */
object Contracts {
    const val CONTRACT_SIZE = 1.0

    private val minLots = mapOf(
        "1HZ10V" to 0.5, "1HZ25V" to 0.005, "1HZ50V" to 0.005, "1HZ75V" to 0.05, "1HZ100V" to 0.5,
        "R_10" to 0.5, "R_25" to 0.5, "R_50" to 4.0, "R_75" to 0.001, "R_100" to 0.5,
    )

    fun minLot(symbol: String): Double? = minLots[symbol]

    /** Montant en $ perdu si le stop est touché, pour un volume donné. */
    fun riskFor(lot: Double, entry: Double, stop: Double): Double = lot * kotlin.math.abs(entry - stop) * CONTRACT_SIZE

    /** Volume qui correspond à un risque en $ donné. */
    fun lotFor(riskAmount: Double, entry: Double, stop: Double): Double {
        val d = kotlin.math.abs(entry - stop) * CONTRACT_SIZE
        return if (d <= 0) 0.0 else riskAmount / d
    }
}

/** Position fictive. Le stop est obligatoire : sans stop, le risque (1 R) n'est pas mesurable. */
data class PaperTrade(
    val id: Long,
    val symbol: String,
    val timeframe: String,
    val side: Side,
    val entry: Double,
    val stop: Double,
    val target: Double?,
    /** Montant risqué en $ fictifs (perte si le stop est touché). */
    val riskAmount: Double,
    val openEpoch: Long,
    val mode: TradeMode,
    val setup: String,
    val note: String,
    val closeEpoch: Long? = null,
    val exit: Double? = null,
    /** « Objectif », « Stop » ou « Manuel ». */
    val reason: String? = null,
    /** Stop d'origine si le stop a été déplacé : il fixe la valeur de 1 R. */
    val initialStop: Double? = null,
    /** Volume en lots (MT5), si la taille a été choisie en lots. */
    val lot: Double? = null,
) {
    val isOpen: Boolean get() = exit == null
    val risk: Double get() = abs(entry - (initialStop ?: stop))

    fun rAt(price: Double): Double {
        if (risk <= 0) return 0.0
        return (if (side == Side.BUY) price - entry else entry - price) / risk
    }

    val r: Double get() = exit?.let { rAt(it) } ?: Double.NaN
    val pnl: Double get() = if (isOpen) 0.0 else r * riskAmount
    val plannedRR: Double? get() = target?.let { if (risk > 0) abs(it - entry) / risk else null }

    /**
     * Vérifie si une bougie (ou un tick, avec low = high = prix) touche le stop ou l'objectif.
     * Si les deux sont touchés dans la même bougie, on retient le stop (hypothèse prudente).
     */
    fun exitFor(low: Double, high: Double): Pair<Double, String>? {
        val hitStop = if (side == Side.BUY) low <= stop else high >= stop
        if (hitStop) return stop to "Stop"
        val t = target ?: return null
        val hitTarget = if (side == Side.BUY) high >= t else low <= t
        return if (hitTarget) t to "Objectif" else null
    }
}

/** Statistiques et conseils calculés sur des trades clôturés. */
class JournalStats(all: List<PaperTrade>, private val startBalance: Double) {

    val trades: List<PaperTrade> = all.filter { !it.isOpen }.sortedBy { it.closeEpoch ?: 0 }
    val n = trades.size
    val wins = trades.count { it.r > 0 }
    val losses = trades.count { it.r < 0 }
    val winRate = if (n == 0) 0.0 else wins * 100.0 / n
    val totalR = trades.sumOf { it.r }
    val avgR = if (n == 0) 0.0 else totalR / n
    val totalPnl = trades.sumOf { it.pnl }
    val avgWinR = trades.filter { it.r > 0 }.map { it.r }.average().let { if (it.isNaN()) 0.0 else it }
    val avgLossR = trades.filter { it.r < 0 }.map { it.r }.average().let { if (it.isNaN()) 0.0 else it }
    val profitFactor: Double
        get() {
            val g = trades.filter { it.r > 0 }.sumOf { it.r }
            val l = -trades.filter { it.r < 0 }.sumOf { it.r }
            return if (l == 0.0) (if (g > 0) Double.POSITIVE_INFINITY else 0.0) else g / l
        }

    /** Capital après chaque trade (premier point = capital de départ). */
    val equity: List<Double> = trades.runningFold(startBalance) { acc, t -> acc + t.pnl }

    val maxDrawdown: Double
        get() {
            var peak = startBalance
            var dd = 0.0
            for (e in equity) {
                peak = max(peak, e)
                dd = max(dd, peak - e)
            }
            return dd
        }

    val maxLosingStreak: Int
        get() {
            var cur = 0
            var best = 0
            for (t in trades) if (t.r < 0) { cur++; best = max(best, cur) } else cur = 0
            return best
        }

    /** t de Student de la moyenne des R : au-delà de 2, l'avantage a peu de chances d'être dû au hasard. */
    val tStat: Double
        get() {
            if (n < 2) return 0.0
            val m = avgR
            val sd = sqrt(trades.sumOf { (it.r - m) * (it.r - m) } / (n - 1))
            return if (sd == 0.0) 0.0 else m / (sd / sqrt(n.toDouble()))
        }

    data class Group(val name: String, val n: Int, val winRate: Double, val avgR: Double, val totalR: Double)

    private fun group(key: (PaperTrade) -> String): List<Group> =
        trades.groupBy(key).map { (k, list) ->
            val tr = list.sumOf { it.r }
            Group(k, list.size, list.count { it.r > 0 } * 100.0 / list.size, tr / list.size, tr)
        }.sortedByDescending { it.totalR }

    val bySetup get() = group { it.setup.ifBlank { "Sans setup" } }
    val bySide get() = group { if (it.side == Side.BUY) "Achats" else "Ventes" }
    val byTimeframe get() = group { it.timeframe }
    val byReason get() = group { it.reason ?: "?" }
    val byMode get() = group { it.mode.label }
    val bySymbol get() = group { it.symbol }
    val byHour
        get() = group {
            val cal = Calendar.getInstance().apply { timeInMillis = it.openEpoch * 1000 }
            val h = cal.get(Calendar.HOUR_OF_DAY) / 4 * 4
            String.format(Locale.US, "%02dh–%02dh", h, h + 4)
        }

    private fun f(v: Double, d: Int = 2) = String.format(Locale.US, "%.${d}f", v)
    private fun rr(v: Double) = String.format(Locale.US, "%+.2f R", v)

    /** Remarques automatiques pour progresser. */
    fun insights(): List<String> {
        val out = ArrayList<String>()
        if (n == 0) return listOf("Aucun trade clôturé pour l'instant. Prends des positions fictives (en direct ou en replay) pour obtenir une analyse.")
        if (n < 20) out.add("Seulement $n trade${if (n > 1) "s" else ""} : les chiffres sont encore très instables. Vise au moins 30 à 50 trades avant de juger une stratégie.")

        // Avantage réel ?
        val t = tStat
        when {
            n >= 20 && t >= 2 -> out.add("Ton résultat moyen (${rr(avgR)} par trade) est nettement positif (t = ${f(t)}). Vérifie qu'il se maintient sur de nouveaux trades avant d'y croire.")
            avgR > 0 -> out.add("Résultat moyen positif (${rr(avgR)} par trade), mais pas encore distinguable de la chance (t = ${f(t)}, il faudrait au moins 2).")
            else -> out.add("Résultat moyen négatif (${rr(avgR)} par trade). Regarde plus bas quels setups et quelles habitudes coûtent le plus.")
        }

        // Ratio gain/risque prévu
        val planned = trades.mapNotNull { it.plannedRR }
        if (planned.isNotEmpty()) {
            val avgPlan = planned.average()
            val need = 100.0 / (1 + avgPlan)
            out.add("Ton objectif moyen est à ${f(avgPlan, 1)} R : il te faut plus de ${f(need, 0)} % de trades gagnants pour être rentable. Tu es à ${f(winRate, 0)} %.")
        }
        val noTarget = trades.count { it.target == null }
        if (noTarget * 2 > n) out.add("Plus de la moitié de tes trades n'ont pas d'objectif. Fixer un objectif avant d'entrer aide à juger si le trade en vaut la peine.")

        // Clôtures manuelles
        val manual = trades.filter { it.reason == "Manuel" }
        if (manual.size >= 3) {
            val mAvg = manual.sumOf { it.r } / manual.size
            val manualWins = manual.filter { it.r > 0 }
            if (manualWins.size * 2 >= manual.size && manualWins.isNotEmpty()) {
                val gain = manualWins.sumOf { it.r } / manualWins.size
                val plan = manualWins.mapNotNull { it.plannedRR }.average()
                if (!plan.isNaN() && gain < plan * 0.6) {
                    out.add("Quand tu clôtures à la main en gain, tu prends en moyenne ${rr(gain)} alors que ton objectif était ${f(plan, 1)} R : tu coupes souvent tes gains trop tôt.")
                }
            }
            if (mAvg < 0) out.add("Tes clôtures manuelles finissent en moyenne à ${rr(mAvg)}. Laisse davantage le stop ou l'objectif décider.")
        }

        // Trades pris juste après une perte
        val afterLoss = ArrayList<PaperTrade>()
        val others = ArrayList<PaperTrade>()
        val sortedByOpen = trades.sortedBy { it.openEpoch }
        for (tr in sortedByOpen) {
            val prevLoss = trades.any { p ->
                p.r < 0 && p.closeEpoch != null && p.mode == tr.mode &&
                    tr.openEpoch >= p.closeEpoch && tr.openEpoch - p.closeEpoch <= 600
            }
            if (prevLoss) afterLoss.add(tr) else others.add(tr)
        }
        if (afterLoss.size >= 5 && others.size >= 5) {
            val a = afterLoss.sumOf { it.r } / afterLoss.size
            val o = others.sumOf { it.r } / others.size
            if (a < o - 0.2) out.add("Les trades ouverts moins de 10 minutes après une perte font ${rr(a)} en moyenne, contre ${rr(o)} pour les autres. Fais une pause après une perte.")
        }

        // Setups, sens
        val setups = bySetup.filter { it.n >= 5 }
        if (setups.size >= 2) {
            out.add("Meilleur setup : ${setups.first().name} (${rr(setups.first().avgR)} en moyenne sur ${setups.first().n} trades). Le moins bon : ${setups.last().name} (${rr(setups.last().avgR)}).")
        }
        val sides = bySide
        if (sides.size == 2 && sides.all { it.n >= 5 } && abs(sides[0].avgR - sides[1].avgR) > 0.3) {
            out.add("Tu réussis mieux tes ${sides[0].name.lowercase()} (${rr(sides[0].avgR)}) que tes ${sides[1].name.lowercase()} (${rr(sides[1].avgR)}).")
        }
        if (maxLosingStreak >= 5) out.add("Tu as connu $maxLosingStreak pertes d'affilée. C'est normal même avec une bonne stratégie : le risque par trade doit te permettre d'y survivre.")
        return out
    }
}
