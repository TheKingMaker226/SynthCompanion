package com.synthcompanion.app

import kotlin.math.abs
import kotlin.math.max

object Indicators {

    /** Moyenne mobile exponentielle, amorcée par une moyenne simple. NaN tant qu'il n'y a pas assez de données. */
    fun ema(values: List<Double>, period: Int): DoubleArray {
        val out = DoubleArray(values.size) { Double.NaN }
        if (period <= 0 || values.size < period) return out
        var sum = 0.0
        for (i in 0 until period) sum += values[i]
        var prev = sum / period
        out[period - 1] = prev
        val k = 2.0 / (period + 1)
        for (i in period until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    /** RSI de Wilder. */
    fun rsi(values: List<Double>, period: Int = 14): DoubleArray {
        val out = DoubleArray(values.size) { Double.NaN }
        if (values.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = values[i] - values[i - 1]
            if (d > 0) gain += d else loss -= d
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        out[period] = rsiValue(avgGain, avgLoss)
        for (i in period + 1 until values.size) {
            val d = values[i] - values[i - 1]
            avgGain = (avgGain * (period - 1) + max(d, 0.0)) / period
            avgLoss = (avgLoss * (period - 1) + max(-d, 0.0)) / period
            out[i] = rsiValue(avgGain, avgLoss)
        }
        return out
    }

    /** ATR de Wilder : amplitude moyenne d'une bougie, écarts entre bougies compris. */
    fun atr(candles: List<Candle>, period: Int = 14): DoubleArray {
        val out = DoubleArray(candles.size) { Double.NaN }
        if (candles.size <= period) return out
        fun tr(i: Int): Double {
            val c = candles[i]
            if (i == 0) return c.high - c.low
            val pc = candles[i - 1].close
            return max(c.high - c.low, max(abs(c.high - pc), abs(c.low - pc)))
        }
        var sum = 0.0
        for (i in 1..period) sum += tr(i)
        var prev = sum / period
        out[period] = prev
        for (i in period + 1 until candles.size) {
            prev = (prev * (period - 1) + tr(i)) / period
            out[i] = prev
        }
        return out
    }

    private fun rsiValue(avgGain: Double, avgLoss: Double): Double = when {
        avgLoss == 0.0 && avgGain == 0.0 -> 50.0
        avgLoss == 0.0 -> 100.0
        else -> 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
    }
}
