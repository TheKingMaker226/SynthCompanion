package com.synthcompanion.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.abs

/** Bulle flottante déplaçable affichée par-dessus MT5 (ou n'importe quelle appli). */
class OverlayController(private val ctx: Context, private val onClose: () -> Unit) {

    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    @SuppressLint("InflateParams")
    private val view: View = LayoutInflater.from(ctx).inflate(R.layout.overlay_bubble, null)
    private val tvHeader: TextView = view.findViewById(R.id.ovHeader)
    private val tvPrice: TextView = view.findViewById(R.id.ovPrice)
    private val tvTimer: TextView = view.findViewById(R.id.ovTimer)
    private val tvPnl: TextView = view.findViewById(R.id.ovPnl)
    private val btnClose: TextView = view.findViewById(R.id.ovClose)

    private val colorUp = ContextCompat.getColor(ctx, R.color.up)
    private val colorDown = ContextCompat.getColor(ctx, R.color.down)
    private val colorText = ContextCompat.getColor(ctx, R.color.text)
    private val colorWarn = ContextCompat.getColor(ctx, R.color.accent)

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = prefs.getInt("ov_x", 40)
        y = prefs.getInt("ov_y", 300)
    }

    private var attached = false

    init {
        btnClose.setOnClickListener { onClose() }
        setupDrag()
    }

    fun show() {
        if (attached) return
        try {
            wm.addView(view, params)
            attached = true
        } catch (_: Exception) {
            attached = false
        }
    }

    fun remove() {
        if (!attached) return
        try {
            wm.removeView(view)
        } catch (_: Exception) {
        }
        attached = false
    }

    fun update() {
        if (!attached) return
        tvHeader.text = "${MarketHub.shortName()} · ${MarketHub.timeframeLabel()}"
        tvPrice.text = MarketHub.format(MarketHub.lastPrice)
        val last = MarketHub.candles.lastOrNull()
        tvPrice.setTextColor(
            when {
                last == null -> colorText
                last.close >= last.open -> colorUp
                else -> colorDown
            }
        )
        // Gain / perte en direct des positions fictives sur cet indice
        val open = Journal.open(TradeMode.LIVE).filter { it.symbol == MarketHub.symbol }
        val p = MarketHub.lastPrice
        if (open.isEmpty() || p.isNaN()) {
            tvPnl.visibility = android.view.View.GONE
        } else {
            val pnl = open.sumOf { it.rAt(p) * it.riskAmount }
            tvPnl.visibility = android.view.View.VISIBLE
            tvPnl.text = String.format(java.util.Locale.US, "%s %+.2f $", if (open.size > 1) "${open.size} pos." else "Pos.", pnl)
            tvPnl.setTextColor(if (pnl >= 0) colorUp else colorDown)
        }
        val rem = MarketHub.remainingSeconds()
        tvTimer.text = MarketHub.formatRemaining(rem)
        val n = MarketHub.preCloseSeconds
        tvTimer.setTextColor(if (n > 0 && rem in 0..n) colorWarn else colorText)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDrag() {
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved && attached) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        wm.updateViewLayout(view, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit().putInt("ov_x", params.x).putInt("ov_y", params.y).apply()
                    } else {
                        ctx.startActivity(
                            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
            true
        }
    }
}
