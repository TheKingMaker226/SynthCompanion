package com.synthcompanion.app

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Connexion WebSocket brute à l'API Deriv. Les callbacks arrivent sur un thread OkHttp :
 * c'est MarketHub qui les renvoie sur le thread principal.
 */
class DerivClient(private val url: String, private val listener: Listener) {

    interface Listener {
        fun onOpen()
        fun onMessage(text: String)
        fun onClosed(reason: String)
    }

    private var socket: WebSocket? = null

    fun connect() {
        val request = Request.Builder().url(url).build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) = listener.onOpen()

            override fun onMessage(webSocket: WebSocket, text: String) = listener.onMessage(text)

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) =
                listener.onClosed(if (reason.isNotBlank()) reason else "fermée ($code)")

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) =
                listener.onClosed(t.message ?: t.javaClass.simpleName)
        })
    }

    fun send(obj: JSONObject): Boolean = socket?.send(obj.toString()) ?: false

    fun close() {
        socket?.close(1000, null)
        socket = null
    }

    companion object {
        private val http: OkHttpClient = OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()
    }
}
