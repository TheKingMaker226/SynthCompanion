package com.synthcompanion.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Journal des positions fictives (direct et replay), sauvegardé sur le téléphone. */
object Journal {

    val SETUPS = listOf(
        "Price action", "Support / résistance", "Ligne de tendance", "Cassure", "Fibonacci",
        "Figure chartiste", "Croisement EMA", "Rebond RSI", "Signal de l'appli", "Autre",
    )

    private lateinit var file: File
    private lateinit var cashFile: File
    private val moves = ArrayList<CashMove>()
    private lateinit var prefs: SharedPreferences
    private val trades = ArrayList<PaperTrade>()

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "journal.json")
        cashFile = File(ctx.filesDir, "cash_moves.json")
        loadMoves()
        prefs = ctx.getSharedPreferences("journal", Context.MODE_PRIVATE)
        load()
    }

    var startBalance: Double
        get() = prefs.getFloat("start_balance", 1000f).toDouble()
        set(v) = prefs.edit().putFloat("start_balance", v.toFloat()).apply()

    /** Pourcentage du capital risqué par trade (proposé par défaut). */
    var riskPercent: Double
        get() = prefs.getFloat("risk_pct", 1f).toDouble()
        set(v) = prefs.edit().putFloat("risk_pct", v.toFloat()).apply()

    /** true = taille choisie en lots, false = en % du capital. */
    var sizeByLot: Boolean
        get() = prefs.getBoolean("size_by_lot", true)
        set(v) = prefs.edit().putBoolean("size_by_lot", v).apply()

    fun lastLot(symbol: String): Double? =
        prefs.getFloat("lot_$symbol", -1f).toDouble().takeIf { it > 0 }

    fun setLastLot(symbol: String, lot: Double) = prefs.edit().putFloat("lot_$symbol", lot.toFloat()).apply()

    var lastSetup: String
        get() = prefs.getString("last_setup", SETUPS[0]) ?: SETUPS[0]
        set(v) = prefs.edit().putString("last_setup", v).apply()

    fun all(): List<PaperTrade> = trades.toList()
    fun open(mode: TradeMode? = null): List<PaperTrade> = trades.filter { it.isOpen && (mode == null || it.mode == mode) }
    fun closed(): List<PaperTrade> = trades.filter { !it.isOpen }

    /** Capital = départ + résultats des trades clôturés + dépôts − retraits. */
    fun balance(): Double = startBalance + closed().sumOf { it.pnl } + moves.sumOf { it.amount }

    fun cashMoves(): List<CashMove> = moves.toList()
    fun totalDeposits(): Double = moves.filter { it.amount > 0 }.sumOf { it.amount }
    fun totalWithdrawals(): Double = -moves.filter { it.amount < 0 }.sumOf { it.amount }

    /**
     * Ramène le capital à [target] : ce qui dépasse est enregistré comme un retrait,
     * ce qui manque comme un dépôt. Renvoie le mouvement créé (null si déjà au bon montant).
     */
    fun resetCapitalTo(target: Double): CashMove? {
        val diff = target - balance()
        if (kotlin.math.abs(diff) < 0.005) return null
        val now = System.currentTimeMillis()
        val m = CashMove(
            id = now,
            epoch = now / 1000,
            amount = diff,
            balanceAfter = target,
            note = if (diff > 0) "Dépôt pour revenir à ${String.format(java.util.Locale.US, "%.0f", target)} $"
            else "Retrait pour revenir à ${String.format(java.util.Locale.US, "%.0f", target)} $",
        )
        moves.add(m)
        saveMoves()
        return m
    }

    private fun loadMoves() {
        moves.clear()
        if (!cashFile.exists()) return
        try {
            val arr = JSONArray(cashFile.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                moves.add(CashMove(o.getLong("id"), o.getLong("epoch"), o.getDouble("amount"), o.optDouble("balance_after", 0.0), o.optString("note")))
            }
        } catch (_: Exception) {
        }
    }

    private fun saveMoves() {
        val arr = JSONArray()
        moves.forEach {
            arr.put(JSONObject().put("id", it.id).put("epoch", it.epoch).put("amount", it.amount)
                .put("balance_after", it.balanceAfter).put("note", it.note))
        }
        try {
            cashFile.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    fun add(t: PaperTrade) {
        trades.add(t)
        save()
    }

    fun close(id: Long, price: Double, epoch: Long, reason: String): PaperTrade? {
        val i = trades.indexOfFirst { it.id == id && it.isOpen }
        if (i < 0) return null
        val t = trades[i].copy(exit = price, closeEpoch = epoch, reason = reason)
        trades[i] = t
        save()
        return t
    }

    fun update(t: PaperTrade) {
        val i = trades.indexOfFirst { it.id == t.id }
        if (i >= 0) {
            trades[i] = t
            save()
        }
    }

    fun delete(id: Long) {
        trades.removeAll { it.id == id }
        save()
    }

    /** Supprime les trades d'un mode (ou tous) et remet le capital de départ. */
    fun reset(mode: TradeMode? = null, newBalance: Double? = null) {
        if (mode == null) {
            trades.clear()
            moves.clear()
            saveMoves()
        } else {
            trades.removeAll { it.mode == mode }
        }
        newBalance?.let { startBalance = it }
        save()
    }

    /**
     * Prix en direct : clôture les positions « Direct » ouvertes sur ce symbole si le stop ou
     * l'objectif est touché. Renvoie les positions clôturées.
     */
    fun onLivePrice(symbol: String, price: Double, epoch: Long): List<PaperTrade> {
        val closedNow = ArrayList<PaperTrade>()
        for (t in trades.filter { it.isOpen && it.mode == TradeMode.LIVE && it.symbol == symbol }) {
            val ex = t.exitFor(price, price) ?: continue
            close(t.id, ex.first, epoch, ex.second)?.let { closedNow.add(it) }
        }
        return closedNow
    }

    private fun load() {
        trades.clear()
        if (!file.exists()) return
        try {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                trades.add(
                    PaperTrade(
                        id = o.getLong("id"),
                        symbol = o.getString("symbol"),
                        timeframe = o.optString("timeframe"),
                        side = Side.valueOf(o.getString("side")),
                        entry = o.getDouble("entry"),
                        stop = o.getDouble("stop"),
                        target = if (o.has("target") && !o.isNull("target")) o.getDouble("target") else null,
                        riskAmount = o.optDouble("risk_amount", 10.0),
                        openEpoch = o.getLong("open_epoch"),
                        mode = TradeMode.valueOf(o.optString("mode", "LIVE")),
                        setup = o.optString("setup"),
                        note = o.optString("note"),
                        closeEpoch = if (o.has("close_epoch") && !o.isNull("close_epoch")) o.getLong("close_epoch") else null,
                        exit = if (o.has("exit") && !o.isNull("exit")) o.getDouble("exit") else null,
                        reason = if (o.has("reason") && !o.isNull("reason")) o.getString("reason") else null,
                        initialStop = if (o.has("initial_stop") && !o.isNull("initial_stop")) o.getDouble("initial_stop") else null,
                        lot = if (o.has("lot") && !o.isNull("lot")) o.getDouble("lot") else null,
                    )
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val arr = JSONArray()
        for (t in trades) {
            val o = JSONObject()
                .put("id", t.id)
                .put("symbol", t.symbol)
                .put("timeframe", t.timeframe)
                .put("side", t.side.name)
                .put("entry", t.entry)
                .put("stop", t.stop)
                .put("risk_amount", t.riskAmount)
                .put("open_epoch", t.openEpoch)
                .put("mode", t.mode.name)
                .put("setup", t.setup)
                .put("note", t.note)
            t.target?.let { o.put("target", it) }
            t.closeEpoch?.let { o.put("close_epoch", it) }
            t.exit?.let { o.put("exit", it) }
            t.reason?.let { o.put("reason", it) }
            t.initialStop?.let { o.put("initial_stop", it) }
            t.lot?.let { o.put("lot", it) }
            arr.put(o)
        }
        try {
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(file)
        } catch (_: Exception) {
        }
    }

    /** Export CSV de tout le journal. */
    fun toCsv(decimalsFor: (String) -> Int): String {
        val sb = StringBuilder("id,mode,symbole,unite,sens,setup,ouverture_utc,cloture_utc,entree,stop,objectif,sortie,raison,lot,risque_usd,resultat_R,resultat_usd,note\n")
        for (t in trades.sortedBy { it.openEpoch }) {
            val d = decimalsFor(t.symbol)
            fun p(v: Double?) = v?.let { String.format(java.util.Locale.US, "%.${d}f", it) } ?: ""
            fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
            sb.append(t.id).append(',').append(t.mode.label).append(',').append(t.symbol).append(',')
                .append(t.timeframe).append(',').append(if (t.side == Side.BUY) "Achat" else "Vente").append(',')
                .append(q(t.setup)).append(',').append(Recorder.formatUtc(t.openEpoch)).append(',')
                .append(t.closeEpoch?.let { Recorder.formatUtc(it) } ?: "").append(',')
                .append(p(t.entry)).append(',').append(p(t.stop)).append(',').append(p(t.target)).append(',')
                .append(p(t.exit)).append(',').append(t.reason ?: "ouverte").append(',')
                .append(t.lot?.let { String.format(java.util.Locale.US, "%.3f", it) } ?: "").append(',')
                .append(String.format(java.util.Locale.US, "%.2f", t.riskAmount)).append(',')
                .append(if (t.isOpen) "" else String.format(java.util.Locale.US, "%.2f", t.r)).append(',')
                .append(if (t.isOpen) "" else String.format(java.util.Locale.US, "%.2f", t.pnl)).append(',')
                .append(q(t.note)).append('\n')
        }
        for (m in moves.sortedBy { it.epoch }) {
            sb.append(m.id).append(',').append(if (m.isDeposit) "Dépôt" else "Retrait").append(",,,,,")
                .append(Recorder.formatUtc(m.epoch)).append(",,,,,,,,,,")
                .append(String.format(java.util.Locale.US, "%.2f", m.amount)).append(',')
                .append("\"" + m.note.replace("\"", "\"\"") + "\"").append('\n')
        }
        return sb.toString()
    }
}
