package com.synthcompanion.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Courbe du capital fictif, trade après trade. */
class EquityView(context: Context) : View(context) {

    private var values: List<Double> = emptyList()
    private var start = 0.0
    private val d = resources.displayMetrics.density

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        color = Color.parseColor("#8B949E")
        pathEffect = DashPathEffect(floatArrayOf(4 * d, 4 * d), 0f)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8B949E"); textSize = 10 * d }
    private val path = Path()

    fun setValues(v: List<Double>, startBalance: Double) {
        values = v
        start = startBalance
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.parseColor("#161B22"))
        val w = width.toFloat()
        val h = height.toFloat()
        val padL = 8 * d
        val padR = 56 * d
        val padV = 12 * d
        if (values.size < 2) {
            text.textAlign = Paint.Align.CENTER
            canvas.drawText("La courbe apparaîtra après tes premiers trades clôturés", w / 2, h / 2, text)
            text.textAlign = Paint.Align.LEFT
            return
        }
        var lo = min(values.minOrNull() ?: start, start)
        var hi = max(values.maxOrNull() ?: start, start)
        if (hi - lo < 1e-9) { hi += 1; lo -= 1 }
        fun x(i: Int) = padL + i * (w - padL - padR) / (values.size - 1)
        fun y(v: Double) = (padV + (hi - v) / (hi - lo) * (h - 2 * padV)).toFloat()
        canvas.drawLine(padL, y(start), w - padR, y(start), base)
        path.reset()
        values.forEachIndexed { i, v -> if (i == 0) path.moveTo(x(i), y(v)) else path.lineTo(x(i), y(v)) }
        line.color = if (values.last() >= start) Color.parseColor("#26A69A") else Color.parseColor("#EF5350")
        canvas.drawPath(path, line)
        canvas.drawText(String.format(Locale.US, "%.0f $", hi), w - padR + 4 * d, padV + 4 * d, text)
        canvas.drawText(String.format(Locale.US, "%.0f $", lo), w - padR + 4 * d, h - padV + 4 * d, text)
        canvas.drawText(String.format(Locale.US, "%.0f $", values.last()), w - padR + 4 * d, y(values.last()) + 4 * d, text)
    }
}
