package com.synthcompanion.app

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * IA locale : apprend sur l'historique stocké sur le téléphone, puis est jugée sur une période
 * qu'elle n'a jamais vue (la plus récente).
 *
 * Question posée à chaque bougie : « le prix va-t-il monter de 1 ATR avant de baisser de 1 ATR
 * (dans les 30 bougies suivantes) ? ». Sur une série sans mémoire, la réponse est oui une fois
 * sur deux : tout ce qui dépasse nettement 50 % hors échantillon est un vrai motif récurrent.
 *
 * Deux modèles :
 *  - « Situation » : régression logistique sur ~20 caractéristiques (mouvements récents, RSI,
 *    EMA, position dans le range, bougies, heure de la journée, volatilité).
 *  - « Motifs similaires » : cherche dans le passé les 50 formes de prix les plus proches des
 *    20 dernières bougies et regarde ce qui s'est passé ensuite.
 */
object AiEngine {

    const val HORIZON = 30
    const val WINDOW = 20
    const val K = 50
    const val CONFIDENT = 0.55
    /** Seuil de validation (z unilatéral) : strict, car on teste plusieurs modèles. */
    const val Z_VALID = 2.5
    const val MIN_CONFIDENT_TESTS = 100

    val FEATURE_NAMES = listOf(
        "rendement -1", "rendement -2", "rendement -3", "rendement -4", "rendement -5",
        "rendement 5 bougies", "rendement 10 bougies", "rendement 20 bougies",
        "RSI", "prix vs EMA20", "EMA20 vs EMA50", "corps", "mèche haute", "mèche basse",
        "position range 20", "position range 50", "figure de bougie", "heure (sin)", "heure (cos)", "volatilité relative",
    )

    class Sample(val index: Int, val x: DoubleArray, val shape: DoubleArray, val y: Int)

    // ---------- Caractéristiques ----------

    private fun atrAt(a: Analysis, i: Int): Double {
        val v = a.atr.getOrNull(i) ?: Double.NaN
        return if (v.isNaN() || v <= 0) 0.0 else v
    }

    /** Caractéristiques connues à la clôture de la bougie i (aucune information future). */
    fun features(a: Analysis, i: Int): DoubleArray? {
        val c = a.candles
        if (i < 60 || i >= c.size) return null
        val atr = atrAt(a, i)
        val e20 = a.ema20[i]
        val e50 = a.ema50[i]
        val rsi = a.rsi[i]
        if (atr <= 0 || e20.isNaN() || e50.isNaN() || rsi.isNaN()) return null
        val k = c[i]
        fun ret(back: Int) = (k.close - c[i - back].close) / atr
        fun step(j: Int) = (c[i - j + 1].close - c[i - j].close) / atr
        var hi20 = -Double.MAX_VALUE; var lo20 = Double.MAX_VALUE
        for (j in i - 19..i) { hi20 = max(hi20, c[j].high); lo20 = min(lo20, c[j].low) }
        var hi50 = -Double.MAX_VALUE; var lo50 = Double.MAX_VALUE
        for (j in i - 49..i) { hi50 = max(hi50, c[j].high); lo50 = min(lo50, c[j].low) }
        val pos20 = if (hi20 > lo20) (k.close - lo20) / (hi20 - lo20) - 0.5 else 0.0
        val pos50 = if (hi50 > lo50) (k.close - lo50) / (hi50 - lo50) - 0.5 else 0.0
        val pattern = when (a.structure.candlePatternAt(i)?.bias) {
            Side.BUY -> 1.0
            Side.SELL -> -1.0
            null -> 0.0
        }
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = k.epoch * 1000 }
        val hour = (cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0) / 24.0 * 2 * Math.PI
        var atr50 = 0.0
        var n50 = 0
        for (j in i - 49..i) { val v = atrAt(a, j); if (v > 0) { atr50 += v; n50++ } }
        val volRel = if (n50 > 0 && atr50 > 0) atr / (atr50 / n50) - 1 else 0.0
        return doubleArrayOf(
            step(1), step(2), step(3), step(4), step(5),
            ret(5), ret(10), ret(20),
            rsi / 100 - 0.5, (k.close - e20) / atr, (e20 - e50) / atr,
            (k.close - k.open) / atr, (k.high - max(k.open, k.close)) / atr, (min(k.open, k.close) - k.low) / atr,
            pos20, pos50, pattern, sin(hour), cos(hour), volRel,
        )
    }

    /** Forme des 20 dernières bougies, en ATR, relative à la clôture actuelle. */
    fun shape(a: Analysis, i: Int): DoubleArray? {
        val c = a.candles
        val atr = atrAt(a, i)
        if (i < WINDOW || atr <= 0) return null
        return DoubleArray(WINDOW) { k -> (c[i - WINDOW + 1 + k].close - c[i].close) / atr }
    }

    /** 1 si +1 ATR est atteint avant −1 ATR dans les 30 bougies, 0 dans le cas inverse, null si indécis. */
    fun label(a: Analysis, i: Int): Int? {
        val c = a.candles
        val atr = atrAt(a, i)
        if (atr <= 0) return null
        val ref = c[i].close
        for (j in i + 1..min(c.size - 1, i + HORIZON)) {
            val up = c[j].high >= ref + atr
            val down = c[j].low <= ref - atr
            if (up && down) return null
            if (up) return 1
            if (down) return 0
        }
        return null
    }

    fun buildSamples(a: Analysis, onProgress: (Int) -> Unit = {}): List<Sample> {
        val out = ArrayList<Sample>()
        val n = a.candles.size
        for (i in 60 until n - 1) {
            val y = label(a, i) ?: continue
            val x = features(a, i) ?: continue
            val s = shape(a, i) ?: continue
            out.add(Sample(i, x, s, y))
            if (i % 5000 == 0) onProgress(i * 100 / n)
        }
        return out
    }

    // ---------- Régression logistique ----------

    class Logistic(val w: DoubleArray, val b: Double, val mean: DoubleArray, val std: DoubleArray) {
        fun prob(x: DoubleArray): Double {
            var z = b
            for (j in x.indices) z += w[j] * (x[j] - mean[j]) / std[j]
            return 1.0 / (1.0 + exp(-z.coerceIn(-30.0, 30.0)))
        }

        /** Les caractéristiques qui pèsent le plus (poids sur données standardisées). */
        fun topWeights(n: Int = 5): List<Pair<String, Double>> =
            w.indices.map { FEATURE_NAMES.getOrElse(it) { "x$it" } to w[it] }.sortedByDescending { abs(it.second) }.take(n)
    }

    fun trainLogistic(train: List<Sample>, iterations: Int = 300, lambda: Double = 1e-3): Logistic {
        val d = train.first().x.size
        val mean = DoubleArray(d)
        val std = DoubleArray(d)
        for (s in train) for (j in 0 until d) mean[j] += s.x[j]
        for (j in 0 until d) mean[j] /= train.size
        for (s in train) for (j in 0 until d) std[j] += (s.x[j] - mean[j]) * (s.x[j] - mean[j])
        for (j in 0 until d) std[j] = sqrt(std[j] / train.size).let { if (it < 1e-9) 1.0 else it }
        // Données standardisées en tableau plat (plus rapide)
        val n = train.size
        val xs = DoubleArray(n * d)
        val ys = DoubleArray(n)
        for ((r, s) in train.withIndex()) {
            for (j in 0 until d) xs[r * d + j] = (s.x[j] - mean[j]) / std[j]
            ys[r] = s.y.toDouble()
        }
        val w = DoubleArray(d)
        var b = 0.0
        val grad = DoubleArray(d)
        var lr = 0.5
        for (it in 0 until iterations) {
            java.util.Arrays.fill(grad, 0.0)
            var gb = 0.0
            for (r in 0 until n) {
                var z = b
                val off = r * d
                for (j in 0 until d) z += w[j] * xs[off + j]
                val p = 1.0 / (1.0 + exp(-z.coerceIn(-30.0, 30.0)))
                val e = p - ys[r]
                for (j in 0 until d) grad[j] += e * xs[off + j]
                gb += e
            }
            for (j in 0 until d) w[j] -= lr * (grad[j] / n + lambda * w[j])
            b -= lr * gb / n
            if (it == iterations / 2) lr *= 0.5
        }
        return Logistic(w, b, mean, std)
    }

    // ---------- Motifs similaires (k plus proches voisins) ----------

    class Knn(private val shapes: DoubleArray, private val labels: IntArray, private val dim: Int) {
        val size get() = labels.size

        /** Probabilité de hausse d'après les K formes passées les plus proches. */
        fun prob(q: DoubleArray, k: Int = K): Double {
            if (labels.isEmpty()) return 0.5
            val kk = min(k, labels.size)
            val bestD = DoubleArray(kk) { Double.MAX_VALUE }
            val bestY = IntArray(kk)
            for (r in labels.indices) {
                var dist = 0.0
                val off = r * dim
                val worst = bestD[kk - 1]
                var j = 0
                while (j < dim) {
                    val diff = shapes[off + j] - q[j]
                    dist += diff * diff
                    if (dist >= worst) break
                    j++
                }
                if (dist >= worst) continue
                // insertion triée
                var p = kk - 1
                while (p > 0 && bestD[p - 1] > dist) { bestD[p] = bestD[p - 1]; bestY[p] = bestY[p - 1]; p-- }
                bestD[p] = dist
                bestY[p] = labels[r]
            }
            return bestY.sum().toDouble() / kk
        }

        companion object {
            fun of(samples: List<Sample>): Knn {
                val dim = WINDOW
                val arr = DoubleArray(samples.size * dim)
                samples.forEachIndexed { r, s -> System.arraycopy(s.shape, 0, arr, r * dim, dim) }
                return Knn(arr, IntArray(samples.size) { samples[it].y }, dim)
            }
        }
    }

    // ---------- Évaluation ----------

    class Eval(
        val name: String,
        val n: Int,
        val accuracy: Double,
        val confidentN: Int,
        val confidentAcc: Double,
        val z: Double,
    ) {
        /** Résultat moyen d'un trade à stop = objectif = 1 ATR, sur les prédictions confiantes (avant spread). */
        val avgR: Double get() = 2 * confidentAcc - 1
        val validated: Boolean get() = confidentN >= MIN_CONFIDENT_TESTS && z >= Z_VALID
    }

    private fun evaluate(name: String, probs: List<Pair<Double, Int>>): Eval {
        val n = probs.size
        val correct = probs.count { (p, y) -> (p >= 0.5) == (y == 1) }
        val conf = probs.filter { (p, _) -> p >= CONFIDENT || p <= 1 - CONFIDENT }
        val confCorrect = conf.count { (p, y) -> (p >= 0.5) == (y == 1) }
        val cn = conf.size
        val z = if (cn == 0) 0.0 else (confCorrect - 0.5 * cn) / sqrt(0.25 * cn)
        return Eval(name, n, if (n == 0) 0.0 else correct.toDouble() / n, cn, if (cn == 0) 0.0 else confCorrect.toDouble() / cn, z)
    }

    class TrainResult(
        val candles: Int,
        val trainN: Int,
        val testN: Int,
        val testStartEpoch: Long,
        val baseRateTest: Double,
        val logistic: Eval,
        val knn: Eval,
        /** Modèles ré-entraînés sur tout l'historique, pour la situation actuelle. */
        val logisticModel: Logistic,
        val knnModel: Knn,
    ) {
        val anyValidated get() = logistic.validated || knn.validated
    }

    /**
     * Entraîne sur les 70 % les plus anciens, teste sur les 30 % les plus récents (avec un écart de
     * 30 bougies pour qu'aucune réponse de l'entraînement ne déborde sur le test).
     */
    fun trainAndEvaluate(candles: List<Candle>, maxKnnTests: Int = 600, onProgress: (String) -> Unit = {}): TrainResult? {
        if (candles.size < 1500) return null
        onProgress("Préparation des données…")
        val a = Analysis(candles)
        val samples = buildSamples(a) { pct -> onProgress("Préparation des données… $pct %") }
        if (samples.size < 800) return null
        val cut = (samples.size * 0.7).toInt()
        val cutIndex = samples[cut].index
        val train = samples.filter { it.index < cutIndex - HORIZON }
        val test = samples.filter { it.index >= cutIndex }

        onProgress("Entraînement du modèle « situation »…")
        val logit = trainLogistic(train)
        val evLogit = evaluate("Situation (régression logistique)", test.map { logit.prob(it.x) to it.y })

        onProgress("Recherche de motifs similaires…")
        val knnTrain = Knn.of(train)
        val step = max(1, test.size / maxKnnTests)
        val knnTests = test.filterIndexed { idx, _ -> idx % step == 0 }
        val knnProbs = knnTests.mapIndexed { idx, s ->
            if (idx % 50 == 0) onProgress("Recherche de motifs similaires… ${idx * 100 / knnTests.size} %")
            knnTrain.prob(s.shape) to s.y
        }
        val evKnn = evaluate("Motifs similaires (${K} plus proches)", knnProbs)

        onProgress("Modèle final sur tout l'historique…")
        val finalLogit = trainLogistic(samples)
        val finalKnn = Knn.of(samples)
        return TrainResult(
            candles = candles.size,
            trainN = train.size,
            testN = test.size,
            testStartEpoch = candles[cutIndex].epoch,
            baseRateTest = test.count { it.y == 1 }.toDouble() / test.size,
            logistic = evLogit,
            knn = evKnn,
            logisticModel = finalLogit,
            knnModel = finalKnn,
        )
    }

    // ---------- Situation actuelle ----------

    class Prediction(val pLogistic: Double?, val pKnn: Double?, val atr: Double, val price: Double)

    /** Prédiction sur la dernière bougie CLÔTURÉE de [candles]. */
    fun predict(candles: List<Candle>, logit: Logistic?, knn: Knn?): Prediction? {
        if (candles.size < 80) return null
        val a = Analysis(candles)
        val i = a.lastClosed
        val x = features(a, i) ?: return null
        val s = shape(a, i) ?: return null
        return Prediction(logit?.prob(x), knn?.prob(s), atrAt(a, i), candles[i].close)
    }

    fun pct(v: Double) = String.format(Locale.US, "%.1f %%", v * 100)

    /** Agrège des bougies M1 en bougies de [granularity] secondes. */
    fun aggregate(m1: List<Candle>, granularity: Int): List<Candle> {
        if (granularity <= 60) return m1
        val out = ArrayList<Candle>()
        var curStart = -1L
        var o = 0.0; var h = 0.0; var l = 0.0; var cl = 0.0
        for (c in m1) {
            val start = c.epoch - Math.floorMod(c.epoch, granularity.toLong())
            if (start != curStart) {
                if (curStart >= 0) out.add(Candle(curStart, o, h, l, cl))
                curStart = start; o = c.open; h = c.high; l = c.low; cl = c.close
            } else {
                h = max(h, c.high); l = min(l, c.low); cl = c.close
            }
        }
        if (curStart >= 0) out.add(Candle(curStart, o, h, l, cl))
        return out
    }

    @Suppress("unused")
    private fun logit(p: Double) = ln(p / (1 - p))
}
