package com.synthcompanion.app

import android.content.Context
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale
import kotlin.math.abs

/** Fenêtre d'ouverture d'une position fictive, utilisée en direct et en replay. */
object TradeTicket {

    fun show(
        ctx: Context,
        side: Side,
        symbol: String,
        symbolName: String,
        timeframe: String,
        price: Double,
        atr: Double,
        decimals: Int,
        mode: TradeMode,
        epoch: Long,
        onCreated: (PaperTrade) -> Unit,
    ) {
        if (price.isNaN() || price <= 0) {
            Toast.makeText(ctx, "Pas de prix disponible pour l'instant", Toast.LENGTH_SHORT).show()
            return
        }
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val fmtS = "%.${decimals}f"
        fun fmt(v: Double) = String.format(Locale.US, fmtS, v)
        fun parse(e: EditText) = e.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val buy = side == Side.BUY
        val a = if (atr > 0) atr else price * 0.001

        fun label(t: String) = TextView(ctx).apply {
            text = t
            textSize = 12f
            setTextColor(ContextCompat.getColor(ctx, R.color.muted))
            setPadding(0, dp(10), 0, 0)
        }
        fun number(v: Double?) = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            if (v != null) setText(fmt(v))
        }

        val etStop = number(if (buy) price - 1.5 * a else price + 1.5 * a)
        val etTarget = number(if (buy) price + 3 * a else price - 3 * a)
        val balance = Journal.balance()
        val minLot = Contracts.minLot(symbol)
        var byLot = Journal.sizeByLot
        val etRisk = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val sizeLabel = label("")
        fun defaultLot(stop: Double?): Double {
            Journal.lastLot(symbol)?.let { return it }
            val fromRisk = if (stop != null) Contracts.lotFor(balance * Journal.riskPercent / 100, price, stop) else 0.0
            return maxOf(fromRisk, minLot ?: 0.0).takeIf { it > 0 } ?: (minLot ?: 0.01)
        }
        fun fmtLot(v: Double) = String.format(Locale.US, if (v < 0.1) "%.3f" else "%.2f", v)
        fun applySizeMode() {
            sizeLabel.text = if (byLot) {
                "Volume en lots (MT5)" + (minLot?.let { " — minimum indicatif ${fmtLot(it)}" } ?: "")
            } else "Risque en % du capital"
        }
        val rgSize = android.widget.RadioGroup(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            val rbLot = android.widget.RadioButton(ctx).apply { id = android.view.View.generateViewId(); text = "Lot" }
            val rbPct = android.widget.RadioButton(ctx).apply { id = android.view.View.generateViewId(); text = "% du capital" }
            addView(rbLot)
            addView(rbPct)
            check(if (byLot) rbLot.id else rbPct.id)
            setOnCheckedChangeListener { _, checkedId ->
                val stop = parse(etStop)
                val v = parse(etRisk)
                val toLot = checkedId == rbLot.id
                if (toLot == byLot) return@setOnCheckedChangeListener
                // Conversion de la valeur saisie vers l'autre unité
                if (stop != null && v != null && abs(price - stop) > 0) {
                    etRisk.setText(
                        if (toLot) fmtLot(Contracts.lotFor(balance * v / 100, price, stop))
                        else String.format(Locale.US, "%.2f", Contracts.riskFor(v, price, stop) / balance * 100)
                    )
                }
                byLot = toLot
                applySizeMode()
            }
        }
        etRisk.setText(
            if (byLot) fmtLot(defaultLot(parse(etStop)))
            else String.format(Locale.US, "%.1f", Journal.riskPercent)
        )
        applySizeMode()
        val spSetup = Spinner(ctx).apply {
            adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, Journal.SETUPS)
            setSelection(Journal.SETUPS.indexOf(Journal.lastSetup).coerceAtLeast(0))
        }
        val etNote = EditText(ctx).apply {
            hint = "Pourquoi j'entre ? (facultatif)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 4
        }
        val tvInfo = TextView(ctx).apply {
            textSize = 13f
            setTextColor(ContextCompat.getColor(ctx, R.color.text))
            setPadding(0, dp(12), 0, 0)
        }
        fun riskAmountNow(stop: Double?): Double? {
            val v = parse(etRisk) ?: return null
            return if (byLot) {
                if (stop == null) null else Contracts.riskFor(v, price, stop)
            } else balance * v / 100
        }

        fun refreshInfo() {
            val stop = parse(etStop)
            val target = parse(etTarget)
            val risk = riskAmountNow(stop) ?: 0.0
            val sb = StringBuilder()
            sb.append("Capital fictif : ${String.format(Locale.US, "%.2f", balance)} $\n")
            if (stop != null && abs(price - stop) > 0) {
                val lot = if (byLot) parse(etRisk) ?: 0.0 else Contracts.lotFor(risk, price, stop)
                sb.append("Volume : ${fmtLot(lot)} lot · ")
                sb.append("${String.format(Locale.US, "%.3f", lot * Contracts.CONTRACT_SIZE)} $ par unité de prix\n")
            }
            sb.append("Risque : ${String.format(Locale.US, "%.2f", risk)} $ (${String.format(Locale.US, "%.2f", risk / balance * 100)} % du capital) si le stop est touché")
            if (stop != null && abs(price - stop) > 0) {
                sb.append("\nStop à ${String.format(Locale.US, "%.1f", abs(price - stop) / a)} ATR")
                if (target != null) sb.append(" · R:R 1:${String.format(Locale.US, "%.1f", abs(target - price) / abs(price - stop))}")
            }
            tvInfo.text = sb
        }
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = refreshInfo()
        }
        etStop.addTextChangedListener(watcher)
        etTarget.addTextChangedListener(watcher)
        etRisk.addTextChangedListener(watcher)
        refreshInfo()

        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
            addView(label("Stop (obligatoire) — proposé à 1,5 ATR"))
            addView(etStop)
            addView(label("Objectif (facultatif) — proposé à 3 ATR, vide = sans objectif"))
            addView(etTarget)
            addView(label("Taille de la position"))
            addView(rgSize)
            addView(sizeLabel)
            addView(etRisk)
            addView(label("Setup"))
            addView(spSetup)
            addView(label("Note"))
            addView(etNote)
            addView(tvInfo)
        }

        // Plein écran : les boutons restent toujours visibles en bas, même clavier ouvert.
        val dialog = android.app.Dialog(ctx, R.style.Theme_SynthCompanion)
        val sideColor = ContextCompat.getColor(ctx, if (buy) R.color.up else R.color.down)
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
            addView(TextView(ctx).apply {
                text = "${if (buy) "▲ ACHAT" else "▼ VENTE"} fictif · $symbolName $timeframe"
                textSize = 20f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(sideColor)
            })
            addView(TextView(ctx).apply {
                text = if (mode == TradeMode.LIVE) "Entrée au marché, au prix du moment où tu valides (≈ ${fmt(price)})"
                else "Entrée à la clôture de la bougie : ${fmt(price)} (replay)"
                textSize = 13f
                setTextColor(ContextCompat.getColor(ctx, R.color.muted))
            })
        }
        val btnCancel = com.google.android.material.button.MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Annuler"
            setOnClickListener { dialog.dismiss() }
        }
        val btnOk = com.google.android.material.button.MaterialButton(ctx).apply {
            text = if (buy) "ACHETER" else "VENDRE"
            textSize = 16f
            backgroundTintList = android.content.res.ColorStateList.valueOf(sideColor)
            setTextColor(android.graphics.Color.WHITE)
        }
        val footer = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(8), dp(16), dp(12))
            setBackgroundColor(ContextCompat.getColor(ctx, R.color.surface))
            addView(btnCancel, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginEnd = dp(8) })
            addView(btnOk, LinearLayout.LayoutParams(0, dp(56), 2f))
        }
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(ctx, R.color.bg))
            addView(header)
            addView(ScrollView(ctx).apply { addView(box) }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(footer)
        }
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime())
            // max et non somme : selon la version d'Android, le clavier est déjà déduit ou non
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }

        btnOk.setOnClickListener {
            // En direct, l'ordre part au prix actuel (comme un ordre au marché)
            val entry = if (mode == TradeMode.LIVE) MarketHub.lastPrice.takeIf { !it.isNaN() } ?: price else price
            val openEpoch = if (mode == TradeMode.LIVE) MarketHub.serverNow() else epoch
            val stop = parse(etStop)
            val targetText = etTarget.text.toString().trim()
            val target = if (targetText.isEmpty()) null else parse(etTarget)
            val sizeVal = parse(etRisk)
            val riskAmount = if (sizeVal == null || stop == null) null
                else if (byLot) Contracts.riskFor(sizeVal, entry, stop) else balance * sizeVal / 100
            val err = when {
                stop == null -> "Stop invalide"
                buy && stop >= entry -> "Pour un achat, le stop doit être sous le prix d'entrée (${fmt(entry)})"
                !buy && stop <= entry -> "Pour une vente, le stop doit être au-dessus du prix d'entrée (${fmt(entry)})"
                targetText.isNotEmpty() && target == null -> "Objectif invalide"
                target != null && buy && target <= entry -> "Pour un achat, l'objectif doit être au-dessus du prix d'entrée"
                target != null && !buy && target >= entry -> "Pour une vente, l'objectif doit être sous le prix d'entrée"
                sizeVal == null || sizeVal <= 0 -> if (byLot) "Volume invalide" else "Risque invalide"
                !byLot && sizeVal > 20 -> "Risque maximum : 20 % du capital"
                riskAmount == null || riskAmount <= 0 -> "Risque invalide"
                else -> null
            }
            if (err != null) {
                Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val setup = Journal.SETUPS[spSetup.selectedItemPosition.coerceIn(0, Journal.SETUPS.size - 1)]
            Journal.lastSetup = setup
            Journal.sizeByLot = byLot
            if (byLot) Journal.setLastLot(symbol, sizeVal!!) else Journal.riskPercent = sizeVal!!
            if (byLot && minLot != null && sizeVal < minLot) {
                Toast.makeText(ctx, "Attention : ${fmtLot(sizeVal)} lot est sous le minimum habituel (${fmtLot(minLot)}) sur MT5", Toast.LENGTH_LONG).show()
            }
            if (riskAmount!! > balance * 0.1) {
                Toast.makeText(ctx, "Ce trade risque plus de 10 % du capital fictif", Toast.LENGTH_LONG).show()
            }
            val t = PaperTrade(
                id = System.currentTimeMillis(),
                symbol = symbol,
                timeframe = timeframe,
                side = side,
                entry = entry,
                stop = stop!!,
                target = target,
                riskAmount = riskAmount,
                lot = if (byLot) sizeVal else Contracts.lotFor(riskAmount, entry, stop),
                openEpoch = openEpoch,
                mode = mode,
                setup = setup,
                note = etNote.text.toString().trim(),
            )
            Journal.add(t)
            dialog.dismiss()
            onCreated(t)
        }

        dialog.setContentView(root)
        dialog.window?.apply {
            setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
            @Suppress("DEPRECATION")
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dialog.show()
    }

    /** Actions sur une position ouverte : clôturer, modifier, supprimer. */
    fun manage(ctx: Context, t: PaperTrade, currentPrice: Double, epoch: Long, decimals: Int, onChanged: () -> Unit) {
        val fmtS = "%.${decimals}f"
        fun fmt(v: Double) = String.format(Locale.US, fmtS, v)
        val r = t.rAt(currentPrice)
        MaterialAlertDialogBuilder(ctx)
            .setTitle("${if (t.side == Side.BUY) "Achat" else "Vente"} ${t.symbol} · ${String.format(Locale.US, "%+.2f R", r)}")
            .setMessage(
                "Entrée ${fmt(t.entry)} · Stop ${fmt(t.stop)} · Objectif ${t.target?.let { fmt(it) } ?: "aucun"}\n" +
                    "Prix actuel ${fmt(currentPrice)} · ${String.format(Locale.US, "%+.2f", r * t.riskAmount)} $\n" +
                    (t.lot?.let { "Volume ${String.format(Locale.US, "%.3f", it)} lot · risque ${String.format(Locale.US, "%.2f", t.riskAmount)} $\n" } ?: "") +
                    "Setup : ${t.setup}" + if (t.note.isNotBlank()) "\nNote : ${t.note}" else ""
            )
            .setPositiveButton("Clôturer maintenant") { _, _ ->
                Journal.close(t.id, currentPrice, epoch, "Manuel")
                onChanged()
            }
            .setNeutralButton("Modifier stop / objectif") { _, _ -> editLevels(ctx, t, decimals, onChanged) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun editLevels(ctx: Context, t: PaperTrade, decimals: Int, onChanged: () -> Unit) {
        val d = ctx.resources.displayMetrics.density
        val fmtS = "%.${decimals}f"
        fun et(v: Double?, hint: String) = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            this.hint = hint
            if (v != null) setText(String.format(Locale.US, fmtS, v))
        }
        val etStop = et(t.stop, "Stop")
        val etTarget = et(t.target, "Objectif (vide = aucun)")
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (8 * d).toInt(), (20 * d).toInt(), 0)
            addView(etStop)
            addView(etTarget)
        }
        MaterialAlertDialogBuilder(ctx)
            .setTitle("Modifier la position")
            .setMessage("Le risque initial (1 R) reste celui de l'entrée : déplacer le stop ne change pas la mesure en R.")
            .setView(box)
            .setPositiveButton("Enregistrer") { _, _ ->
                val stop = etStop.text.toString().replace(',', '.').toDoubleOrNull()
                val tt = etTarget.text.toString().trim()
                val target = if (tt.isEmpty()) null else tt.replace(',', '.').toDoubleOrNull()
                if (stop == null) {
                    Toast.makeText(ctx, "Stop invalide", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                Journal.update(
                    t.copy(
                        stop = stop,
                        target = target,
                        initialStop = t.initialStop ?: if (stop != t.stop) t.stop else null,
                        note = t.note + if (stop != t.stop && !t.note.contains("[stop déplacé]")) " [stop déplacé]" else "",
                    )
                )
                onChanged()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
