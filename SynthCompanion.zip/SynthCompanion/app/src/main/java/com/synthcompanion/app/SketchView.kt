package com.synthcompanion.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Petit schéma pédagogique : bougies (o, h, l, c), courbe de prix, niveaux horizontaux,
 * segments (lignes de tendance) et étiquettes. Les unités sont libres, le schéma s'adapte.
 */
class SketchView(
    context: Context,
    private val candles: List<DoubleArray> = emptyList(),
    private val line: List<Double> = emptyList(),
    private val levels: List<Level> = emptyList(),
    private val segments: List<Segment> = emptyList(),
    private val marks: List<Mark> = emptyList(),
) : View(context) {

    data class Level(val price: Double, val label: String, val color: Int, val dashed: Boolean = true)
    /** Segment entre deux points (index, prix). */
    data class Segment(val i1: Double, val p1: Double, val i2: Double, val p2: Double, val color: Int, val label: String = "")
    /** Texte posé sur le schéma (index, prix). */
    data class Mark(val i: Double, val p: Double, val text: String, val color: Int)

    companion object {
        val UP = Color.parseColor("#26A69A")
        val DOWN = Color.parseColor("#EF5350")
        val GOLD = Color.parseColor("#F0B90B")
        val BLUE = Color.parseColor("#4DA3FF")
        val VIOLET = Color.parseColor("#9AA7FF")
        val GREY = Color.parseColor("#8B949E")
        val WHITE = Color.parseColor("#E6EDF3")

        /** Raccourci : bougie (open, high, low, close). */
        fun c(o: Double, h: Double, l: Double, cl: Double) = doubleArrayOf(o, h, l, cl)
    }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1.5f * d }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
        pathEffect = DashPathEffect(floatArrayOf(5 * d, 4 * d), 0f)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f * d; isFakeBoldText = true }
    private val path = Path()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (130 * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.parseColor("#0E1117"))
        val n = max(max(candles.size, line.size), 1)
        var lo = Double.MAX_VALUE
        var hi = -Double.MAX_VALUE
        candles.forEach { lo = min(lo, it[2]); hi = max(hi, it[1]) }
        line.forEach { lo = min(lo, it); hi = max(hi, it) }
        levels.forEach { lo = min(lo, it.price); hi = max(hi, it.price) }
        segments.forEach { lo = min(lo, min(it.p1, it.p2)); hi = max(hi, max(it.p1, it.p2)) }
        if (hi <= lo) { hi = lo + 1 }
        val padV = (hi - lo) * 0.12
        lo -= padV; hi += padV
        val left = 10 * d
        val right = width - 70 * d
        val top = 8 * d
        val bottom = height - 8 * d
        val step = (right - left) / n
        fun x(i: Double) = (left + (i + 0.5) * step).toFloat()
        fun y(p: Double) = (top + (hi - p) / (hi - lo) * (bottom - top)).toFloat()

        for (lv in levels) {
            val p = if (lv.dashed) dash else stroke
            p.color = lv.color
            canvas.drawLine(left, y(lv.price), right, y(lv.price), p)
            text.color = lv.color
            canvas.drawText(lv.label, right + 4 * d, y(lv.price) + 4 * d, text)
        }
        if (line.isNotEmpty()) {
            path.reset()
            line.forEachIndexed { i, v -> if (i == 0) path.moveTo(x(i.toDouble()), y(v)) else path.lineTo(x(i.toDouble()), y(v)) }
            stroke.color = WHITE
            canvas.drawPath(path, stroke)
        }
        val bw = max(3 * d, (step * 0.55f))
        candles.forEachIndexed { i, k ->
            val cx = x(i.toDouble())
            paint.color = if (k[3] >= k[0]) UP else DOWN
            canvas.drawLine(cx, y(k[1]), cx, y(k[2]), paint)
            val t = y(max(k[0], k[3]))
            var b = y(min(k[0], k[3]))
            if (b - t < 2 * d) b = t + 2 * d
            canvas.drawRect(cx - bw / 2, t, cx + bw / 2, b, paint)
        }
        for (s in segments) {
            stroke.color = s.color
            canvas.drawLine(x(s.i1), y(s.p1), x(s.i2), y(s.p2), stroke)
            if (s.label.isNotEmpty()) {
                text.color = s.color
                canvas.drawText(s.label, x(s.i2) + 4 * d, y(s.p2) + 4 * d, text)
            }
        }
        for (m in marks) {
            text.color = m.color
            text.textAlign = Paint.Align.CENTER
            canvas.drawText(m.text, x(m.i), y(m.p), text)
            text.textAlign = Paint.Align.LEFT
        }
    }
}
