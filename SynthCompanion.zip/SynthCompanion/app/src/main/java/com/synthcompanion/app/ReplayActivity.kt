package com.synthcompanion.app

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random

/**
 * Replay : on revient à un moment du passé, la suite est cachée, et on avance bougie par bougie en
 * prenant des positions fictives. Elles se clôturent sur les bougies suivantes (stop prioritaire si
 * stop et objectif sont touchés dans la même bougie).
 */
class ReplayActivity : AppCompatActivity() {

    private lateinit var chart: ChartView
    private lateinit var tvTitle: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvInfo: TextView
    private lateinit var btnAuto: MaterialButton
    private val keepInFullscreen = ArrayList<View>()

    private var full: List<Candle> = emptyList()
    private var cursor = 0
    private var gran = 60
    private val symbol = MarketHub.symbol
    private val symbolName = MarketHub.shortName()
    private var decimals = MarketHub.decimals()
    private val sessionIds = LinkedHashSet<Long>()

    private val handler = Handler(Looper.getMainLooper())
    private var speed = 0
    private val speedMs = longArrayOf(0, 1000, 400, 150)
    private val speedLabel = arrayOf("▶ Auto", "▶ Auto ×1", "▶ Auto ×2", "▶ Auto ×5")
    private val autoRunnable = object : Runnable {
        override fun run() {
            if (speed == 0) return
            step(1)
            if (speed > 0) handler.postDelayed(this, speedMs[speed])
        }
    }

    private val dateFmt = SimpleDateFormat("EEE dd/MM/yyyy HH:mm", Locale.FRANCE)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Des positions replay restées ouvertes (appli fermée en cours de séance) n'ont plus de sens
        Journal.open(TradeMode.REPLAY).forEach { Journal.delete(it.id) }
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (ChartFullscreen.isOn(chart)) ChartFullscreen.set(this@ReplayActivity, chart, false) else confirmEnd()
            }
        })
        chooseTimeframe()
    }

    private fun btn(text: String, outlined: Boolean = true, onClick: () -> Unit) =
        (if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle) else MaterialButton(this)).apply {
            this.text = text
            textSize = 12f
            setOnClickListener { onClick() }
        }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(6) })
        }
    }

    private fun buildUi() {
        tvTitle = TextView(this).apply {
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(color(R.color.text))
        }
        tvDate = TextView(this).apply { textSize = 12f; setTextColor(color(R.color.accent)) }
        tvInfo = TextView(this).apply { textSize = 12f; setTextColor(color(R.color.muted)); setPadding(0, dp(4), 0, dp(4)) }
        chart = ChartView(this)
        chart.onFullscreenToggle = { ChartFullscreen.set(this, chart, !ChartFullscreen.isOn(chart), keepInFullscreen) }
        btnAuto = btn(speedLabel[0]) { cycleSpeed() }

        val buy = btn("ACHAT", false) { openTicket(Side.BUY) }.apply { backgroundTintList = ColorStateList.valueOf(color(R.color.up)) }
        val sell = btn("VENTE", false) { openTicket(Side.SELL) }.apply { backgroundTintList = ColorStateList.valueOf(color(R.color.down)) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(R.color.bg))
            addView(LinearLayout(this@ReplayActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(tvTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                addView(btn("Terminer") { confirmEnd() })
            })
            addView(tvDate)
            addView(chart, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(4) })
            addView(tvInfo)
            val controls1 = row(btn("+1 bougie") { stopAuto(); step(1) }, btn("+10") { stopAuto(); step(10) }, btnAuto)
            val controls2 = row(buy, sell, btn("Positions") { showPositions() })
            keepInFullscreen.add(controls1)
            keepInFullscreen.add(controls2)
            addView(controls1)
            addView(controls2)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(12), b.top + dp(6), b.right + dp(12), b.bottom + dp(6))
            insets
        }
        setContentView(root)
        tvTitle.text = "Replay · $symbolName"
    }

    // ---------- Préparation ----------

    private fun chooseTimeframe() {
        val labels = Timeframes.list.map { it.second }.toTypedArray()
        val current = Timeframes.list.indexOfFirst { it.first == MarketHub.granularity }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Replay · unité de temps")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                gran = Timeframes.list[which].first
                dialog.dismiss()
                chooseStart()
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private val startChoices = listOf(
        "Au hasard (recommandé : pas de biais)" to -1L,
        "Il y a 1 jour" to 86_400L,
        "Il y a 3 jours" to 3 * 86_400L,
        "Il y a 1 semaine" to 7 * 86_400L,
        "Il y a 2 semaines" to 14 * 86_400L,
        "Il y a 1 mois" to 30 * 86_400L,
    )

    private fun chooseStart() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Point de départ")
            .setItems(startChoices.map { it.first }.toTypedArray()) { _, which -> load(startChoices[which].second) }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun load(secondsBack: Long) {
        val progress = MaterialAlertDialogBuilder(this)
            .setTitle("Chargement de l'historique")
            .setMessage("Récupération des bougies ${Timeframes.label(gran)}…")
            .setCancelable(false)
            .show()
        MarketHub.fetchCandlesPaged(symbol, gran, 5000, { n -> progress.setMessage("$n bougies récupérées…") }) { list ->
            progress.dismiss()
            if (list == null || list.size < 300) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Historique indisponible")
                    .setMessage("Impossible de récupérer assez de bougies. Vérifie que l'appli est connectée à Deriv.")
                    .setPositiveButton("OK") { _, _ -> finish() }
                    .setCancelable(false)
                    .show()
                return@fetchCandlesPaged
            }
            full = list
            val minStart = 150
            val maxStart = full.size - 60
            cursor = if (secondsBack < 0) {
                minStart + Random().nextInt(maxOf(1, maxStart - minStart))
            } else {
                val back = (secondsBack / gran).toInt()
                val c = full.size - 1 - back
                if (c < minStart) toast("Pas assez d'historique en ${Timeframes.label(gran)} : départ au plus ancien possible")
                c.coerceIn(minStart, maxStart)
            }
            tvTitle.text = "Replay · $symbolName ${Timeframes.label(gran)}"
            render()
            MaterialAlertDialogBuilder(this)
                .setTitle("C'est parti")
                .setMessage(
                    "La suite du graphique est cachée. Analyse la situation, prends position si tu veux " +
                        "(ACHAT / VENTE), puis avance avec « +1 bougie » ou « Auto ».\n\n" +
                        "Conseil : décide et note ton plan AVANT d'avancer. Les trades vont dans ton journal (mode Replay)."
                )
                .setPositiveButton("Compris", null)
                .show()
        }
    }

    // ---------- Déroulé ----------

    private fun sessionTrades(): List<PaperTrade> = Journal.all().filter { it.id in sessionIds }

    private fun step(n: Int) {
        if (full.isEmpty()) return
        val closedNow = ArrayList<PaperTrade>()
        for (k in 0 until n) {
            if (cursor >= full.size - 1) {
                stopAuto()
                toast("Fin des données disponibles")
                break
            }
            cursor++
            val c = full[cursor]
            for (t in sessionTrades().filter { it.isOpen }) {
                val ex = t.exitFor(c.low, c.high) ?: continue
                Journal.close(t.id, ex.first, c.epoch, ex.second)?.let { closedNow.add(it) }
            }
        }
        render()
        if (closedNow.isNotEmpty()) {
            stopAuto()
            val t = closedNow.last()
            toast("${if (t.r >= 0) "✅" else "❌"} ${t.reason} : ${String.format(Locale.US, "%+.2f R", t.r)}")
        }
    }

    private fun cycleSpeed() {
        speed = (speed + 1) % speedMs.size
        btnAuto.text = if (speed == 0) speedLabel[0] else "⏸ ${speedLabel[speed].removePrefix("▶ ")}"
        handler.removeCallbacks(autoRunnable)
        if (speed > 0) handler.postDelayed(autoRunnable, speedMs[speed])
    }

    private fun stopAuto() {
        speed = 0
        handler.removeCallbacks(autoRunnable)
        if (::btnAuto.isInitialized) btnAuto.text = speedLabel[0]
    }

    private fun render() {
        if (full.isEmpty()) return
        val visible = ArrayList(full.subList(0, cursor + 1))
        val analysis = Analysis(visible)
        val tools = Tool.values().filter { MarketHub.toolEnabled(it) }.toSet()
        val t = analysis.lastClosed
        val overlay = if (visible.size >= 60) analysis.structure.overlayAt(t, visible.last().close) else ChartOverlay.EMPTY
        val sigs = if (Tool.SIGNALS in tools) analysis.signals(MarketHub.strategy, MarketHub.slAtr, MarketHub.tpAtr) else emptyList()
        chart.setData(visible, decimals, gran, emptyList(), analysis, sigs, null, overlay, tools)
        val session = sessionTrades()
        chart.setTrades(session.filter { it.isOpen }, session.filter { !it.isOpen })

        val c = visible.last()
        tvDate.text = dateFmt.format(Date(c.epoch * 1000)) + "  ·  bougie ${cursor + 1}/${full.size} (${full.size - 1 - cursor} cachées)"
        val closed = session.filter { !it.isOpen }
        val open = session.filter { it.isOpen }
        val totalR = closed.sumOf { it.r }
        val openR = open.sumOf { it.rAt(c.close) }
        tvInfo.text = "Séance : ${closed.size} trade${if (closed.size > 1) "s" else ""} clôturé${if (closed.size > 1) "s" else ""} · " +
            String.format(Locale.US, "%+.2f R", totalR) +
            (if (open.isNotEmpty()) " · ${open.size} ouvert${if (open.size > 1) "s" else ""} (${String.format(Locale.US, "%+.2f R", openR)})" else "") +
            " · capital ${String.format(Locale.US, "%.2f", Journal.balance())} $"
    }

    // ---------- Positions ----------

    private fun openTicket(side: Side) {
        if (full.isEmpty()) return
        stopAuto()
        val visible = full.subList(0, cursor + 1)
        val atr = Indicators.atr(visible.takeLast(200), 14).lastOrNull { !it.isNaN() } ?: 0.0
        TradeTicket.show(
            this, side, symbol, symbolName, Timeframes.label(gran), visible.last().close, atr, decimals,
            TradeMode.REPLAY, visible.last().epoch,
        ) { t ->
            sessionIds.add(t.id)
            render()
        }
    }

    private fun showPositions() {
        stopAuto()
        val open = sessionTrades().filter { it.isOpen }
        if (open.isEmpty()) {
            toast("Aucune position ouverte dans ce replay")
            return
        }
        val c = full[cursor]
        val labels = open.map {
            "${if (it.side == Side.BUY) "▲ Achat" else "▼ Vente"} · ${String.format(Locale.US, "%+.2f R", it.rAt(c.close))}"
        }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Positions ouvertes")
            .setItems(labels) { _, which -> TradeTicket.manage(this, open[which], c.close, c.epoch, decimals) { render() } }
            .setNegativeButton("Fermer", null)
            .show()
    }

    // ---------- Fin de séance ----------

    private fun confirmEnd() {
        stopAuto()
        if (sessionIds.isEmpty()) {
            finish()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Terminer le replay ?")
            .setMessage("Les positions encore ouvertes seront clôturées au prix actuel.")
            .setPositiveButton("Terminer") { _, _ -> endSession() }
            .setNegativeButton("Continuer", null)
            .show()
    }

    private fun closeOpenSessionTrades() {
        if (full.isEmpty()) return
        val c = full[cursor]
        for (t in sessionTrades().filter { it.isOpen }) Journal.close(t.id, c.close, c.epoch, "Manuel")
    }

    private fun endSession() {
        closeOpenSessionTrades()
        val trades = sessionTrades()
        val stats = JournalStats(trades, 0.0)
        val msg = StringBuilder()
        if (stats.n == 0) {
            msg.append("Aucun trade pendant cette séance.")
        } else {
            msg.append("${stats.n} trade${if (stats.n > 1) "s" else ""} · ${String.format(Locale.US, "%.0f", stats.winRate)} % gagnants\n")
            msg.append("Résultat : ${String.format(Locale.US, "%+.2f R", stats.totalR)} · ${String.format(Locale.US, "%+.2f $", stats.totalPnl)}\n")
            val candlesSeen = cursor
            msg.append("\n")
            stats.insights().take(3).forEach { msg.append("• ").append(it).append("\n") }
            if (candlesSeen > 0) msg.append("\nPour une vraie mesure, cumule plusieurs séances : le journal additionne tous tes replays.")
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Bilan du replay")
            .setMessage(msg.toString())
            .setPositiveButton("Voir le journal") { _, _ ->
                startActivity(Intent(this, JournalActivity::class.java))
                finish()
            }
            .setNeutralButton("Nouveau replay") { _, _ -> recreate() }
            .setNegativeButton("Quitter") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoRunnable)
        if (isFinishing) closeOpenSessionTrades()
        super.onDestroy()
    }
}
