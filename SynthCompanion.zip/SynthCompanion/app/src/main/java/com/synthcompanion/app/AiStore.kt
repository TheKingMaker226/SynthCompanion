package com.synthcompanion.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Modèles IA entraînés, sauvegardés par indice et unité de temps. */
object AiStore {

    class Saved(
        val symbol: String,
        val granularity: Int,
        val trainedAt: Long,
        val model: AiEngine.Logistic,
        val validated: Boolean,
        val z: Double,
        val confidentAcc: Double,
        val confidentN: Int,
        val testN: Int,
        val knnValidated: Boolean,
        val knnZ: Double,
        val knnAcc: Double,
    )

    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("ai_models", Context.MODE_PRIVATE)
    }

    private fun key(symbol: String, gran: Int) = "m_${symbol}_$gran"

    /** Signaux IA en direct (seulement pour un modèle validé). */
    var liveSignals: Boolean
        get() = prefs.getBoolean("live_signals", false)
        set(v) = prefs.edit().putBoolean("live_signals", v).apply()

    var lastSignalEpoch: Long
        get() = prefs.getLong("last_signal_epoch", -1)
        set(v) = prefs.edit().putLong("last_signal_epoch", v).apply()

    fun save(symbol: String, gran: Int, r: AiEngine.TrainResult) {
        val m = r.logisticModel
        fun arr(a: DoubleArray) = JSONArray().apply { a.forEach { put(it) } }
        val o = JSONObject()
            .put("symbol", symbol).put("gran", gran).put("trained_at", System.currentTimeMillis())
            .put("w", arr(m.w)).put("b", m.b).put("mean", arr(m.mean)).put("std", arr(m.std))
            .put("validated", r.logistic.validated).put("z", r.logistic.z)
            .put("conf_acc", r.logistic.confidentAcc).put("conf_n", r.logistic.confidentN).put("test_n", r.testN)
            .put("knn_validated", r.knn.validated).put("knn_z", r.knn.z).put("knn_acc", r.knn.confidentAcc)
        prefs.edit().putString(key(symbol, gran), o.toString()).apply()
    }

    fun get(symbol: String, gran: Int): Saved? {
        val raw = prefs.getString(key(symbol, gran), null) ?: return null
        return try {
            val o = JSONObject(raw)
            fun arr(name: String): DoubleArray {
                val a = o.getJSONArray(name)
                return DoubleArray(a.length()) { a.getDouble(it) }
            }
            Saved(
                symbol, gran, o.getLong("trained_at"),
                AiEngine.Logistic(arr("w"), o.getDouble("b"), arr("mean"), arr("std")),
                o.getBoolean("validated"), o.getDouble("z"), o.getDouble("conf_acc"), o.getInt("conf_n"), o.getInt("test_n"),
                o.optBoolean("knn_validated"), o.optDouble("knn_z", 0.0), o.optDouble("knn_acc", 0.0),
            )
        } catch (_: Exception) {
            null
        }
    }

    fun delete(symbol: String, gran: Int) = prefs.edit().remove(key(symbol, gran)).apply()
}
