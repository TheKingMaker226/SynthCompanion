package com.synthcompanion.app

import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Suivi des prédictions : captures, résultats vérifiés automatiquement et score face au hasard. */
class SuiviActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private val dateFmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { setBackgroundColor(color(R.color.bg)); addView(content) }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(14), b.top + dp(8), b.right + dp(14), b.bottom + dp(12))
            insets
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
        Predictions.evaluatePending(ArrayList(MarketHub.candles), MarketHub.symbol, MarketHub.granularity) { n ->
            if (n > 0 && !isFinishing) render()
        }
    }

    private fun text(t: String, size: Float = 13f, col: Int = R.color.text, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color(col))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.15f)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(color(R.color.surface))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        }
    }

    private fun arrow(v: Int) = when (v) { 1 -> "↑"; -1 -> "↓"; else -> "—" }

    private fun render() {
        content.removeAllViews()
        content.addView(text("📈 Suivi des prédictions", 22f, bold = true))
        content.addView(text(
            "Capture une prédiction depuis le menu (📸). L'appli fige l'avis de chaque outil et le tien, puis vérifie toute seule " +
                "si le prix a d'abord monté (↑) ou baissé (↓) de 1 ATR dans les 50 bougies suivantes. " +
                "En replay, le résultat est connu tout de suite.",
            12.5f, R.color.muted,
        ).apply { setPadding(0, dp(4), 0, 0) })

        val snaps = Predictions.all()
        val judged = snaps.count { it.result != null }
        val sc = card()
        sc.addView(text("🏁 Score", 15f, R.color.accent, true))
        for (s in Predictions.scores(snaps)) {
            sc.addView(text(
                "${s.name} : ${if (s.n == 0) "—" else "${s.ok} / ${s.n} justes (${Prob.pct(s.rate)})"}",
                13.5f,
            ).apply { setPadding(0, dp(3), 0, 0) })
        }
        sc.addView(text("Pile ou face : 50 %", 13f, R.color.muted).apply { setPadding(0, dp(3), 0, 0) })
        sc.addView(text(
            if (judged < 30) "Encore ${30 - judged} captures jugées avant de pouvoir conclure : sur peu de cas, 70 % de réussite arrive souvent par hasard."
            else "Une vraie récurrence se verrait comme une réussite nettement au-dessus de 50 % qui se maintient dans le temps.",
            12f, R.color.muted,
        ).apply { setPadding(0, dp(6), 0, 0) })
        content.addView(sc)

        if (snaps.isEmpty()) {
            content.addView(text("Aucune capture pour l'instant.", 13f, R.color.muted).apply { setPadding(0, dp(12), 0, 0) })
            return
        }
        for (s in snaps.take(100)) content.addView(snapCard(s))
    }

    private fun snapCard(s: Predictions.Snap): View {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val f = Predictions.imageFile(s)
        if (f.exists()) {
            val img = ImageView(this).apply {
                val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                setImageBitmap(BitmapFactory.decodeFile(f.absolutePath, opts))
                scaleType = ImageView.ScaleType.CENTER_CROP
                setOnClickListener { showImage(f.absolutePath) }
            }
            row.addView(img, LinearLayout.LayoutParams(dp(110), dp(72)).apply { marginEnd = dp(10) })
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(text("${MarketHub.shortName(s.symbol)} ${Timeframes.label(s.granularity)} · ${dateFmt.format(Date(s.epoch * 1000))} · ${s.mode}", 13f, bold = true))
        info.addView(text("Prix ${String.format(Locale.US, "%.2f", s.price)} · ATR ${String.format(Locale.US, "%.2f", s.atr)}", 12f, R.color.muted))
        val r = s.result
        fun chip(name: String, v: Int): String {
            if (v == 0) return ""
            val mark = when {
                r == null -> " ⏳"
                r == 0 -> ""
                r == v -> " ✓"
                else -> " ✗"
            }
            return "$name ${arrow(v)}$mark   "
        }
        info.addView(text(
            chip("Toi", s.user) + chip("Formes (${s.simUp}↑/${s.simDown}↓)", s.similar) + chip("Tendance", s.trend) + chip("RSI", s.rsi),
            12.5f,
        ))
        info.addView(text(
            when (r) {
                null -> "⏳ En attente (jusqu'à ${Predictions.HORIZON} bougies)"
                1 -> "Résultat : ↑ +1 ATR atteint d'abord en ${s.bars} bougies"
                -1 -> "Résultat : ↓ −1 ATR atteint d'abord en ${s.bars} bougies"
                else -> "Résultat : indécis"
            },
            12.5f, when (r) { 1 -> R.color.up; -1 -> R.color.down; else -> R.color.muted },
        ))
        if (s.note.isNotEmpty()) info.addView(text("📝 ${s.note}", 12f, R.color.muted))
        info.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Supprimer"
            textSize = 11f
            setOnClickListener {
                Predictions.delete(s.id)
                render()
            }
        })
        row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        c.addView(row)
        return c
    }

    private fun showImage(path: String) {
        val img = ImageView(this).apply {
            setImageBitmap(BitmapFactory.decodeFile(path))
            adjustViewBounds = true
        }
        MaterialAlertDialogBuilder(this).setView(img).setPositiveButton("Fermer", null).show()
    }
}
