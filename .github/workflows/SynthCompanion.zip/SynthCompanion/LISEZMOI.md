# Synth Companion

Compagnon Android pour les indices synthétiques Deriv (Volatility 50 (1s), V10, V75, V100, etc.),
à utiliser à côté de MT5.

## Ce que fait l'appli
- **Données en direct** depuis l'API publique Deriv (pas besoin de lire l'écran de MT5).
- **Graphique en chandeliers** M1 à D1, avec EMA 20, EMA 50 et RSI 14.
  Glisser = historique · pincer = zoom · double-tap = retour au direct · appui long = alerte à ce prix.
- **Compte à rebours** avant la clôture de la bougie, synchronisé sur l'heure du serveur Deriv.
- **Alerte avant clôture** (5 à 60 s avant), par notification et vibration.
- **Alertes de prix** (le sens hausse ou baisse est déduit du prix actuel), gardées sur le téléphone.
- **Bulle flottante** déplaçable par-dessus MT5 : indice, prix, compte à rebours. Toucher la bulle ouvre l'appli.
- **Signaux d'entrée** selon la stratégie choisie (croisement EMA 20/50, rebond RSI 30/70, ou cassure
  des 20 dernières bougies), évalués à chaque clôture de bougie. Tu reçois une notification avec
  l'entrée, le stop et l'objectif, calculés en multiples d'ATR (1,5 et 3 ATR par défaut). Flèches sur le graphique,
  lignes SL/TP pour le trade en cours.
- **Analyse et rapport** : tendance, RSI, volatilité, dernier signal et son statut, et test des trois
  stratégies sur les 1 000 dernières bougies (taux de réussite, total en R, pire baisse, séries de pertes).
  Le rapport peut être partagé par WhatsApp, e-mail, etc.
- **Outils de tracé** (bouton « Outils », à cocher un par un) : supports et résistances (zones touchées
  plusieurs fois), lignes de tendance (les plus fortes, épaisses à partir de 3 touches), retracements et
  extensions de Fibonacci sur la jambe en cours, figures chartistes (double sommet ou creux,
  épaule-tête-épaule, triangles, biseaux, canaux), figures de bougies (E englobante, P pin bar, ★ étoile,
  3 soldats ou corbeaux). Tout s'adapte à l'unité de temps choisie, de M1 à D1.
- **Stratégie « Price action »** : une bougie de retournement posée sur un support ou une ligne de tendance,
  dans le sens de la tendance. Le stop se place sous (ou sur) la mèche.
- **Rapport multi-unités** : tendance, RSI, figures et bougies sur M1, M5, M15, H1, H4 et D1, détail des niveaux
  de l'unité affichée, et une proposition d'entrée (zone, stop, objectif, R:R) pour chaque unité de temps.
- **Labo statistique** (bouton « Labo ») : sur 3 000 bougies réelles, vérifie si les règles du trading
  font mieux que le hasard : mémoire des mouvements, tendance ou retour à la moyenne, respect des
  supports et résistances (comparés à de faux niveaux), fiabilité de chaque figure de bougie, et
  stratégies rejouées contre 40 copies de l'historique mélangé. Chaque test donne un score z
  (au-delà de ±1,96 = écart significatif).
- **Données CSV** (bouton « Labo » → « Données CSV ») : téléchargement de l'historique (jusqu'à 20 000 bougies
  de l'unité de temps affichée, ou 20 000 ticks bruts), et enregistrement continu de chaque tick reçu en direct
  (fichier `ticks_<indice>.csv`, qui continue en arrière-plan). Les fichiers s'enregistrent où tu veux
  (Téléchargements, Drive…) via le sélecteur de fichiers d'Android. Colonnes : `epoch,date_utc,open,high,low,close`
  ou `epoch,date_utc,prix` (heure UTC).
- **Sonnerie façon réveil** : à cocher pour chaque alerte de prix (« ⏰ Sonner comme un réveil ») et pour
  les signaux (menu Signaux). La sonnerie d'alarme du téléphone joue en boucle, même en mode silencieux,
  avec vibration et un écran d'alarme par-dessus le verrouillage. Arrêt avec le bouton, ou seule après 90 s.
  Bouton « Tester la sonnerie » dans la fenêtre de création d'alerte.
- **Trading fictif** : boutons ACHAT / VENTE sur un capital virtuel (1 000 $ par défaut). Stop obligatoire
  (proposé à 1,5 ATR), objectif facultatif, taille en **lots** (comme sur MT5 : 1 lot = 1 $ par unité de prix)
  ou en % du capital, setup et note. La position se clôture
  seule au stop ou à l'objectif sur les prix en direct, ou à la main (« Positions »).
- **Journal** (Menu → Journal) : courbe du capital, chiffres clés (taux de réussite, R moyen, facteur de
  profit, pire baisse), répartition par setup, sens, unité de temps, façon de sortir et heure, conseils
  automatiques (gains coupés trop tôt, trades pris juste après une perte…), export CSV.
- **Mode replay** (Menu → Mode replay) : retour à un moment passé (au hasard ou il y a 1 jour à 1 mois),
  la suite est cachée, on avance bougie par bougie (+1, +10, lecture auto) en prenant des positions.
  Les trades vont dans le journal en mode « Replay ».
- **Centre de notifications** (🔔 en haut) : historique de toutes les alertes, suppression une par une ou
  en bloc. L'ouvrir retire les notifications du téléphone et le chiffre sur l'icône.
- **Guide des outils** (Menu → Guide) : légende du graphique, figures de bougies, supports/résistances,
  lignes de tendance, Fibonacci, figures chartistes, EMA/RSI/ATR, signaux et gestion du risque. Pour chaque
  outil : ce que c'est, comment l'appli le détecte, comment prendre position (entrée, stop, objectif), pièges,
  avec des schémas.
- **Stockage automatique** (Menu → Données stockées) : base SQLite sur le téléphone avec toutes les bougies M1
  des indices suivis (V50 (1s) + chaque indice affiché). Synchronisation toutes les minutes, trous comblés à la
  reconnexion, historique initial réglable (7 à 365 jours), export CSV en M1 à D1.
- **IA locale** (Menu → IA) : deux modèles (« situation » = régression logistique sur 20 caractéristiques,
  « motifs similaires » = 50 formes de prix passées les plus proches). Apprentissage sur 70 % de l'historique,
  jugement sur les 30 % les plus récents jamais vus. Validé seulement si z ≥ 2,5 sur au moins 100 cas.
  Signaux IA en direct uniquement avec un modèle validé.
- **Inversion de polarité** : détection automatique des zones cassées puis retestées (support ↔ résistance).
  Alerte en direct avec plan d'entrée (menu Signaux), test dédié dans le Labo (vrais niveaux contre faux
  niveaux), et 3 caractéristiques supplémentaires pour l'IA (distance, ancienneté, retour sur niveau cassé).
- Tourne en arrière-plan (service avec notification permanente et bouton « Arrêter »).

## Compiler et installer
1. Installe **Android Studio** (gratuit) sur ton ordinateur.
2. *File → Open* → choisis le dossier `SynthCompanion`. Attends la fin de la synchronisation Gradle
   (Android Studio télécharge lui-même le SDK et les dépendances).
3. Branche ton téléphone en USB, avec le **débogage USB** activé (Options pour les développeurs), puis ▶ *Run*.
   Ou bien *Build → Build App Bundle(s) / APK(s) → Build APK(s)*, puis copie
   `app/build/outputs/apk/debug/app-debug.apk` sur le téléphone et installe-le
   (autorise l'installation de sources inconnues).
4. Au premier lancement, accepte les notifications. Pour la bulle, touche « Bulle » puis autorise
   « Afficher par-dessus les autres applis ».

Android 8.0 minimum.

## À faire avant un usage régulier
- **Identifiant d'application Deriv** : le code utilise `1089`, l'identifiant de test public.
  Crée le tien gratuitement dans l'espace développeurs de Deriv et remplace `APP_ID`
  dans `MarketHub.kt`. Si Deriv change l'adresse de son API, modifie `WS_URL` au même endroit.
- **Batterie** : certains téléphones (Xiaomi, Huawei, Samsung…) tuent les applis en arrière-plan.
  Mets Synth Companion en « Sans restriction » dans les réglages de batterie si les alertes n'arrivent pas.

## Limites
- Les alertes de prix ne surveillent que **l'indice affiché** dans l'appli (une seule connexion de flux).
- L'unité de temps n'est pas détectée automatiquement depuis MT5 : choisis-la dans l'appli
  (c'est ce qui évite la permission d'accessibilité).
- Les indices synthétiques sont générés par un algorithme aléatoire. Les indicateurs et figures
  décrivent le passé mais ne prédisent rien. Cet outil ne donne aucun conseil financier.

## Lire les résultats du test
- **R** = le montant risqué sur un trade (la distance jusqu'au stop). +2 R = tu gagnes deux fois ce que tu risquais.
- Avec un stop à 1,5 ATR et un objectif à 3 ATR, il faut plus de 33,3 % de trades gagnants pour être rentable.
- Le test ne compte pas le spread : sur MT5, retire-le mentalement de chaque trade.
- Sur une série vraiment aléatoire, toutes les stratégies tendent vers 0 R par trade, moins le spread.
  Un résultat positif sur quelques dizaines de trades n'est donc pas une preuve.

## Organisation du code (`app/src/main/java/com/synthcompanion/app/`)
| Fichier | Rôle |
|---|---|
| `MarketHub.kt` | Connexion Deriv, bougies, compte à rebours, déclenchement des alertes |
| `DerivClient.kt` | WebSocket (OkHttp) |
| `ChartView.kt` | Dessin du graphique et gestes |
| `Indicators.kt` | EMA, RSI, ATR |
| `Analysis.kt` | Stratégies, signaux, test sur l'historique |
| `Structure.kt` | Pivots, supports/résistances, lignes de tendance, Fibonacci, figures chartistes et de bougies |
| `Report.kt` | Rapport multi-unités et propositions d'entrée |
| `GuideActivity.kt`, `SketchView.kt` | Guide des outils et schémas |
| `CandleDb.kt` | Base de données des bougies M1 |
| `AiEngine.kt`, `AiStore.kt`, `AiActivity.kt` | IA locale : apprentissage, validation, signaux |
| `DataActivity.kt` | Écran des données stockées |
| `Polarity.kt` | Inversion de polarité : cassures, retours, caractéristiques IA |
| `Lab.kt` | Labo statistique : tests contre le hasard |
| `Recorder.kt` | Enregistrement continu des ticks en CSV |
| `Paper.kt` | Positions fictives et statistiques du journal |
| `Journal.kt` | Stockage du journal et clôture automatique |
| `TradeTicket.kt` | Fenêtre d'ouverture et de gestion d'une position |
| `JournalActivity.kt`, `EquityView.kt` | Écran du journal et courbe du capital |
| `ReplayActivity.kt` | Mode replay |
| `NotificationLog.kt`, `NotificationsActivity.kt` | Centre de notifications |
| `MarketService.kt` | Service en arrière-plan et notification permanente |
| `OverlayController.kt` | Bulle flottante |
| `AlertStore.kt` | Sauvegarde des alertes de prix |
| `Notifier.kt` | Notifications |
| `MainActivity.kt` | Écran principal |
