package com.synthcompanion.app

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class Side { BUY, SELL }

enum class Strategy(val label: String, val description: String) {
    EMA_CROSS(
        "Croisement EMA 20/50",
        "Achat quand l'EMA 20 passe au-dessus de l'EMA 50 avec RSI > 50. Vente dans le cas inverse.",
    ),
    RSI_REVERSAL(
        "Rebond RSI 30/70",
        "Achat quand le RSI remonte au-dessus de 30. Vente quand il redescend sous 70.",
    ),
    BREAKOUT(
        "Cassure 20 bougies",
        "Achat quand la clôture dépasse le plus haut des 20 dernières bougies. Vente sous le plus bas.",
    ),
    PRICE_ACTION(
        "Price action : bougie sur support/résistance",
        "Achat sur une bougie de retournement haussière (englobante, marteau, étoile du matin…) posée sur un " +
            "support ou une ligne de tendance, quand l'EMA 20 est au-dessus de l'EMA 50. Vente dans le cas inverse. " +
            "Stop sous la mèche de la bougie.",
    ),
}

/** Un signal, déclenché à la clôture de la bougie [index]. Stop et objectif en multiples d'ATR. */
data class Signal(
    val index: Int,
    val epoch: Long,
    val side: Side,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val strategy: Strategy,
    val note: String = "",
)

enum class Outcome { TARGET, STOP, TIMEOUT }

data class Trade(val signal: Signal, val exitIndex: Int, val exitPrice: Double, val r: Double, val outcome: Outcome)

data class BacktestResult(
    val strategy: Strategy,
    val trades: List<Trade>,
    val openSignal: Signal?,
) {
    val count get() = trades.size
    val wins get() = trades.count { it.r > 0 }
    val winRate get() = if (count == 0) 0.0 else wins * 100.0 / count
    val totalR get() = trades.sumOf { it.r }
    val avgR get() = if (count == 0) 0.0 else totalR / count
    val profitFactor: Double
        get() {
            val gain = trades.filter { it.r > 0 }.sumOf { it.r }
            val loss = -trades.filter { it.r < 0 }.sumOf { it.r }
            return if (loss == 0.0) (if (gain > 0) Double.POSITIVE_INFINITY else 0.0) else gain / loss
        }
    /** Pire baisse du capital cumulé, en R. */
    val maxDrawdownR: Double
        get() {
            var cum = 0.0
            var peak = 0.0
            var dd = 0.0
            for (t in trades) {
                cum += t.r
                peak = max(peak, cum)
                dd = max(dd, peak - cum)
            }
            return dd
        }
    /** Plus longue série de pertes consécutives. */
    val maxLosingStreak: Int
        get() {
            var cur = 0
            var best = 0
            for (t in trades) {
                if (t.r < 0) { cur++; best = max(best, cur) } else cur = 0
            }
            return best
        }
}

/**
 * Calculs sur une copie figée des bougies. La dernière bougie est en cours de formation :
 * les signaux ne sont évalués que sur les bougies clôturées (jusqu'à [lastClosed]).
 */
class Analysis(val candles: List<Candle>) {

    companion object {
        const val BREAKOUT_N = 20
        const val MAX_HOLD = 100
    }

    val closes: List<Double> = candles.map { it.close }
    val ema20 = Indicators.ema(closes, 20)
    val ema50 = Indicators.ema(closes, 50)
    val rsi = Indicators.rsi(closes, 14)
    val atr = Indicators.atr(candles, 14)

    /** Supports, résistances, lignes de tendance, Fibonacci, figures (calculés à la demande). */
    val structure: Structure by lazy { Structure(this) }

    /** Distance et retour aux niveaux récemment cassés (inversion de polarité), pour l'IA. */
    val polarity: Polarity.Features by lazy { Polarity.features(this) }

    /** +1 haussière, -1 baissière, 0 sans direction (écart EMA 20/50 en ATR). */
    fun trendAt(i: Int): Int {
        val e20 = ema20.getOrNull(i) ?: return 0
        val e50 = ema50.getOrNull(i) ?: return 0
        val a = atr.getOrNull(i) ?: return 0
        if (e20.isNaN() || e50.isNaN() || a.isNaN() || a <= 0) return 0
        val gap = (e20 - e50) / a
        return when {
            gap > 0.5 -> 1
            gap < -0.5 -> -1
            else -> 0
        }
    }

    val lastClosed: Int get() = candles.size - 2

    private fun highest(from: Int, to: Int): Double {
        var h = -Double.MAX_VALUE
        for (i in max(0, from)..to) h = max(h, candles[i].high)
        return h
    }

    private fun lowest(from: Int, to: Int): Double {
        var l = Double.MAX_VALUE
        for (i in max(0, from)..to) l = min(l, candles[i].low)
        return l
    }

    fun sideAt(i: Int, s: Strategy): Side? {
        if (i < 1 || i >= candles.size) return null
        return when (s) {
            Strategy.EMA_CROSS -> {
                val p = ema20[i - 1] - ema50[i - 1]
                val c = ema20[i] - ema50[i]
                val r = rsi[i]
                when {
                    p.isNaN() || c.isNaN() || r.isNaN() -> null
                    p <= 0 && c > 0 && r > 50 -> Side.BUY
                    p >= 0 && c < 0 && r < 50 -> Side.SELL
                    else -> null
                }
            }
            Strategy.RSI_REVERSAL -> {
                val p = rsi[i - 1]
                val c = rsi[i]
                when {
                    p.isNaN() || c.isNaN() -> null
                    p < 30 && c >= 30 -> Side.BUY
                    p > 70 && c <= 70 -> Side.SELL
                    else -> null
                }
            }
            Strategy.PRICE_ACTION -> priceActionAt(i, 1.5, 3.0)?.side
            Strategy.BREAKOUT -> {
                if (i < BREAKOUT_N + 1) return null
                val hh = highest(i - BREAKOUT_N, i - 1)
                val ll = lowest(i - BREAKOUT_N, i - 1)
                val hhPrev = highest(i - BREAKOUT_N - 1, i - 2)
                val llPrev = lowest(i - BREAKOUT_N - 1, i - 2)
                val c = closes[i]
                val pc = closes[i - 1]
                when {
                    c > hh && pc <= hhPrev -> Side.BUY
                    c < ll && pc >= llPrev -> Side.SELL
                    else -> null
                }
            }
        }
    }

    /**
     * Figure de bougie de retournement, posée sur une zone (≥ 2 touches) ou une ligne de tendance connues
     * avant cette bougie, dans le sens de la tendance EMA.
     */
    private fun priceActionAt(i: Int, slAtr: Double, tpAtr: Double): Signal? {
        if (i < 60 || i >= candles.size) return null
        val cp = structure.candlePatternAt(i) ?: return null
        val side = cp.bias ?: return null
        val a = atr[i]
        val e20 = ema20[i]
        val e50 = ema50[i]
        if (a.isNaN() || a <= 0 || e20.isNaN() || e50.isNaN()) return null
        if (side == Side.BUY && e20 < e50) return null
        if (side == Side.SELL && e20 > e50) return null
        val k = candles[i]
        val tol = 0.5 * a
        val zones = structure.zonesAt(i - 1).filter { it.touches >= 2 }
        val lines = structure.trendLinesAt(i - 1)
        val fmt = { v: Double -> String.format(java.util.Locale.US, "%.2f", v) }
        val where: String? = if (side == Side.BUY) {
            zones.firstOrNull { k.low <= it.high + tol && k.close >= it.low }?.let { "support ${fmt(it.mid)} (${it.touches} touches)" }
                ?: lines.firstOrNull { it.isSupport && k.low <= it.valueAt(i) + tol && k.close >= it.valueAt(i) - tol }
                    ?.let { "ligne de tendance haussière (${it.touches} touches)" }
        } else {
            zones.firstOrNull { k.high >= it.low - tol && k.close <= it.high }?.let { "résistance ${fmt(it.mid)} (${it.touches} touches)" }
                ?: lines.firstOrNull { !it.isSupport && k.high >= it.valueAt(i) - tol && k.close <= it.valueAt(i) + tol }
                    ?.let { "ligne de tendance baissière (${it.touches} touches)" }
        }
        if (where == null) return null
        val entry = k.close
        val ratio = if (slAtr > 0) tpAtr / slAtr else 2.0
        return if (side == Side.BUY) {
            var stop = k.low - 0.2 * a
            if (entry - stop < 0.5 * a) stop = entry - 0.5 * a
            Signal(i, k.epoch, side, entry, stop, entry + (entry - stop) * ratio, Strategy.PRICE_ACTION, "${cp.name} sur $where")
        } else {
            var stop = k.high + 0.2 * a
            if (stop - entry < 0.5 * a) stop = entry + 0.5 * a
            Signal(i, k.epoch, side, entry, stop, entry - (stop - entry) * ratio, Strategy.PRICE_ACTION, "${cp.name} sur $where")
        }
    }

    fun signalAt(i: Int, s: Strategy, slAtr: Double, tpAtr: Double): Signal? {
        if (s == Strategy.PRICE_ACTION) return priceActionAt(i, slAtr, tpAtr)
        val side = sideAt(i, s) ?: return null
        val a = atr[i]
        if (a.isNaN() || a <= 0) return null
        val entry = closes[i]
        return if (side == Side.BUY) {
            Signal(i, candles[i].epoch, side, entry, entry - slAtr * a, entry + tpAtr * a, s)
        } else {
            Signal(i, candles[i].epoch, side, entry, entry + slAtr * a, entry - tpAtr * a, s)
        }
    }

    fun signals(s: Strategy, slAtr: Double, tpAtr: Double): List<Signal> =
        if (lastClosed < 1) emptyList() else (1..lastClosed).mapNotNull { signalAt(it, s, slAtr, tpAtr) }

    fun lastSignal(s: Strategy, slAtr: Double, tpAtr: Double): Signal? {
        for (i in lastClosed downTo 1) signalAt(i, s, slAtr, tpAtr)?.let { return it }
        return null
    }

    /**
     * Suit le signal bougie par bougie. Si le stop et l'objectif sont touchés dans la même bougie,
     * on compte une perte (hypothèse prudente). Renvoie null si le trade est encore ouvert.
     */
    fun resolve(sig: Signal, maxHold: Int = MAX_HOLD): Trade? {
        val risk = abs(sig.entry - sig.stop)
        if (risk <= 0) return null
        val end = min(lastClosed, sig.index + maxHold)
        for (j in sig.index + 1..end) {
            val c = candles[j]
            val hitStop = if (sig.side == Side.BUY) c.low <= sig.stop else c.high >= sig.stop
            val hitTarget = if (sig.side == Side.BUY) c.high >= sig.target else c.low <= sig.target
            if (hitStop) return Trade(sig, j, sig.stop, -1.0, Outcome.STOP)
            if (hitTarget) return Trade(sig, j, sig.target, abs(sig.target - sig.entry) / risk, Outcome.TARGET)
            if (j == sig.index + maxHold) {
                val r = (if (sig.side == Side.BUY) c.close - sig.entry else sig.entry - c.close) / risk
                return Trade(sig, j, c.close, r, Outcome.TIMEOUT)
            }
        }
        return null
    }

    /** Un seul trade à la fois : un nouveau signal n'est pris qu'après la sortie du précédent. */
    fun backtest(s: Strategy, slAtr: Double, tpAtr: Double): BacktestResult {
        val trades = ArrayList<Trade>()
        var open: Signal? = null
        var i = 1
        while (i <= lastClosed) {
            val sig = signalAt(i, s, slAtr, tpAtr)
            if (sig == null) {
                i++
                continue
            }
            val t = resolve(sig)
            if (t == null) {
                open = sig
                break
            }
            trades.add(t)
            i = t.exitIndex + 1
        }
        return BacktestResult(s, trades, open)
    }
}
