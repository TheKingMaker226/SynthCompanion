package com.synthcompanion.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.graphics.Typeface
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import java.io.File
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), MarketHub.Listener {

    private lateinit var spSymbol: Spinner
    private lateinit var spTimeframe: Spinner
    private lateinit var tvPrice: TextView
    private lateinit var tvChange: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var tvStatus: TextView
    private lateinit var chart: ChartView
    private lateinit var btnAlerts: MaterialButton
    private lateinit var btnNotif: MaterialButton
    private lateinit var btnPositions: MaterialButton
    private lateinit var positionsPanel: LinearLayout
    /** Lignes du bandeau des positions, par id de trade (mises à jour à chaque tick). */
    private val positionRows = LinkedHashMap<Long, TextView>()
    private lateinit var btnSignals: MaterialButton

    private var symbolCodes: List<String> = emptyList()
    private var cacheKey = ""
    private var cachedOverlay: ChartOverlay = ChartOverlay.EMPTY
    private var cachedSignals: List<Signal> = emptyList()
    private var cachedActive: Signal? = null
    private var overlayPermissionPending = false

    private val preCloseChoices = intArrayOf(0, 5, 10, 15, 30, 60)

    /** Unités de temps du rapport multi-unités. */
    private val MTF = listOf("M1" to 60, "M5" to 300, "M15" to 900, "H1" to 3600, "H4" to 14400, "D1" to 86400)

    /** Préréglages stop / objectif, en ATR. */
    private val riskPresets = listOf(1.0 to 2.0, 1.5 to 3.0, 2.0 to 4.0, 1.0 to 1.5, 2.0 to 2.0)

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    /** Fichier prêt à être copié à l'emplacement choisi par l'utilisateur. */
    private var exportFile: File? = null

    private val createCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val f = exportFile ?: return@registerForActivityResult
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            toast("Fichier CSV enregistré")
        } catch (e: Exception) {
            toast("Échec de l'enregistrement : ${e.message}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindViews()
        onBackPressedDispatcher.addCallback(this, exitFullscreenOnBack)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /**
     * Rotation : l'écran n'est pas recréé (configChanges dans le manifeste), on recharge seulement
     * la mise en page portrait ou paysage. Les fenêtres ouvertes et le zoom du graphique sont conservés.
     */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val zoom = chart.zoom
        bindViews()
        chart.zoom = zoom
        if (chartFullscreen) ChartFullscreen.set(this, chart, true)
        symbolCodes = emptyList()
        cacheKey = ""
        refreshSymbols()
        onData()
        onTick()
        onStatus()
    }

    private fun bindViews() {
        setContentView(R.layout.activity_main)

        spSymbol = findViewById(R.id.spSymbol)
        spTimeframe = findViewById(R.id.spTimeframe)
        tvPrice = findViewById(R.id.tvPrice)
        tvChange = findViewById(R.id.tvChange)
        tvCountdown = findViewById(R.id.tvCountdown)
        tvStatus = findViewById(R.id.tvStatus)
        chart = findViewById(R.id.chart)
        btnAlerts = findViewById(R.id.btnAlerts)
        btnNotif = findViewById(R.id.btnNotif)
        btnPositions = findViewById(R.id.btnPositions)
        positionsPanel = findViewById(R.id.positionsPanel)
        positionRows.clear()
        btnSignals = findViewById(R.id.btnSignals)

        val root = findViewById<View>(R.id.root)
        val pad = (12 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left + pad, bars.top + pad / 2, bars.right + pad, bars.bottom + pad / 2)
            insets
        }

        setupSymbolSpinner()
        setupTimeframeSpinner()

        chart.onLongPressPrice = { price -> showAddAlertDialog(price) }
        chart.onFullscreenToggle = { setChartFullscreen(!chartFullscreen) }
        positionsSummary = null
        findViewById<MaterialButton>(R.id.btnAddAlert).setOnClickListener { showAddAlertDialog(MarketHub.lastPrice) }
        btnAlerts.setOnClickListener { showAlertsDialog() }
        btnNotif.setOnClickListener { startActivity(Intent(this, NotificationsActivity::class.java)) }
        btnPositions.setOnClickListener { openPositionsScreen() }
        findViewById<MaterialButton>(R.id.btnBuy).setOnClickListener { openTicket(Side.BUY) }
        findViewById<MaterialButton>(R.id.btnSell).setOnClickListener { openTicket(Side.SELL) }
        btnSignals.setOnClickListener { showSignalsDialog() }
        findViewById<MaterialButton>(R.id.btnReport).setOnClickListener { showReport() }
        findViewById<MaterialButton>(R.id.btnMenu).setOnClickListener { showMenu() }
    }

    private val notifListener: () -> Unit = { runOnUiThread { updateButtons() } }

    override fun onStart() {
        super.onStart()
        MarketHub.addListener(this)
        NotificationLog.addListener(notifListener)
        MarketService.start(this)
        refreshSymbols()
        onData()
        onTick()
        onStatus()
    }

    override fun onResume() {
        super.onResume()
        if (overlayPermissionPending) {
            overlayPermissionPending = false
            if (Settings.canDrawOverlays(this)) {
                MarketHub.overlayEnabled = true
                MarketService.start(this, MarketService.ACTION_OVERLAY_ON)
            } else {
                toast("Autorisation refusée : la bulle ne peut pas s'afficher")
            }
        }
        updateButtons()
    }

    override fun onStop() {
        MarketHub.removeListener(this)
        NotificationLog.removeListener(notifListener)
        super.onStop()
    }

    // ---------- Sélecteurs ----------

    private fun setupSymbolSpinner() {
        spSymbol.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val code = symbolCodes.getOrNull(position) ?: return
                if (code != MarketHub.symbol) MarketHub.setSymbol(code)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun refreshSymbols() {
        val list = MarketHub.symbols
        val codes = list.map { it.code }
        if (codes == symbolCodes) return
        symbolCodes = codes
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, list.map { it.name })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spSymbol.adapter = adapter
        val idx = codes.indexOf(MarketHub.symbol)
        if (idx >= 0) spSymbol.setSelection(idx, false)
    }

    private fun setupTimeframeSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Timeframes.list.map { it.second })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spTimeframe.adapter = adapter
        val idx = Timeframes.list.indexOfFirst { it.first == MarketHub.granularity }
        if (idx >= 0) spTimeframe.setSelection(idx, false)
        spTimeframe.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val g = Timeframes.list.getOrNull(position)?.first ?: return
                if (g != MarketHub.granularity) MarketHub.setGranularity(g)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    // ---------- Mises à jour ----------

    override fun onData() {
        tvPrice.text = MarketHub.format(MarketHub.lastPrice)
        val last = MarketHub.candles.lastOrNull()
        if (last != null) {
            val change = last.close - last.open
            val pct = if (last.open != 0.0) change / last.open * 100 else 0.0
            val d = MarketHub.decimals()
            tvChange.text = String.format(Locale.US, "%+.${d}f (%+.3f%%) sur la bougie", change, pct)
            val color = ContextCompat.getColor(this, if (change >= 0) R.color.up else R.color.down)
            tvChange.setTextColor(color)
            tvPrice.setTextColor(color)
        } else {
            tvChange.text = ""
            tvPrice.setTextColor(ContextCompat.getColor(this, R.color.text))
        }
        val levels = AlertStore.activeFor(MarketHub.symbol).map { it.price }
        val snapshot = ArrayList(MarketHub.candles)
        val analysis = Analysis(snapshot)
        // Structure et signaux ne changent qu'à la clôture d'une bougie : on les garde en cache.
        val key = listOf(
            MarketHub.symbol, MarketHub.granularity, snapshot.size, snapshot.getOrNull(snapshot.size - 2)?.epoch,
            MarketHub.strategy, MarketHub.slAtr, MarketHub.tpAtr,
        ).joinToString("|")
        if (key != cacheKey) {
            cacheKey = key
            if (snapshot.size >= 60) {
                val t = analysis.lastClosed
                cachedOverlay = analysis.structure.overlayAt(t, snapshot.last().close)
                cachedSignals = analysis.signals(MarketHub.strategy, MarketHub.slAtr, MarketHub.tpAtr)
                cachedActive = cachedSignals.lastOrNull()?.takeIf { analysis.resolve(it) == null }
            } else {
                cachedOverlay = ChartOverlay.EMPTY
                cachedSignals = emptyList()
                cachedActive = null
            }
        }
        val tools = Tool.values().filter { MarketHub.toolEnabled(it) }.toSet()
        chart.setData(
            snapshot, MarketHub.decimals(), MarketHub.granularity, levels, analysis,
            cachedSignals, cachedActive, cachedOverlay, tools,
        )
        val live = Journal.all().filter { it.mode == TradeMode.LIVE && it.symbol == MarketHub.symbol }
        chart.setTrades(live.filter { it.isOpen }, live.filter { !it.isOpen }.takeLast(50))
        updatePositionsPanel()
        updateButtons()
    }

    override fun onTick() {
        val rem = MarketHub.remainingSeconds()
        tvCountdown.text = MarketHub.formatRemaining(rem)
        val n = MarketHub.preCloseSeconds
        tvCountdown.setTextColor(
            ContextCompat.getColor(this, if (n > 0 && rem in 0..n) R.color.accent else R.color.text)
        )
    }

    override fun onStatus() {
        tvStatus.text = MarketHub.status
    }

    override fun onSymbols() {
        refreshSymbols()
    }

    private fun updateButtons() {
        val active = AlertStore.all().count { it.active }
        btnAlerts.text = if (active > 0) "Mes alertes ($active)" else "Mes alertes"
        val unread = NotificationLog.unread()
        btnNotif.text = if (unread > 0) "🔔 $unread" else "🔔"
        val openCount = Journal.open(TradeMode.LIVE).size
        btnPositions.text = if (openCount > 0) "Positions ($openCount)" else "Positions"
        val short = when (MarketHub.strategy) {
            Strategy.EMA_CROSS -> "EMA"
            Strategy.RSI_REVERSAL -> "RSI"
            Strategy.BREAKOUT -> "Cassure"
            Strategy.PRICE_ACTION -> "Price action"
        }
        btnSignals.text = "Signaux : $short · " + if (MarketHub.signalAlerts) "ON" else "OFF"
    }

    // ---------- Dialogues ----------

    private fun showAddAlertDialog(prefill: Double) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            if (!prefill.isNaN()) setText(MarketHub.format(prefill))
            setSelection(text.length)
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val alarmBox = MaterialCheckBox(this).apply {
            text = "⏰ Sonner comme un réveil (même en silencieux)"
            isChecked = MarketHub.lastAlarmChoice
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
            addView(alarmBox)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Alerte de prix · ${MarketHub.shortName()}")
            .setMessage("Prix actuel : ${MarketHub.format(MarketHub.lastPrice)}")
            .setView(box)
            .setPositiveButton("Créer") { _, _ ->
                val v = input.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (v == null || v <= 0) {
                    toast("Prix invalide")
                    return@setPositiveButton
                }
                val alarm = alarmBox.isChecked
                MarketHub.lastAlarmChoice = alarm
                val a = AlertStore.add(MarketHub.symbol, v, MarketHub.lastPrice, alarm)
                val sens = if (a.direction == Direction.ABOVE) "monte à" else "descend à"
                toast("Alerte${if (alarm) " avec sonnerie" else ""} créée : quand le prix $sens ${MarketHub.format(v)}")
                if (alarm) checkFullScreenPermission()
                onData()
            }
            .setNeutralButton("Tester la sonnerie") { _, _ -> testAlarm() }
            .setNegativeButton("Annuler", null)
            .show()
    }

    /** Fait sonner l'alarme 10 secondes pour vérifier le volume. */
    private fun testAlarm() {
        AlarmPlayer.start(this, "Test de la sonnerie", "Elle s'arrête seule dans 10 secondes, ou touche Arrêter.")
        chart.postDelayed({ if (AlarmPlayer.title == "Test de la sonnerie") AlarmPlayer.stop(this) }, 10_000)
        toast("Si tu n'entends rien, monte le volume « Alarme » du téléphone")
    }

    /**
     * Android 14+ : l'écran d'alarme par-dessus le verrouillage demande une autorisation.
     * Sans elle, la sonnerie et la notification fonctionnent quand même.
     */
    private fun checkFullScreenPermission() {
        if (Build.VERSION.SDK_INT < 34) return
        val nm = getSystemService(android.app.NotificationManager::class.java)
        if (nm.canUseFullScreenIntent()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("Écran d'alarme")
            .setMessage(
                "Pour que l'alarme s'affiche en plein écran même quand le téléphone est verrouillé, autorise " +
                    "« Notifications en plein écran » pour Synth Companion.\n\nSans cette autorisation, la sonnerie " +
                    "et la notification avec le bouton Arrêter fonctionnent quand même."
            )
            .setPositiveButton("Autoriser") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    toast("Réglage introuvable sur ce téléphone")
                }
            }
            .setNegativeButton("Plus tard", null)
            .show()
    }

    private fun showAlertsDialog() {
        val alerts = AlertStore.all().sortedWith(compareByDescending<PriceAlert> { it.active }.thenBy { it.symbol })
        if (alerts.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Mes alertes")
                .setMessage("Aucune alerte. Utilise « + Alerte de prix » ou un appui long sur le graphique.\n\nLes alertes surveillent l'indice affiché à l'écran.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val labels = alerts.map {
            val arrow = if (it.direction == Direction.ABOVE) "▲" else "▼"
            val state = if (it.active) "" else "  · déclenchée"
            val bell = if (it.alarm) "  ⏰" else ""
            "$arrow ${MarketHub.shortName(it.symbol)}  ${formatFor(it.symbol, it.price)}$bell$state"
        }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Mes alertes (touche pour supprimer)")
            .setItems(labels) { _, which ->
                AlertStore.remove(alerts[which].id)
                onData()
                toast("Alerte supprimée")
            }
            .setNeutralButton("Tout supprimer") { _, _ ->
                AlertStore.clear()
                onData()
            }
            .setPositiveButton("Fermer", null)
            .show()
    }

    private fun formatFor(symbol: String, price: Double): String {
        val pip = MarketHub.symbolInfo(symbol)?.pip ?: 0.01
        val d = if (pip > 0) (-log10(pip)).roundToInt().coerceIn(0, 6) else 2
        return String.format(Locale.US, "%.${d}f", price)
    }

    private fun showPreCloseDialog() {
        val labels = preCloseChoices.map { if (it == 0) "Désactivée" else "$it s avant la clôture" }.toTypedArray()
        val current = preCloseChoices.indexOfFirst { it == MarketHub.preCloseSeconds }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Alerte avant clôture de bougie")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                MarketHub.preCloseSeconds = preCloseChoices[which]
                updateButtons()
                onTick()
                dialog.dismiss()
            }
            .show()
    }

    private fun toggleOverlay() {
        when {
            MarketHub.overlayEnabled -> {
                MarketHub.overlayEnabled = false
                MarketService.start(this, MarketService.ACTION_OVERLAY_OFF)
            }
            !Settings.canDrawOverlays(this) -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Autoriser la bulle flottante")
                    .setMessage("Pour afficher le prix et le compte à rebours par-dessus MT5, active « Afficher par-dessus les autres applis » pour Synth Companion, puis reviens ici.")
                    .setPositiveButton("Ouvrir les réglages") { _, _ ->
                        overlayPermissionPending = true
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        )
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            else -> {
                MarketHub.overlayEnabled = true
                MarketService.start(this, MarketService.ACTION_OVERLAY_ON)
            }
        }
        updateButtons()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun n1(v: Double) = if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()

    private fun showSignalsDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val group = RadioGroup(this)
        for (s in Strategy.values()) {
            group.addView(RadioButton(this).apply {
                id = View.generateViewId()
                text = "${s.label}\n${s.description}"
                tag = s
                setPadding(dp(4), dp(6), 0, dp(6))
                isChecked = s == MarketHub.strategy
            })
        }
        layout.addView(group)

        layout.addView(TextView(this).apply {
            text = "Stop et objectif (en ATR = amplitude moyenne d'une bougie)"
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.muted))
            textSize = 12f
            setPadding(0, dp(12), 0, 0)
        })
        val spRisk = Spinner(this)
        val labels = riskPresets.map { (sl, tp) -> "Stop ${n1(sl)} ATR · Objectif ${n1(tp)} ATR (1:${n1(tp / sl)})" }
        spRisk.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val cur = riskPresets.indexOfFirst { it.first == MarketHub.slAtr && it.second == MarketHub.tpAtr }
        spRisk.setSelection(if (cur >= 0) cur else 1)
        layout.addView(spRisk)

        val sw = MaterialSwitch(this).apply {
            text = "M'alerter à chaque nouveau signal (à la clôture de la bougie)"
            isChecked = MarketHub.signalAlerts
            setPadding(0, dp(8), 0, 0)
        }
        layout.addView(sw)
        val swAlarm = MaterialSwitch(this).apply {
            text = "⏰ Sonner comme un réveil pour les signaux"
            isChecked = MarketHub.signalAlarm
            setPadding(0, dp(4), 0, 0)
        }
        layout.addView(swAlarm)
        layout.addView(TextView(this).apply {
            text = "Inversion de polarité"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.accent))
            setPadding(0, dp(14), 0, 0)
        })
        val swPol = MaterialSwitch(this).apply {
            text = "🔁 M'alerter quand le prix revient sur une zone qu'il vient de casser (support ↔ résistance)"
            isChecked = MarketHub.polarityAlerts
            setPadding(0, dp(4), 0, 0)
        }
        layout.addView(swPol)
        val swPolAlarm = MaterialSwitch(this).apply {
            text = "⏰ Sonner comme un réveil pour ces retours"
            isChecked = MarketHub.polarityAlarm
            setPadding(0, dp(4), 0, 0)
        }
        layout.addView(swPolAlarm)

        MaterialAlertDialogBuilder(this)
            .setTitle("Signaux d'entrée")
            .setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("Enregistrer") { _, _ ->
                val chosen = group.findViewById<RadioButton>(group.checkedRadioButtonId)?.tag as? Strategy
                if (chosen != null) MarketHub.strategy = chosen
                val (sl, tp) = riskPresets[spRisk.selectedItemPosition.coerceIn(0, riskPresets.size - 1)]
                MarketHub.slAtr = sl
                MarketHub.tpAtr = tp
                MarketHub.signalAlerts = sw.isChecked
                val wantAlarm = swAlarm.isChecked && sw.isChecked
                MarketHub.signalAlarm = wantAlarm
                MarketHub.polarityAlerts = swPol.isChecked
                MarketHub.polarityAlarm = swPolAlarm.isChecked && swPol.isChecked
                if (MarketHub.polarityAlarm) checkFullScreenPermission()
                if (wantAlarm) checkFullScreenPermission()
                onData()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showReport() {
        if (MarketHub.candles.size < 60) {
            toast("Pas encore assez de données, réessaie dans un instant")
            return
        }
        val current = ArrayList(MarketHub.candles)
        val symbol = MarketHub.symbol
        val gran = MarketHub.granularity
        val symbolName = MarketHub.symbolInfo(symbol)?.name ?: symbol
        val decimals = MarketHub.decimals()
        val strategy = MarketHub.strategy
        val sl = MarketHub.slAtr
        val tp = MarketHub.tpAtr
        val fmt = { v: Double -> String.format(Locale.US, "%.${decimals}f", v) }
        val progress = MaterialAlertDialogBuilder(this)
            .setTitle("Analyse en cours")
            .setMessage("Récupération de M1, M5, M15, H1, H4 et D1…")
            .setCancelable(false)
            .show()

        // Récupère chaque unité de temps (l'unité affichée utilise les bougies déjà chargées)
        val results = HashMap<Int, List<Candle>>()
        var remaining = MTF.size
        val onAllFetched = {
            val mtfCandles = MTF.map { (label, g) -> label to (if (g == gran) current else results[g]) }
            // Calculs lourds hors du fil principal
            Thread {
                val mtf = mtfCandles.mapNotNull { (label, list) ->
                    if (list == null || list.size < 60) null else label to Analysis(list)
                }
                val report = Report.build(Analysis(current), symbolName, Timeframes.label(gran), gran, strategy, sl, tp, mtf, fmt)
                runOnUiThread {
                    progress.dismiss()
                    if (!isFinishing) showReportText("Analyse", report)
                }
            }.start()
        }
        for ((_, g) in MTF) {
            if (g == gran) {
                remaining--
                if (remaining == 0) onAllFetched()
                continue
            }
            MarketHub.fetchCandles(symbol, g, 500) { list ->
                if (list != null) results[g] = list
                remaining--
                if (remaining == 0) onAllFetched()
            }
        }
    }

    private fun showLabIntro() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Labo statistique")
            .setMessage(
                "Le labo télécharge 3 000 bougies de ${MarketHub.shortName()} en ${MarketHub.timeframeLabel()} et vérifie " +
                    "si les règles du trading y fonctionnent mieux que le hasard :\n\n" +
                    "1. Mémoire des mouvements\n2. Tendance ou retour à la moyenne\n3. Respect des supports et résistances\n" +
                    "4. Fiabilité des figures de bougies\n5. Stratégies contre des séries mélangées\n\n" +
                    "Compte 10 à 60 secondes. Refais-le sur plusieurs unités de temps : une vraie règle doit réapparaître à chaque fois."
            )
            .setPositiveButton("Lancer") { _, _ -> runLab() }
            .setNeutralButton("Données CSV") { _, _ -> showDataDialog() }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------- Données CSV ----------

    private fun showDataDialog() {
        val rec = Recorder.isEnabled(this)
        val files = Recorder.files(this)
        val size = files.sumOf { it.length() }
        val sizeText = if (size > 1_000_000) String.format(Locale.US, "%.1f Mo", size / 1e6) else "${size / 1000} Ko"
        val tf = MarketHub.timeframeLabel()
        val items = arrayOf(
            "Télécharger les bougies $tf (jusqu'à 20 000)",
            "Télécharger les ticks bruts (jusqu'à 20 000)",
            if (rec) "■ Arrêter l'enregistrement continu" else "● Démarrer l'enregistrement continu des ticks",
            "Exporter un enregistrement (${files.size} fichier${if (files.size > 1) "s" else ""}, $sizeText)",
            "Effacer les enregistrements",
        )
        MaterialAlertDialogBuilder(this)
            .setTitle("Données CSV · ${MarketHub.shortName()}")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> downloadCandles()
                    1 -> downloadTicks()
                    2 -> {
                        Recorder.setEnabled(this, !rec)
                        toast(
                            if (!rec) "Enregistrement démarré : chaque tick de ${MarketHub.shortName()} est sauvegardé, même en arrière-plan"
                            else "Enregistrement arrêté"
                        )
                    }
                    3 -> exportRecording()
                    4 -> MaterialAlertDialogBuilder(this)
                        .setTitle("Effacer les enregistrements ?")
                        .setMessage("Les fichiers de ticks enregistrés seront supprimés du téléphone.")
                        .setPositiveButton("Effacer") { _, _ ->
                            Recorder.clear(this)
                            toast("Enregistrements effacés")
                        }
                        .setNegativeButton("Annuler", null)
                        .show()
                }
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun fileStamp(): String = java.text.SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())

    private fun downloadCandles() {
        val symbol = MarketHub.symbol
        val gran = MarketHub.granularity
        val tf = Timeframes.label(gran)
        val d = MarketHub.decimals()
        val progress = MaterialAlertDialogBuilder(this)
            .setTitle("Téléchargement")
            .setMessage("Récupération des bougies $tf…")
            .setCancelable(false)
            .show()
        MarketHub.fetchCandlesPaged(symbol, gran, 20_000, { n -> progress.setMessage("$n bougies récupérées…") }) { list ->
            if (list.isNullOrEmpty()) {
                progress.dismiss()
                toast("Aucune donnée reçue. Vérifie la connexion.")
                return@fetchCandlesPaged
            }
            Thread {
                val f = File(cacheDir, "${symbol}_${tf}_${fileStamp()}.csv")
                f.bufferedWriter().use { w ->
                    w.write("epoch,date_utc,open,high,low,close\n")
                    val fmt = "%.${d}f"
                    for (c in list) {
                        w.write(
                            "${c.epoch},${Recorder.formatUtc(c.epoch)}," +
                                "${String.format(Locale.US, fmt, c.open)},${String.format(Locale.US, fmt, c.high)}," +
                                "${String.format(Locale.US, fmt, c.low)},${String.format(Locale.US, fmt, c.close)}\n"
                        )
                    }
                }
                runOnUiThread {
                    progress.dismiss()
                    toast("${list.size} bougies prêtes, choisis où enregistrer le fichier")
                    exportFile = f
                    createCsv.launch(f.name)
                }
            }.start()
        }
    }

    private fun downloadTicks() {
        val symbol = MarketHub.symbol
        val d = MarketHub.decimals()
        val progress = MaterialAlertDialogBuilder(this)
            .setTitle("Téléchargement")
            .setMessage("Récupération des ticks…")
            .setCancelable(false)
            .show()
        MarketHub.fetchTicksPaged(symbol, 20_000, { n -> progress.setMessage("$n ticks récupérés…") }) { list ->
            if (list.isNullOrEmpty()) {
                progress.dismiss()
                toast("Aucune donnée reçue. Vérifie la connexion.")
                return@fetchTicksPaged
            }
            Thread {
                val f = File(cacheDir, "${symbol}_ticks_${fileStamp()}.csv")
                f.bufferedWriter().use { w ->
                    w.write("epoch,date_utc,prix\n")
                    val fmt = "%.${d}f"
                    for ((e, p) in list) w.write("$e,${Recorder.formatUtc(e)},${String.format(Locale.US, fmt, p)}\n")
                }
                runOnUiThread {
                    progress.dismiss()
                    toast("${list.size} ticks prêts, choisis où enregistrer le fichier")
                    exportFile = f
                    createCsv.launch(f.name)
                }
            }.start()
        }
    }

    private fun exportRecording() {
        Recorder.flush()
        val files = Recorder.files(this)
        if (files.isEmpty()) {
            toast("Aucun enregistrement. Démarre d'abord l'enregistrement continu.")
            return
        }
        val export = { f: File ->
            exportFile = f
            createCsv.launch(f.nameWithoutExtension + "_" + fileStamp() + ".csv")
        }
        if (files.size == 1) {
            export(files[0])
            return
        }
        val labels = files.map { "${it.nameWithoutExtension.removePrefix("ticks_")} · ${it.length() / 1000} Ko" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Quel enregistrement ?")
            .setItems(labels) { _, which -> export(files[which]) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun runLab() {
        val symbol = MarketHub.symbol
        val gran = MarketHub.granularity
        val name = MarketHub.symbolInfo(symbol)?.name ?: symbol
        val tf = Timeframes.label(gran)
        val progress = MaterialAlertDialogBuilder(this)
            .setTitle("Labo en cours")
            .setMessage("Téléchargement de l'historique…")
            .setCancelable(false)
            .show()
        MarketHub.fetchCandles(symbol, gran, 3000) { list ->
            if (list == null || list.size < 300) {
                progress.dismiss()
                toast("Impossible de récupérer assez d'historique. Vérifie la connexion.")
                return@fetchCandles
            }
            Thread {
                val text = try {
                    Lab.run(list, name, tf, 40) { msg -> runOnUiThread { progress.setMessage(msg) } }
                } catch (e: Exception) {
                    "Erreur pendant le calcul : ${e.message}"
                }
                runOnUiThread {
                    progress.dismiss()
                    if (!isFinishing) showReportText("Labo statistique", text)
                }
            }.start()
        }
    }

    private fun showReportText(title: String, report: String) {
        val tv = TextView(this).apply {
            text = report
            setTextIsSelectable(true)
            textSize = 13f
            typeface = Typeface.DEFAULT
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text))
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Fermer", null)
            .setNeutralButton("Partager") { _, _ ->
                val send = Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, "$title · ${MarketHub.shortName()} ${MarketHub.timeframeLabel()}")
                    .putExtra(Intent.EXTRA_TEXT, report)
                startActivity(Intent.createChooser(send, "Partager le rapport"))
            }
            .show()
    }

    // ---------- Menu ----------

    private fun showMenu() {
        val n = MarketHub.preCloseSeconds
        val items = listOf(
            "🤖  IA : chercher des motifs récurrents" to { startActivity(Intent(this, AiActivity::class.java)) },
            "🗄  Données stockées sur le téléphone" to { startActivity(Intent(this, DataActivity::class.java)) },
            "📖  Guide des outils (figures, Fibonacci, indicateurs…)" to { startActivity(Intent(this, GuideActivity::class.java)) },
            "📒  Journal de trading" to { startActivity(Intent(this, JournalActivity::class.java)) },
            "💵  Réinitialiser le capital à ${String.format(Locale.US, "%.0f", Journal.startBalance)} $" to { confirmCapitalReset() },
            "⏪  Mode replay (s'entraîner sur le passé)" to { startActivity(Intent(this, ReplayActivity::class.java)) },
            "🧪  Labo statistique" to { showLabIntro() },
            "📄  Données CSV" to { showDataDialog() },
            "✏️  Outils du graphique" to { showToolsDialog() },
            "⏱  Alerte avant clôture : ${if (n > 0) "$n s" else "désactivée"}" to { showPreCloseDialog() },
            "🫧  Bulle flottante : ${if (MarketHub.overlayEnabled) "ON" else "OFF"}" to { toggleOverlay() },
            "⏻  Quitter l'appli" to {
                MarketService.stop(this)
                finishAndRemoveTask()
            },
        )
        MaterialAlertDialogBuilder(this)
            .setTitle("Menu")
            .setItems(items.map { it.first }.toTypedArray()) { _, which -> items[which].second() }
            .show()
    }

    // ---------- Trading fictif ----------

    private fun openTicket(side: Side) {
        TradeTicket.show(
            this, side, MarketHub.symbol, MarketHub.shortName(), MarketHub.timeframeLabel(),
            MarketHub.lastPrice, MarketHub.currentAtr(), MarketHub.decimals(), TradeMode.LIVE, MarketHub.serverNow(),
        ) { t ->
            toast("Position ouverte : ${if (t.side == Side.BUY) "achat" else "vente"} à ${MarketHub.format(t.entry)}")
            onData()
        }
    }

    /** Ramène le capital fictif au capital de départ, en l'inscrivant comme dépôt ou retrait. */
    private fun confirmCapitalReset() {
        val target = Journal.startBalance
        val bal = Journal.balance()
        val diff = target - bal
        val fmt = { v: Double -> String.format(Locale.US, "%.2f", v) }
        if (kotlin.math.abs(diff) < 0.005) {
            toast("Ton capital est déjà à ${fmt(target)} $")
            return
        }
        val open = Journal.open(TradeMode.LIVE).size
        val msg = StringBuilder()
        msg.append("Capital actuel : ${fmt(bal)} $\n\n")
        msg.append(
            if (diff < 0) "Tu as gagné ${fmt(-diff)} $ au-dessus de ${fmt(target)} $ : ils seront enregistrés comme un RETRAIT."
            else "Il te manque ${fmt(diff)} $ pour revenir à ${fmt(target)} $ : ils seront enregistrés comme un DÉPÔT."
        )
        msg.append("\n\nTes trades et tes statistiques restent intacts. Le mouvement apparaît dans l'historique.")
        if (open > 0) msg.append("\n\n$open position${if (open > 1) "s" else ""} ouverte${if (open > 1) "s" else ""} continue${if (open > 1) "nt" else ""} : leur résultat s'ajoutera ensuite au nouveau capital.")
        MaterialAlertDialogBuilder(this)
            .setTitle("Réinitialiser le capital à ${fmt(target)} $ ?")
            .setMessage(msg.toString())
            .setPositiveButton(if (diff < 0) "Retirer ${fmt(-diff)} $" else "Déposer ${fmt(diff)} $") { _, _ ->
                val m = Journal.resetCapitalTo(target)
                if (m != null) toast("${if (m.isDeposit) "Dépôt" else "Retrait"} de ${fmt(kotlin.math.abs(m.amount))} $ enregistré · capital : ${fmt(target)} $")
                onData()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun openPositionsScreen() {
        startActivity(Intent(this, JournalActivity::class.java).putExtra(JournalActivity.EXTRA_POSITIONS, true))
    }

    /**
     * Bandeau compact au-dessus du graphique : une seule ligne (résumé des positions et gain/perte en
     * direct). Toucher la ligne déplie le détail, limité à 3 lignes qui défilent : le graphique ne
     * rétrécit plus quand on ouvre plusieurs positions.
     */
    private var positionsExpanded = false
    private var positionsSummary: TextView? = null
    private var positionsList: LinearLayout? = null
    private var positionsScroll: ScrollView? = null

    private fun updatePositionsPanel() {
        val open = Journal.open(TradeMode.LIVE)
        if (open.isEmpty() || chartFullscreen) {
            positionsPanel.visibility = View.GONE
            if (open.isEmpty()) {
                positionsPanel.removeAllViews()
                positionRows.clear()
                positionsSummary = null
            }
            return
        }
        positionsPanel.visibility = View.VISIBLE
        if (positionsSummary == null) {
            positionsPanel.removeAllViews()
            positionRows.clear()
            positionsSummary = TextView(this).apply {
                textSize = 13f
                typeface = Typeface.MONOSPACE
                setPadding(dp(8), dp(6), dp(8), dp(6))
                setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.surface))
                setOnClickListener {
                    positionsExpanded = !positionsExpanded
                    positionRows.clear()
                    updatePositionsPanel()
                }
            }
            positionsList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            positionsScroll = ScrollView(this).apply { addView(positionsList) }
            positionsPanel.addView(positionsSummary)
            positionsPanel.addView(positionsScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0))
        }
        val list = positionsList!!
        val scroll = positionsScroll!!

        // Détail : recréé seulement si la liste des positions a changé
        if (positionsExpanded && open.map { it.id } != positionRows.keys.toList()) {
            list.removeAllViews()
            positionRows.clear()
            for (t in open) {
                val tv = TextView(this).apply {
                    textSize = 12f
                    typeface = Typeface.MONOSPACE
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    setOnClickListener {
                        val cur = Journal.open(TradeMode.LIVE).firstOrNull { it.id == t.id } ?: return@setOnClickListener
                        if (cur.symbol != MarketHub.symbol || MarketHub.lastPrice.isNaN()) {
                            toast("Affiche ${cur.symbol} pour gérer cette position")
                        } else {
                            TradeTicket.manage(this@MainActivity, cur, MarketHub.lastPrice, MarketHub.serverNow(), MarketHub.decimals()) { onData() }
                        }
                    }
                }
                list.addView(tv)
                positionRows[t.id] = tv
            }
        }
        // Hauteur du détail : au plus 3 lignes, défilement au-delà
        val rowsShown = if (positionsExpanded) minOf(open.size, 3) else 0
        val targetH = rowsShown * dp(26)
        val lp = scroll.layoutParams
        if (lp.height != targetH) {
            lp.height = targetH
            scroll.layoutParams = lp
        }

        val price = MarketHub.lastPrice
        var total = 0.0
        var counted = 0
        for (t in open) {
            val tv = positionRows[t.id]
            val arrow = if (t.side == Side.BUY) "▲" else "▼"
            val lot = t.lot?.let { String.format(Locale.US, " %.3f", it) } ?: ""
            if (t.symbol != MarketHub.symbol || price.isNaN()) {
                tv?.text = "$arrow$lot ${t.symbol} · en pause (indice non affiché)"
                tv?.setTextColor(ContextCompat.getColor(this, R.color.muted))
                continue
            }
            val r = t.rAt(price)
            val pnl = r * t.riskAmount
            total += pnl
            counted++
            tv?.text = "$arrow$lot @ ${MarketHub.format(t.entry)}  " + String.format(Locale.US, "%+.2f $ (%+.2f R)", pnl, r)
            tv?.setTextColor(ContextCompat.getColor(this, if (pnl >= 0) R.color.up else R.color.down))
        }
        val summary = positionsSummary!!
        val chevron = if (positionsExpanded) "▴" else "▾"
        summary.text = if (open.size == 1 && counted == 1) {
            val t = open[0]
            val r = t.rAt(price)
            "${if (t.side == Side.BUY) "▲ ACHAT" else "▼ VENTE"}${t.lot?.let { String.format(Locale.US, " %.3f lot", it) } ?: ""} @ ${MarketHub.format(t.entry)}  " +
                String.format(Locale.US, "%+.2f $ (%+.2f R)", r * t.riskAmount, r) + "  $chevron"
        } else {
            "${open.size} positions · " + String.format(Locale.US, "%+.2f $", total) + "  $chevron"
        }
        summary.setTextColor(ContextCompat.getColor(this, if (counted == 0) R.color.muted else if (total >= 0) R.color.up else R.color.down))
    }

    // ---------- Plein écran du graphique ----------

    private var chartFullscreen = false

    private val exitFullscreenOnBack = object : androidx.activity.OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = setChartFullscreen(false)
    }

    private fun setChartFullscreen(on: Boolean) {
        chartFullscreen = on
        exitFullscreenOnBack.isEnabled = on
        ChartFullscreen.set(this, chart, on)
        if (!on) onData()
    }

    private fun showPositions() {
        val open = Journal.open(TradeMode.LIVE)
        if (open.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Positions fictives")
                .setMessage("Aucune position ouverte. Utilise ACHAT ou VENTE pour en ouvrir une.\n\nCapital fictif : ${String.format(Locale.US, "%.2f", Journal.balance())} $")
                .setPositiveButton("Ouvrir le journal") { _, _ -> startActivity(Intent(this, JournalActivity::class.java)) }
                .setNegativeButton("Fermer", null)
                .show()
            return
        }
        val labels = open.map {
            val live = it.symbol == MarketHub.symbol && !MarketHub.lastPrice.isNaN()
            val r = if (live) String.format(Locale.US, "%+.2f R", it.rAt(MarketHub.lastPrice)) else "en pause (indice non affiché)"
            "${if (it.side == Side.BUY) "▲ Achat" else "▼ Vente"} ${it.symbol} ${it.timeframe} · $r"
        }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Positions ouvertes")
            .setItems(labels) { _, which ->
                val t = open[which]
                if (t.symbol != MarketHub.symbol || MarketHub.lastPrice.isNaN()) {
                    toast("Affiche ${t.symbol} pour gérer cette position")
                } else {
                    TradeTicket.manage(this, t, MarketHub.lastPrice, MarketHub.serverNow(), MarketHub.decimals()) { onData() }
                }
            }
            .setPositiveButton("Journal") { _, _ -> startActivity(Intent(this, JournalActivity::class.java)) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showToolsDialog() {
        val tools = Tool.values()
        val labels = tools.map { it.label }.toTypedArray()
        val checked = tools.map { MarketHub.toolEnabled(it) }.toBooleanArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Outils du graphique")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Appliquer") { _, _ ->
                tools.forEachIndexed { i, t -> MarketHub.setTool(t, checked[i]) }
                onData()
            }
            .setNeutralButton("Quitter l'appli") { _, _ ->
                MarketService.stop(this)
                finishAndRemoveTask()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
