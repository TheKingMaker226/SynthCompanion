package com.synthcompanion.app

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Inversion de polarité : une zone touchée plusieurs fois est cassée (clôture au-delà d'au moins
 * 0,3 ATR), puis le prix revient dessus. Une ancienne résistance peut alors servir de support
 * (et inversement).
 *
 * Tout est calculé sans regard vers le futur : la zone doit être connue AVANT la cassure, et le
 * retour est la première bougie qui revient toucher la zone après la cassure.
 */
object Polarity {

    /** Délai maximal entre la cassure et le retour (en bougies). */
    const val MAX_WAIT = 60
    /** Horizon pour juger si le niveau a tenu. */
    const val HORIZON = 50

    /**
     * Un retour sur zone cassée. [up] = cassure vers le haut (ancienne résistance devenue support).
     * [outcome] : +1 le prix est reparti de 1 ATR dans le sens de la cassure (le niveau a tenu),
     * −1 il a traversé de 1 ATR dans l'autre sens (échec), 0 indécis.
     */
    data class Retest(
        val low: Double, val high: Double, val up: Boolean,
        val breakIndex: Int, val retestIndex: Int, val outcome: Int,
    ) {
        val mid: Double get() = (low + high) / 2
        val age: Int get() = retestIndex - breakIndex
    }

    private class Pending(val low: Double, val high: Double, val up: Boolean, val breakIndex: Int)

    private fun firstPassage(c: List<Candle>, from: Int, ref: Double, x: Double, maxH: Int): Int {
        for (j in from + 1..min(c.size - 1, from + maxH)) {
            val up = c[j].high >= ref + x
            val down = c[j].low <= ref - x
            if (up && down) return 0
            if (up) return 1
            if (down) return -1
        }
        return 0
    }

    /** Décalage fixe et reproductible d'une zone, pour fabriquer de faux niveaux témoins. */
    fun fakeShift(z: Zone, atr: Double): Double {
        val key = floor(z.mid / max(atr, 1e-9))
        val h = ((key * 0.618033988749895) % 1.0 + 1.0) % 1.0
        val sign = if (((key.toLong() % 2) + 2) % 2 == 0L) 1 else -1
        return (1.5 + h * 1.5) * atr * sign
    }

    /**
     * Parcourt les bougies [from]..[to] et renvoie tous les retours sur zone cassée.
     * [shift] décale les zones (faux niveaux témoins pour le Labo).
     * Si [measure] est faux, l'issue n'est pas calculée (utile pour l'alerte en direct).
     */
    fun scan(
        a: Analysis,
        from: Int = 61,
        to: Int = a.candles.size - 1,
        shift: ((Zone, Double) -> Double)? = null,
        measure: Boolean = true,
    ): List<Retest> {
        val c = a.candles
        val st = a.structure
        val pending = ArrayList<Pending>()
        val out = ArrayList<Retest>()
        for (t in max(from, 61)..to) {
            val atr = st.atrAt(t)
            if (atr <= 0) continue

            // 1) Retours sur les zones cassées en attente
            val it = pending.iterator()
            while (it.hasNext()) {
                val p = it.next()
                if (t - p.breakIndex > MAX_WAIT) {
                    it.remove()
                    continue
                }
                if (t == p.breakIndex) continue
                val touched = if (p.up) c[t].low <= p.high else c[t].high >= p.low
                if (touched) {
                    val o = if (measure) firstPassage(c, t, c[t].close, atr, HORIZON) * (if (p.up) 1 else -1) else 0
                    out.add(Retest(p.low, p.high, p.up, p.breakIndex, t, o))
                    it.remove()
                }
            }

            // 2) Nouvelles cassures de zones connues avant cette bougie
            val prev = c[t - 1].close
            val cl = c[t].close
            for (z in st.zonesAt(t - 1)) {
                if (z.touches < 2) continue
                val off = shift?.invoke(z, atr) ?: 0.0
                val lo = z.low + off
                val hi = z.high + off
                val up = prev <= hi && cl > hi + 0.3 * atr
                val down = prev >= lo && cl < lo - 0.3 * atr
                if (!up && !down) continue
                val mid = (lo + hi) / 2
                if (pending.any { it.up == up && abs((it.low + it.high) / 2 - mid) < 0.5 * atr }) continue
                pending.add(Pending(lo, hi, up, t))
            }
        }
        return out
    }

    /**
     * Caractéristiques pour l'IA, calculées en un seul passage (rapide même sur 80 000 bougies) à
     * partir des sommets et creux confirmés :
     *  - distance au dernier niveau cassé, en ATR, positive du côté de la cassure ;
     *  - ancienneté de la cassure (0 à 1, sur 100 bougies) ;
     *  - « en retour » : +1 si le prix est revenu à moins de 0,5 ATR d'un niveau cassé vers le haut
     *    depuis moins de 60 bougies, −1 pour une cassure vers le bas, 0 sinon.
     */
    class Features(val dist: DoubleArray, val age: DoubleArray, val retest: DoubleArray)

    fun features(a: Analysis): Features {
        val c = a.candles
        val n = c.size
        val dist = DoubleArray(n)
        val age = DoubleArray(n)
        val retest = DoubleArray(n)
        val piv = a.structure.pivots
        var pi = 0
        val active = ArrayList<Double>()
        var lastLevel = Double.NaN
        var lastUp = true
        var lastIdx = -1
        for (i in 1 until n) {
            while (pi < piv.size && piv[pi].confirmIndex <= i) {
                active.add(piv[pi].price)
                if (active.size > 30) active.removeAt(0)
                pi++
            }
            val atr = a.atr[i]
            if (atr.isNaN() || atr <= 0) continue
            val prev = c[i - 1].close
            val cl = c[i].close
            var k = active.size - 1
            while (k >= 0) {
                val lv = active[k]
                val up = prev <= lv && cl > lv + 0.3 * atr
                val down = prev >= lv && cl < lv - 0.3 * atr
                if (up || down) {
                    lastLevel = lv
                    lastUp = up
                    lastIdx = i
                    active.removeAt(k)
                }
                k--
            }
            if (lastIdx >= 0) {
                val sign = if (lastUp) 1.0 else -1.0
                dist[i] = ((cl - lastLevel) / atr * sign).coerceIn(-5.0, 5.0)
                age[i] = min(1.0, (i - lastIdx) / 100.0)
                retest[i] = if (i > lastIdx && abs(cl - lastLevel) < 0.5 * atr && i - lastIdx <= MAX_WAIT) sign else 0.0
            }
        }
        return Features(dist, age, retest)
    }
}
