package com.synthcompanion.app

import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.synthcompanion.app.SketchView.Companion.BLUE
import com.synthcompanion.app.SketchView.Companion.DOWN
import com.synthcompanion.app.SketchView.Companion.GOLD
import com.synthcompanion.app.SketchView.Companion.GREY
import com.synthcompanion.app.SketchView.Companion.UP
import com.synthcompanion.app.SketchView.Companion.VIOLET
import com.synthcompanion.app.SketchView.Companion.WHITE
import com.synthcompanion.app.SketchView.Companion.c
import com.synthcompanion.app.SketchView.Level
import com.synthcompanion.app.SketchView.Mark
import com.synthcompanion.app.SketchView.Segment

/** Guide des outils : ce que c'est, comment l'appli le détecte, comment prendre position, pièges. */
class GuideActivity : AppCompatActivity() {

    /** Bloc de contenu d'une fiche. */
    private sealed class B {
        class H(val t: String) : B()
        class T(val t: String) : B()
        class L(val items: List<String>) : B()
        class S(val make: (Context) -> View, val caption: String) : B()
    }

    private class Section(val icon: String, val title: String, val summary: String, val blocks: List<B>)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)

    private val sections: List<Section> by lazy { buildSections() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply {
            text = "Guide des outils"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(color(R.color.text))
        })
        content.addView(TextView(this).apply {
            text = "Touche une fiche pour l'ouvrir. Chaque outil : ce que c'est, comment l'appli le repère, comment prendre position, et les pièges."
            textSize = 13f
            setTextColor(color(R.color.muted))
            setPadding(0, dp(4), 0, dp(10))
        })
        for (s in sections) content.addView(sectionView(s))
        val scroll = ScrollView(this).apply {
            setBackgroundColor(color(R.color.bg))
            addView(content)
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left + dp(14), b.top + dp(8), b.right + dp(14), b.bottom + dp(12))
            insets
        }
        setContentView(scroll)
    }

    private fun sectionView(s: Section): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(12), 0, dp(12), dp(12))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(TextView(this@GuideActivity).apply {
                text = "${s.icon}  ${s.title}"
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(color(R.color.text))
            })
            addView(TextView(this@GuideActivity).apply {
                text = s.summary
                textSize = 12f
                setTextColor(color(R.color.muted))
            })
        }
        var built = false
        header.setOnClickListener {
            if (!built) {
                s.blocks.forEach { body.addView(blockView(it)) }
                built = true
            }
            body.visibility = if (body.visibility == View.GONE) View.VISIBLE else View.GONE
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(R.color.surface))
            addView(header)
            addView(body)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
    }

    private fun blockView(b: B): View = when (b) {
        is B.H -> TextView(this).apply {
            text = b.t
            textSize = 14.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(color(R.color.accent))
            setPadding(0, dp(12), 0, dp(4))
        }
        is B.T -> TextView(this).apply {
            text = b.t
            textSize = 13.5f
            setTextColor(color(R.color.text))
            setLineSpacing(0f, 1.2f)
            setPadding(0, dp(2), 0, dp(2))
        }
        is B.L -> TextView(this).apply {
            text = b.items.joinToString("\n") { "•  $it" }
            textSize = 13.5f
            setTextColor(color(R.color.text))
            setLineSpacing(0f, 1.25f)
            setPadding(dp(4), dp(2), 0, dp(2))
        }
        is B.S -> LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(4))
            addView(b.make(this@GuideActivity))
            addView(TextView(this@GuideActivity).apply {
                text = b.caption
                textSize = 11.5f
                setTextColor(color(R.color.muted))
                setPadding(0, dp(3), 0, 0)
            })
        }
    }

    // ---------- Contenu ----------

    private fun buildSections(): List<Section> = listOf(
        Section("🗺", "Légende du graphique", "Ce que veulent dire les lettres, couleurs et lignes", listOf(
            B.L(listOf(
                "E (vert en dessous / rouge au-dessus) : bougie englobante haussière / baissière.",
                "P : pin bar. Vert sous la bougie = marteau (haussier). Rouge au-dessus = étoile filante (baissier).",
                "★ : étoile du matin (verte) ou du soir (rouge), figure en 3 bougies.",
                "3 : trois soldats blancs (vert) ou trois corbeaux noirs (rouge).",
                "Zones vertes « S 3× » : supports touchés 3 fois. Zones rouges « R 2× » : résistances.",
                "Lignes vertes / rouges obliques : lignes de tendance de support / de résistance, épaisses à partir de 3 touches.",
                "Lignes violettes « 38.2 % », « 61.8 % » : retracements de Fibonacci.",
                "Traits reliant des sommets et des creux, avec un nom : figures chartistes (✓ = confirmée).",
                "Courbes jaune et bleue : EMA 20 et EMA 50. Panneau du bas : RSI 14.",
                "Triangles verts / rouges : signaux de la stratégie choisie (menu Signaux).",
                "Lignes Entrée / SL / TP : tes positions fictives, avec le gain ou la perte en direct.",
            )),
            B.T("Tu peux afficher ou masquer chaque outil dans Menu → Outils du graphique."),
        )),

        Section("🕯", "Lire une bougie", "Corps, mèches, et ce qu'elles racontent", listOf(
            B.T("Une bougie résume une période (1 minute en M1, 1 heure en H1…). Le corps va de l'ouverture à la clôture : vert si la clôture est plus haute, rouge si elle est plus basse. Les mèches montrent le plus haut et le plus bas atteints."),
            B.S({ SketchView(it, candles = listOf(c(5.0, 9.0, 4.0, 8.0), c(8.0, 8.5, 3.5, 4.5), c(5.0, 5.4, 2.0, 5.2), c(5.0, 8.0, 4.8, 5.1)),
                marks = listOf(Mark(0.0, 9.6, "hausse", UP), Mark(1.0, 9.0, "baisse", DOWN), Mark(2.0, 6.2, "rejet bas", GOLD), Mark(3.0, 8.6, "rejet haut", GOLD))) },
                "Une longue mèche = le prix est allé loin puis a été repoussé : c'est un rejet."),
            B.T("Règle d'or : une bougie seule ne suffit pas. Elle compte surtout quand elle se forme sur un niveau important (support, résistance, ligne de tendance, Fibonacci) et dans le sens du contexte."),
        )),

        Section("E", "Englobante haussière et baissière", "Une bougie qui « avale » la précédente", listOf(
            B.H("Ce que c'est"),
            B.T("Englobante haussière : une bougie rouge, puis une bougie verte dont le corps recouvre entièrement celui de la rouge. Les acheteurs ont repris tout le terrain perdu, et plus encore. L'englobante baissière est l'inverse."),
            B.S({ SketchView(it, candles = listOf(c(10.0, 10.3, 8.8, 9.0), c(9.0, 9.2, 7.8, 8.0), c(8.0, 8.2, 6.9, 7.2), c(7.0, 9.7, 6.8, 9.5)),
                levels = listOf(Level(6.8, "stop", DOWN)), marks = listOf(Mark(3.0, 10.3, "E", UP))) },
                "Englobante haussière après une baisse. Stop sous le plus bas de la figure."),
            B.H("Comment l'appli la repère"),
            B.T("Bougie précédente de couleur inverse, corps actuel qui englobe le corps précédent, et corps d'au moins 0,3 ATR (pour écarter les petites bougies sans signification)."),
            B.H("Comment prendre position"),
            B.L(listOf(
                "Contexte : cherche-la sur un support (achat) ou une résistance (vente), idéalement dans le sens de la tendance EMA.",
                "Entrée : à la clôture de la bougie englobante, ou plus prudent : au dépassement de son plus haut (achat).",
                "Stop : sous le plus bas de la figure (achat) / au-dessus du plus haut (vente), avec une petite marge (0,2 ATR).",
                "Objectif : la prochaine résistance (achat) ou le prochain support (vente), ou au moins 2 fois le risque (2 R).",
            )),
            B.H("Pièges"),
            B.L(listOf(
                "Au milieu de nulle part (loin de tout niveau), elle est peu fiable.",
                "Une englobante contre une forte tendance échoue souvent : attends la confirmation.",
                "Si le stop est trop loin et qu'aucun objectif ne donne 1:1,5 au minimum, passe ton tour.",
            )),
        )),

        Section("P", "Pin bar : marteau et étoile filante", "Longue mèche = rejet d'un niveau", listOf(
            B.H("Ce que c'est"),
            B.T("Un petit corps avec une très longue mèche d'un seul côté. Marteau (pin bar haussière) : longue mèche vers le bas, le prix a plongé puis a été racheté. Étoile filante (pin bar baissière) : longue mèche vers le haut, le prix a été rejeté vers le bas."),
            B.S({ SketchView(it, candles = listOf(c(9.0, 9.2, 8.0, 8.2), c(8.2, 8.4, 7.2, 7.4), c(7.3, 7.6, 4.6, 7.5), c(7.5, 8.6, 7.4, 8.5)),
                levels = listOf(Level(5.0, "support", UP, false), Level(4.4, "stop", DOWN)), marks = listOf(Mark(2.0, 4.0, "P", UP))) },
                "Marteau qui rejette un support : la mèche montre que les vendeurs n'ont pas tenu sous le niveau."),
            B.H("Comment l'appli la repère"),
            B.T("Mèche au moins 2 fois plus longue que le corps et au moins 60 % de la bougie, mèche opposée petite (≤ 25 %), et bougie assez grande (≥ 0,5 ATR)."),
            B.H("Comment prendre position"),
            B.L(listOf(
                "Contexte : la mèche doit toucher ou traverser un niveau (support pour un marteau, résistance pour une étoile filante).",
                "Entrée : à la clôture de la pin bar, ou au dépassement du haut de la pin bar (marteau).",
                "Stop : derrière la pointe de la mèche, avec une marge.",
                "Objectif : niveau suivant, ou 2 R. Si la mèche est très longue, le stop est loin : réduis le lot pour garder le même risque en $.",
            )),
            B.H("Pièges"),
            B.L(listOf(
                "Une pin bar dont la mèche ne touche aucun niveau n'a pas grand sens.",
                "Plusieurs pin bars de suite au même endroit = indécision, pas forcément retournement.",
            )),
        )),

        Section("★", "Étoile du matin et étoile du soir", "Retournement en 3 bougies", listOf(
            B.H("Ce que c'est"),
            B.T("Étoile du matin : une grosse bougie rouge, puis une petite bougie d'hésitation, puis une grosse bougie verte qui clôture au-dessus du milieu de la première. La baisse s'essouffle puis les acheteurs reprennent la main. L'étoile du soir est l'inverse, au sommet d'une hausse."),
            B.S({ SketchView(it, candles = listOf(c(10.5, 10.7, 9.8, 10.0), c(10.0, 10.1, 7.4, 7.5), c(7.4, 7.7, 6.8, 7.2), c(7.2, 9.6, 7.0, 9.4)),
                levels = listOf(Level(6.6, "stop", DOWN)), marks = listOf(Mark(3.0, 10.2, "★", UP))) },
                "Étoile du matin : rouge, hésitation, verte qui reprend plus de la moitié de la rouge."),
            B.H("Comment l'appli la repère"),
            B.T("1re bougie avec un corps d'au moins 0,6 ATR, 2e bougie au corps petit (≤ 0,3 ATR), 3e bougie de couleur inverse qui clôture au-delà du milieu de la 1re."),
            B.H("Comment prendre position"),
            B.L(listOf(
                "Entrée : à la clôture de la 3e bougie.",
                "Stop : sous le plus bas des trois bougies (étoile du matin) / au-dessus du plus haut (étoile du soir).",
                "Objectif : prochain niveau ou 2 R. C'est une figure plus « complète » qu'une seule bougie, mais le stop est souvent plus large.",
            )),
        )),

        Section("3", "Trois soldats blancs / trois corbeaux noirs", "Élan fort dans une direction", listOf(
            B.T("Trois grosses bougies de suite dans le même sens, chacune clôturant plus loin que la précédente. Elles montrent un mouvement qui accélère plutôt qu'un retournement."),
            B.S({ SketchView(it, candles = listOf(c(5.0, 5.3, 4.6, 4.8), c(4.8, 6.2, 4.7, 6.0), c(6.0, 7.4, 5.9, 7.2), c(7.2, 8.6, 7.1, 8.4)),
                marks = listOf(Mark(3.0, 9.2, "3", UP))) }, "Trois soldats blancs : trois bougies vertes d'au moins 0,5 ATR."),
            B.H("Comment s'en servir"),
            B.L(listOf(
                "Plutôt qu'entrer après la 3e bougie (souvent tard), attends un repli vers le milieu du mouvement ou vers l'EMA 20.",
                "Si la figure casse une résistance, cette résistance devient un support possible pour entrer au retour.",
                "Stop sous le creux du repli, objectif : prolongement (extension Fibonacci 127,2 % ou 161,8 %).",
            )),
        )),

        Section("D", "Doji et inside bar", "Indécision et compression (non marqués sur le graphique)", listOf(
            B.T("Doji : corps quasi nul, ouverture ≈ clôture. Personne ne gagne la période. Inside bar : bougie entièrement comprise dans la précédente, le marché se comprime."),
            B.S({ SketchView(it, candles = listOf(c(6.0, 9.0, 5.5, 8.5), c(8.3, 8.6, 7.0, 7.4), c(7.4, 8.4, 6.6, 7.42))) },
                "Grosse bougie, inside bar (contenue dedans), puis doji."),
            B.H("Comment s'en servir"),
            B.L(listOf(
                "Ce ne sont pas des signaux d'entrée seuls : elles annoncent souvent un mouvement à venir, sans dire dans quel sens.",
                "Inside bar : place un plan de cassure. Achat si le prix dépasse le haut de la bougie mère, vente s'il casse son bas. Stop de l'autre côté.",
                "Un doji sur un niveau fort, suivi d'une bougie qui part dans un sens, peut compléter un signal (comme l'étoile du matin).",
            )),
        )),

        Section("▭", "Supports et résistances", "Les zones où le prix a déjà réagi", listOf(
            B.H("Ce que c'est"),
            B.T("Un support est une zone de prix où la baisse s'est arrêtée plusieurs fois ; une résistance, une zone où la hausse s'est arrêtée. On parle de zones plutôt que de lignes exactes : le prix réagit rarement au point près."),
            B.S({ SketchView(it, line = listOf(5.0, 7.5, 6.2, 8.9, 6.3, 8.8, 7.0, 9.8, 10.4),
                levels = listOf(Level(9.0, "résistance", DOWN, false), Level(6.2, "support", UP, false))) },
                "Rebonds sur le support, rejets sous la résistance, puis cassure au-dessus."),
            B.H("Comment l'appli les trouve"),
            B.T("Elle repère les sommets et creux importants (un mouvement d'au moins 2 ATR), puis regroupe ceux qui sont proches (moins de 0,6 ATR d'écart). Le chiffre « 3× » est le nombre de fois où la zone a été touchée : plus il est élevé et récent, plus la zone compte."),
            B.H("Deux façons de prendre position"),
            B.L(listOf(
                "Rebond : le prix revient sur un support, une bougie de retournement s'y forme (E, P, ★) → achat. Stop sous la zone, objectif : la résistance suivante.",
                "Cassure et retour : le prix clôture nettement au-delà d'une résistance, revient la tester par le dessus, et repart → achat au retour. L'ancienne résistance devient support.",
                "Toujours : vérifie que l'objectif est au moins 1,5 fois plus loin que le stop.",
            )),
            B.H("Pièges"),
            B.L(listOf(
                "Plus une zone est touchée, plus elle risque de céder : un 5e test n'est pas « plus sûr » qu'un 2e.",
                "Une simple mèche qui dépasse n'est pas une cassure : attends une clôture au-delà.",
                "Ne place pas ton stop pile sur le niveau : laisse une marge (0,3 à 0,5 ATR).",
            )),
        )),

        Section("🔁", "Inversion de polarité", "Support cassé → résistance, résistance cassée → support", listOf(
            B.H("Ce que c'est"),
            B.T("Quand une zone qui a bloqué le prix plusieurs fois finit par être cassée, elle change souvent de rôle : l'ancienne résistance sert de support au retour du prix, l'ancien support sert de résistance."),
            B.S({ SketchView(it, line = listOf(5.0, 7.8, 6.4, 7.9, 6.6, 9.2, 8.1, 7.9, 9.4, 10.6),
                levels = listOf(Level(8.0, "résistance → support", GOLD, false), Level(7.4, "stop", DOWN))) },
                "Deux rejets sous la zone, cassure, retour sur la zone par le haut, puis reprise."),
            B.H("Comment l'appli le repère"),
            B.T("Une zone touchée au moins 2 fois, connue avant la cassure. Cassure = clôture au-delà de la zone d'au moins 0,3 ATR. Retour = la première bougie qui revient toucher la zone dans les 60 bougies suivantes. Si l'alerte est activée (menu Signaux), tu reçois une notification à ce moment-là, avec un plan."),
            B.H("Comment prendre position (cassure puis retour)"),
            B.L(listOf(
                "N'achète pas la cassure elle-même : attends le retour sur la zone.",
                "Entre seulement si une bougie de rejet se forme sur la zone (pin bar, englobante) dans le sens de la cassure.",
                "Stop : de l'autre côté de la zone, avec une marge de 0,5 ATR. Objectif : niveau suivant, au moins 2 R.",
                "Si le prix clôture franchement de l'autre côté de la zone, la cassure a échoué : on sort.",
            )),
            B.H("Est-ce que ça marche sur le V50 ?"),
            B.T("Le Labo (test n° 5) compte, sur des milliers de bougies, combien de retours ont tenu, et compare avec de faux niveaux. On retient surtout les fois où ça a marché : le Labo compte aussi celles où ça n'a pas marché. L'IA utilise aussi la distance au dernier niveau cassé et vérifie si ça l'aide à prédire."),
        )),

        Section("⟋", "Lignes de tendance", "Relier les creux (ou les sommets) d'une tendance", listOf(
            B.H("Ce que c'est"),
            B.T("Dans une hausse, on relie au moins deux creux de plus en plus hauts : c'est une ligne de support montante. Dans une baisse, on relie les sommets de plus en plus bas : ligne de résistance descendante. Le prix a tendance à rebondir dessus tant que la tendance tient."),
            B.S({ SketchView(it, line = listOf(4.0, 6.0, 5.0, 7.2, 6.0, 8.3, 7.0, 9.2),
                segments = listOf(Segment(0.0, 4.0, 7.3, 7.4, UP, "support"))) },
                "Ligne de support montante qui relie des creux de plus en plus hauts."),
            B.H("Comment l'appli choisit les plus fortes"),
            B.T("Elle teste toutes les lignes possibles entre les derniers creux (ou sommets), écarte celles qu'une clôture a traversées, celles trop pentues ou trop loin du prix, puis garde les deux plus fortes de chaque côté. La force dépend du nombre de touches (affiché « 3× ») et de la longueur. Trait épais = au moins 3 touches."),
            B.H("Comment prendre position"),
            B.L(listOf(
                "Rebond : dans une hausse, achat quand le prix revient sur la ligne et forme une bougie haussière. Stop sous la ligne (et sous la mèche), objectif : dernier sommet ou plus.",
                "Cassure : une clôture nette sous une ligne de support montante signale que la hausse faiblit. Pas forcément une vente immédiate : attends souvent un retour sous la ligne.",
                "Deux lignes parallèles (support et résistance) forment un canal : acheter en bas, vendre en haut, tant qu'il tient.",
            )),
            B.H("Pièges"),
            B.L(listOf(
                "Une ligne à 2 points est fragile. Elle devient intéressante à partir de 3 touches.",
                "On peut toujours « forcer » une ligne. Celles de l'appli suivent des règles fixes, sans parti pris.",
            )),
        )),

        Section("φ", "Retracements de Fibonacci", "Où un repli a des chances de s'arrêter", listOf(
            B.H("Ce que c'est"),
            B.T("Après un mouvement (une « jambe »), le prix corrige souvent une partie du chemin avant de repartir. Les niveaux de Fibonacci découpent ce mouvement : 23,6 %, 38,2 %, 50 %, 61,8 % et 78,6 %. Les plus suivis sont 38,2 %, 50 % et 61,8 %. Les extensions 127,2 % et 161,8 % servent d'objectifs si le mouvement repart."),
            B.S({ SketchView(it, line = listOf(4.0, 5.5, 7.0, 8.4, 10.0, 8.8, 7.8, 8.6, 10.5, 11.6),
                levels = listOf(Level(10.0, "0 %", VIOLET), Level(7.71, "38,2 %", VIOLET), Level(7.0, "50 %", VIOLET), Level(6.29, "61,8 %", VIOLET), Level(4.0, "100 %", VIOLET))) },
                "Hausse de 4 à 10, repli jusqu'au 38,2 %, puis reprise."),
            B.H("Comment l'appli le trace"),
            B.T("Sur la jambe en cours : du dernier sommet ou creux confirmé jusqu'à l'extrême atteint depuis. Les niveaux se mettent à jour quand le mouvement se prolonge."),
            B.H("Comment prendre position"),
            B.L(listOf(
                "Dans une hausse, attends le repli dans la zone 38,2 % – 61,8 %.",
                "Entre seulement si une bougie de retournement s'y forme, idéalement sur un support ou une ligne de tendance au même endroit (confluence).",
                "Stop : sous le 78,6 %, ou sous le 100 % si tu veux plus de marge. Objectif : le dernier sommet (0 %), puis l'extension 127,2 %.",
            )),
            B.H("Pièges"),
            B.L(listOf(
                "Les niveaux ne sont pas magiques : un 61,8 % seul, sans autre raison, ne justifie pas une entrée.",
                "Au-delà de 78,6 %, le mouvement initial est souvent annulé.",
            )),
        )),

        Section("⋀", "Figures chartistes", "Double sommet, épaule-tête-épaule, triangles…", listOf(
            B.H("Double sommet / double creux"),
            B.T("Deux sommets à peu près au même niveau, séparés par un creux : la ligne de cou. La figure est confirmée quand le prix clôture sous la ligne de cou. Objectif théorique : la hauteur de la figure reportée sous la ligne de cou. Le double creux est l'inverse (haussier)."),
            B.S({ SketchView(it, line = listOf(5.0, 9.0, 7.0, 9.0, 6.4, 5.0),
                levels = listOf(Level(7.0, "ligne de cou", GOLD), Level(5.0, "objectif", GREY))) },
                "Double sommet : cassure de la ligne de cou, objectif = hauteur de la figure."),
            B.H("Épaule-tête-épaule"),
            B.T("Trois sommets, celui du milieu (la tête) plus haut que les deux autres (les épaules). Confirmée à la cassure de la ligne de cou qui relie les deux creux. Version inversée en bas de marché (haussière)."),
            B.S({ SketchView(it, line = listOf(5.0, 8.0, 6.5, 9.8, 6.6, 8.0, 5.6, 4.6),
                levels = listOf(Level(6.5, "ligne de cou", GOLD))) }, "Épaule, tête, épaule, puis cassure de la ligne de cou."),
            B.H("Triangles, biseaux et canaux"),
            B.L(listOf(
                "Triangle ascendant : sommets au même niveau, creux de plus en plus hauts → souvent cassure vers le haut.",
                "Triangle descendant : l'inverse → souvent cassure vers le bas.",
                "Triangle symétrique : compression sans sens privilégié → attendre la cassure.",
                "Biseau ascendant (les deux lignes montent en se resserrant) → plutôt baissier. Biseau descendant → plutôt haussier.",
                "Canal : deux lignes parallèles, le prix fait des allers-retours entre elles.",
            )),
            B.H("Comment prendre position"),
            B.L(listOf(
                "N'anticipe pas : attends la cassure (clôture au-delà de la ligne de cou ou du triangle). Le ✓ sur le graphique indique une figure confirmée.",
                "Entrée à la cassure, ou au retour sur la ligne cassée (plus prudent, meilleur prix).",
                "Stop : de l'autre côté de la ligne, derrière la dernière épaule ou le dernier sommet. Objectif : l'objectif théorique affiché dans le rapport.",
            )),
        )),

        Section("〰", "Indicateurs : EMA, RSI, ATR", "Tendance, élan et volatilité", listOf(
            B.H("EMA 20 et EMA 50 (moyennes mobiles)"),
            B.T("Moyennes des prix récents qui donnent plus de poids aux dernières bougies. EMA 20 (jaune) au-dessus de l'EMA 50 (bleue) : tendance haussière. En dessous : baissière. Elles servent aussi de supports et résistances « mobiles »."),
            B.S({ SketchView(it, line = listOf(5.0, 5.8, 5.4, 6.6, 6.2, 7.4, 7.0, 8.2),
                segments = listOf(Segment(0.0, 4.8, 7.0, 7.3, GOLD, "EMA 20"), Segment(0.0, 4.4, 7.0, 6.4, BLUE, "EMA 50"))) },
                "EMA 20 au-dessus de l'EMA 50 : on cherche plutôt des achats sur repli."),
            B.L(listOf(
                "Filtre de tendance : n'achète que si l'EMA 20 est au-dessus de l'EMA 50, ne vends que si elle est en dessous.",
                "Repli sur l'EMA 20 dans une tendance = zone d'entrée classique (avec une bougie de retournement).",
                "Croisement EMA 20 / EMA 50 : signal de changement de tendance, souvent en retard.",
            )),
            B.H("RSI 14"),
            B.T("Mesure la force des hausses face aux baisses récentes, de 0 à 100. Au-dessus de 70 : surachat (la hausse a été forte). Sous 30 : survente. Au-dessus de 50 : les acheteurs dominent."),
            B.L(listOf(
                "Le surachat n'est pas un signal de vente en soi : en forte tendance, le RSI peut rester au-dessus de 70 longtemps.",
                "Usage prudent : acheter quand le RSI repasse au-dessus de 30 près d'un support, vendre quand il repasse sous 70 près d'une résistance.",
                "Divergence : le prix fait un plus haut mais le RSI un plus bas → l'élan faiblit.",
            )),
            B.H("ATR 14 (volatilité)"),
            B.T("Taille moyenne d'une bougie sur les 14 dernières. L'appli s'en sert pour adapter tous ses outils à l'indice et à l'unité de temps, et pour proposer des stops (1,5 ATR) et des objectifs (3 ATR)."),
            B.L(listOf(
                "Un stop à moins d'1 ATR se fait souvent toucher par le simple bruit du marché.",
                "Quand l'ATR est grand, réduis le lot pour garder le même risque en $.",
            )),
        )),

        Section("🎯", "Signaux de l'appli", "Les 4 stratégies du menu Signaux", listOf(
            B.L(listOf(
                "Croisement EMA 20/50 : achat quand l'EMA 20 passe au-dessus de l'EMA 50 avec RSI > 50 (vente : l'inverse).",
                "Rebond RSI 30/70 : achat quand le RSI repasse au-dessus de 30, vente quand il repasse sous 70.",
                "Cassure 20 bougies : achat quand la clôture dépasse le plus haut des 20 dernières bougies (vente : sous le plus bas).",
                "Price action : bougie de retournement (E, P, ★…) posée sur un support ou une ligne de tendance, dans le sens de la tendance EMA. Stop derrière la mèche.",
            )),
            B.T("Chaque signal arrive à la clôture de la bougie, avec entrée, stop et objectif. Le rapport indique le résultat passé de chaque stratégie : regarde-le avant de faire confiance à un signal. Le Labo teste si elle bat vraiment le hasard."),
        )),

        Section("🛡", "Gestion du risque", "Stop, lot, R et ratio gain/risque", listOf(
            B.H("Le R"),
            B.T("1 R = ce que tu perds si ton stop est touché. Un trade à +2 R rapporte deux fois ton risque. Mesurer en R permet de comparer tous tes trades, quelle que soit la taille du lot."),
            B.H("Taille de position"),
            B.L(listOf(
                "Décide d'abord ton stop (où le trade est faux), puis ton lot, pas l'inverse.",
                "Sur les synthétiques Deriv : risque en $ = lot × distance du stop. Ex. 0,01 lot avec un stop à 500 points = 5 $.",
                "Règle courante : ne pas risquer plus de 1 à 2 % du capital par trade. Même 10 pertes d'affilée restent alors supportables.",
            )),
            B.H("Ratio gain/risque et taux de réussite"),
            B.T("Avec un objectif à 2 R, il suffit de gagner plus d'un trade sur trois pour être rentable (avant frais). Avec 1 R, il en faut plus d'un sur deux. Le journal te montre où tu en es."),
            B.H("Discipline"),
            B.L(listOf(
                "Écris ton plan avant d'entrer (setup, entrée, stop, objectif) : la note du ticket est faite pour ça.",
                "Ne déplace pas ton stop pour éviter une perte. Tu peux le rapprocher, jamais l'éloigner.",
                "Après une perte, fais une pause : le journal repère les trades pris juste après une perte.",
            )),
        )),

        Section("⚠", "À savoir sur les indices synthétiques", "Pourquoi tester avant de croire", listOf(
            B.T("Deriv indique que ses indices de volatilité sont produits par un processus aléatoire cryptographiquement sûr, et que des figures peuvent s'y former naturellement. Tous les outils de ce guide décrivent où le prix a réagi ; ils ne garantissent pas la suite."),
            B.L(listOf(
                "Utilise le Labo pour vérifier si une figure ou un niveau a vraiment fait mieux que le hasard sur l'indice et l'unité de temps choisis.",
                "Utilise le replay et le trading fictif pour t'entraîner et accumuler au moins 30 à 50 trades avant de juger une méthode.",
                "Rien dans cette appli n'est un conseil financier.",
            )),
        )),
    )
}
